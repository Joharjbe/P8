# src/our_library/graph.py
import json, uuid
from IPython.display import HTML

def hello_d3(width=260, height=160, radius=36, color="#1976d2"):
    """
    Dibuja un círculo con D3. Si D3 no se puede cargar desde CDN (CSP),
    cae a un fallback con SVG nativo.
    """
    html = """
<div class="ourlib-hello-d3"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui;">
  <div class="viz"></div>
</div>

<!-- 1) Intentamos cargar D3 desde CDN -->
<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>

<!-- 2) Script que dibuja con D3 o cae a fallback -->
<script>
(function() {
  const container = document.currentScript.previousElementSibling; // el <div class="ourlib-hello-d3">
  const viz = container.querySelector('.viz');

  // Helper para mensajes
  const say = function(msg) {
    const p = document.createElement('p');
    p.style.margin = '6px 0 0 0';
    p.textContent = msg;
    container.appendChild(p);
  };

  const W = %d, H = %d, R = %d;
  const COLOR = "%s";

  if (typeof d3 !== 'undefined') {
    // ========== Con D3 ==========
    const svg = d3.select(viz)
      .append('svg')
      .attr('width', W)
      .attr('height', H);

    svg.append('circle')
      .attr('cx', W/2)
      .attr('cy', H/2)
      .attr('r', R)
      .attr('fill', COLOR)
      .attr('opacity', 0.9);

    say("D3 cargado: " + d3.version);
  } else {
    // ========== Fallback sin D3 (SVG nativo) ==========
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', W);
    svg.setAttribute('height', H);

    const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    c.setAttribute('cx', W/2);
    c.setAttribute('cy', H/2);
    c.setAttribute('r', R);
    c.setAttribute('fill', COLOR);
    c.setAttribute('opacity', '0.9');

    svg.appendChild(c);
    viz.appendChild(svg);

    say("D3 no disponible (CSP). Mostrando fallback SVG.");
  }
})();
</script>
""" % (width, height, radius, color)
    return HTML(html)


# --- NUEVA FUNCIÓN ---
def show_graph(nodes, links, width=520, height=360, node_radius=8,
               node_color="#1976d2", link_color="#999"):
    """
    Dibuja un grafo ESTÁTICO (sin fuerzas) con SVG nativo.
    - nodes: lista de dicts con al menos {"id": ...}
    - links: lista de dicts con {"source": <id>, "target": <id>}
    """
    # Validación mínima en Python (errores claros si los datos vienen mal)
    if not isinstance(nodes, (list, tuple)) or not isinstance(links, (list, tuple)):
        raise TypeError("nodes y links deben ser listas/tuplas")

    for i, n in enumerate(nodes):
        if not isinstance(n, dict) or "id" not in n:
            raise ValueError(f"nodes[{i}] debe tener clave 'id'")

    node_ids = {str(n["id"]) for n in nodes}
    clean_links = []
    for j, e in enumerate(links):
        if not isinstance(e, dict) or "source" not in e or "target" not in e:
            raise ValueError(f"links[{j}] debe tener 'source' y 'target'")
        s, t = str(e["source"]), str(e["target"])
        # Ignoramos aristas con ids inexistentes (para que no reviente)
        if s in node_ids and t in node_ids:
            clean_links.append({"source": s, "target": t})

    data = {"nodes": nodes, "links": clean_links}
    data_json = json.dumps(data)  # seguro para incrustar en JS
    cid = "ourlib-" + uuid.uuid4().hex  # id único del contenedor

    html = """
<div id="%s" class="ourlib-graph"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui;">
  <div class="viz"></div>
</div>

<script>
(function(){
  const root = document.getElementById('%s');
  const viz  = root.querySelector('.viz');
  const data = %s;

  const W = %d, H = %d, R = %d;
  const NODE_COLOR = "%s";
  const LINK_COLOR = "%s";

  // 1) Posicionamos nodos en un círculo (layout simple)
  const n = data.nodes.length;
  const cx = W/2, cy = H/2;
  const rad = Math.min(W, H)/2 - (R + 12);
  const pos = {};
  data.nodes.forEach((node, i) => {
    const ang = (i / Math.max(1, n)) * 2 * Math.PI;
    pos[String(node.id)] = {
      x: cx + rad * Math.cos(ang),
      y: cy + rad * Math.sin(ang)
    };
  });

  // 2) Creamos el SVG
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('width', W);
  svg.setAttribute('height', H);
  viz.appendChild(svg);

  // 3) Dibujamos aristas
  (data.links || []).forEach(link => {
    const a = pos[String(link.source)];
    const b = pos[String(link.target)];
    if (!a || !b) return;
    const line = document.createElementNS(svgNS, 'line');
    line.setAttribute('x1', a.x);
    line.setAttribute('y1', a.y);
    line.setAttribute('x2', b.x);
    line.setAttribute('y2', b.y);
    line.setAttribute('stroke', LINK_COLOR);
    line.setAttribute('stroke-width', 1.5);
    line.setAttribute('opacity', 0.8);
    svg.appendChild(line);
  });

  // 4) Dibujamos nodos
  data.nodes.forEach(node => {
    const p = pos[String(node.id)];
    const c = document.createElementNS(svgNS, 'circle');
    c.setAttribute('cx', p.x);
    c.setAttribute('cy', p.y);
    c.setAttribute('r', R);
    c.setAttribute('fill', NODE_COLOR);
    c.setAttribute('opacity', 0.9);
    svg.appendChild(c);
  });

  // Nota
  const note = document.createElement('p');
  note.style.margin = '6px 0 0';
  note.textContent = 'show_graph() estático (sin fuerzas).';
  root.appendChild(note);
})();
</script>
""" % (cid, cid, data_json, width, height, node_radius, node_color, link_color)

    return HTML(html)


# --- NUEVA FUNCIÓN ---
# src/our_library/graph.py
import json, uuid, base64
from pathlib import Path
from IPython.display import HTML

# no funciona la parte dinámica porque vscode bloquea al tratar de inyectar D3 
def show_graph_force(nodes, links, width=640, height=420, node_radius=8,
                     node_color="#1976d2", link_color="#999",
                     link_distance=70, charge_strength=-160):
    """
    Grafo con layout de fuerzas usando D3 cargado INLINE (sin CDN, sin data:, sin eval).
    Si no se logra inyectar D3, cae a un render estático simple.
    """
    # Validaciones mínimas
    if not isinstance(nodes, (list, tuple)) or not isinstance(links, (list, tuple)):
        raise TypeError("nodes y links deben ser listas/tuplas")
    for i, n in enumerate(nodes):
        if not isinstance(n, dict) or "id" not in n:
            raise ValueError(f"nodes[{i}] debe tener clave 'id'")

    node_ids = {str(n["id"]) for n in nodes}
    clean_links = []
    for j, e in enumerate(links):
        if not isinstance(e, dict) or "source" not in e or "target" not in e:
            raise ValueError(f"links[{j}] debe tener 'source' y 'target'")
        s, t = str(e["source"]), str(e["target"])
        if s in node_ids and t in node_ids:
            clean_links.append({"source": s, "target": t})

    data = {"nodes": nodes, "links": clean_links}
    data_json = json.dumps(data)
    cid = "ourlib-" + uuid.uuid4().hex

    # 1) Leemos d3.v7.min.js (local)
    d3_path = Path(__file__).parent / "_static" / "d3.v7.min.js"
    try:
        d3_text = d3_path.read_text(encoding="utf-8")
    except Exception:
        d3_text = None  # si no está, haremos fallback

    # 2) Construimos HTML por piezas para evitar problemas con % en el código de D3
    parts = []

    # Contenedor
    parts.append(f"""
<div id="{cid}" class="ourlib-graph"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui;">
  <div class="viz"></div>
</div>
""")

    if d3_text is not None:
        # 3) Inyectamos D3 como <script> inline (sin eval)
        parts.append("<script>\n" + d3_text + "\n</script>\n")

        # 4) Script principal que usa D3 (con formato seguro separando el bloque JS)
        main_js = """
(function(){
  const root = document.getElementById('%(cid)s');
  const viz  = root.querySelector('.viz');
  const data = %(data_json)s;

  const W = %(W)d, H = %(H)d, R = %(R)d;
  const NODE_COLOR = "%(NODE_COLOR)s";
  const LINK_COLOR = "%(LINK_COLOR)s";
  const LINK_DIST  = %(LINK_DIST)d;
  const CHARGE_STR = %(CHARGE_STR)d;

  if (typeof d3 !== 'undefined') {
    const svg = d3.select(viz).append('svg')
      .attr('width', W).attr('height', H);

    const link = svg.append('g')
      .attr('stroke', LINK_COLOR).attr('stroke-opacity', 0.7)
      .selectAll('line').data(data.links).join('line')
      .attr('stroke-width', 1.5);

    const node = svg.append('g')
      .selectAll('circle').data(data.nodes).join('circle')
      .attr('r', R).attr('fill', NODE_COLOR).attr('opacity', 0.95);

    const sim = d3.forceSimulation(data.nodes)
      .force('link', d3.forceLink(data.links).id(d => String(d.id)).distance(LINK_DIST))
      .force('charge', d3.forceManyBody().strength(CHARGE_STR))
      .force('center', d3.forceCenter(W/2, H/2));

    sim.on('tick', () => {
      link.attr('x1', d => d.source.x)
          .attr('y1', d => d.source.y)
          .attr('x2', d => d.target.x)
          .attr('y2', d => d.target.y);

      node.attr('cx', d => d.x)
          .attr('cy', d => d.y);
    });

    const p = document.createElement('p');
    p.style.margin = '6px 0 0';
    p.textContent = 'show_graph_force() con D3 local (inline).';
    root.appendChild(p);
  } else {
    const p = document.createElement('p');
    p.style.margin = '6px 0 0';
    p.textContent = 'D3 no disponible (inline no ejecutó). Fallback estático.';
    root.appendChild(p);
  }
})();
"""
        parts.append("<script>\n" + (main_js % {
            "cid": cid,
            "data_json": data_json,
            "W": width, "H": height, "R": node_radius,
            "NODE_COLOR": node_color, "LINK_COLOR": link_color,
            "LINK_DIST": link_distance, "CHARGE_STR": charge_strength
        }) + "\n</script>\n")

    else:
        # 5) Fallback estático si no pudimos leer D3
        fallback_js = """
(function(){
  const root = document.getElementById('%(cid)s');
  const viz  = root.querySelector('.viz');
  const data = %(data_json)s;

  const W = %(W)d, H = %(H)d, R = %(R)d;
  const NODE_COLOR = "%(NODE_COLOR)s";
  const LINK_COLOR = "%(LINK_COLOR)s";

  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('width', W); svg.setAttribute('height', H);
  viz.appendChild(svg);

  const n = data.nodes.length;
  const cx = W/2, cy = H/2;
  const rad = Math.min(W,H)/2 - (R+12);
  const pos = {};
  data.nodes.forEach((node, i) => {
    const ang = (i / Math.max(1, n)) * 2 * Math.PI;
    pos[String(node.id)] = { x: cx + rad*Math.cos(ang), y: cy + rad*Math.sin(ang) };
  });

  (data.links || []).forEach(link => {
    const a = pos[String(link.source)], b = pos[String(link.target)];
    if (!a || !b) return;
    const line = document.createElementNS(svgNS, 'line');
    line.setAttribute('x1', a.x); line.setAttribute('y1', a.y);
    line.setAttribute('x2', b.x); line.setAttribute('y2', b.y);
    line.setAttribute('stroke', LINK_COLOR);
    line.setAttribute('stroke-width', 1.5);
    line.setAttribute('opacity', '0.7');
    svg.appendChild(line);
  });

  data.nodes.forEach(node => {
    const p = pos[String(node.id)];
    const c = document.createElementNS(svgNS, 'circle');
    c.setAttribute('cx', p.x); c.setAttribute('cy', p.y);
    c.setAttribute('r', R);
    c.setAttribute('fill', NODE_COLOR);
    c.setAttribute('opacity', '0.95');
    svg.appendChild(c);
  });

  const note = document.createElement('p');
  note.style.margin = '6px 0 0';
  note.textContent = 'D3 no disponible. Fallback estático.';
  root.appendChild(note);
})();
"""
        parts.append("<script>\n" + (fallback_js % {
            "cid": cid,
            "data_json": data_json,
            "W": width, "H": height, "R": node_radius,
            "NODE_COLOR": node_color, "LINK_COLOR": link_color
        }) + "\n</script>\n")

    return HTML("".join(parts))


# usaremos js puro
# ---- Fuerzas sin D3 (mini física en JS puro) ----
import json, uuid
from IPython.display import HTML

def show_graph_force_vanilla(nodes, links, width=640, height=420, node_radius=8,
                             node_color="#1976d2", link_color="#999",
                             link_distance=70):
    """
    Grafo con layout de fuerzas *sin D3* (mini simulación) + interacciones:
    - Drag para arrastrar nodos.
    - Hover con tooltip (id y grado del nodo).
    """
    # Validación mínima
    if not isinstance(nodes, (list, tuple)) or not isinstance(links, (list, tuple)):
        raise TypeError("nodes y links deben ser listas/tuplas")
    for i, n in enumerate(nodes):
        if not isinstance(n, dict) or "id" not in n:
            raise ValueError(f"nodes[{i}] debe tener clave 'id'")

    node_ids = {str(n["id"]) for n in nodes}
    clean_links = []
    for j, e in enumerate(links):
        if not isinstance(e, dict) or "source" not in e or "target" not in e:
            raise ValueError(f"links[{j}] debe tener 'source' y 'target'")
        s, t = str(e["source"]), str(e["target"])
        if s in node_ids and t in node_ids:
            clean_links.append({"source": s, "target": t})

    data = {"nodes": nodes, "links": clean_links}
    import json, uuid
    data_json = json.dumps(data)
    cid = "ourlib-" + uuid.uuid4().hex

    from IPython.display import HTML
    html = """
<div id="%s" class="ourlib-graph"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui; position:relative;">
  <div class="viz"></div>
  <div class="tip" style="position:absolute; display:none; pointer-events:none; padding:4px 6px; background:#111; color:#fff; font-size:12px; border-radius:4px; box-shadow:0 2px 6px rgba(0,0,0,.2); transform:translate(12px, -8px);"></div>
</div>

<script>
(function(){
  const root = document.getElementById('%s');
  const viz  = root.querySelector('.viz');
  const tip  = root.querySelector('.tip');
  const data = %s;

  const W = %d, H = %d, R = %d;
  const NODE_COLOR = "%s";
  const LINK_COLOR = "%s";
  const LINK_DIST  = %d;

  // ===== SVG =====
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('width', W); svg.setAttribute('height', H);
  viz.appendChild(svg);

  // ===== Índices y grados =====
  const idx = new Map(); data.nodes.forEach((n,i)=>idx.set(String(n.id), i));
  const degree = new Array(data.nodes.length).fill(0);
  const edges = (data.links||[])
    .map(l=>({ s: idx.get(String(l.source)), t: idx.get(String(l.target)) }))
    .filter(e=> e.s!=null && e.t!=null);
  for (const e of edges){ degree[e.s]++; degree[e.t]++; }

  // ===== Estado de simulación =====
  const nodes = data.nodes.map((n,i)=>({
    id: String(n.id),
    x: Math.random()*W, y: Math.random()*H,
    vx: 0, vy: 0, fx: 0, fy: 0
  }));

  // ===== Elementos SVG =====
  const lines = edges.map(e=>{
    const ln = document.createElementNS(svgNS, 'line');
    ln.setAttribute('stroke', LINK_COLOR);
    ln.setAttribute('stroke-opacity', '0.7');
    ln.setAttribute('stroke-width', '1.5');
    svg.appendChild(ln);
    return ln;
  });

  const circles = nodes.map((n,i)=>{
    const c = document.createElementNS(svgNS, 'circle');
    c.setAttribute('r', R);
    c.setAttribute('fill', NODE_COLOR);
    c.setAttribute('opacity', '0.95');
    c.style.cursor = 'grab';
    c.dataset.index = String(i);
    svg.appendChild(c);
    return c;
  });

  // ===== Tooltip (hover) =====
  function showTip(i, clientX, clientY){
    tip.textContent = nodes[i].id + " · grado " + degree[i];
    const rect = root.getBoundingClientRect();
    tip.style.left = (clientX - rect.left + 12) + 'px';
    tip.style.top  = (clientY - rect.top  - 8) + 'px';
    tip.style.display = 'block';
  }
  function hideTip(){ tip.style.display = 'none'; }

  circles.forEach((c,i)=>{
    c.addEventListener('mouseenter', (e)=> showTip(i, e.clientX, e.clientY));
    c.addEventListener('mousemove',  (e)=> showTip(i, e.clientX, e.clientY));
    c.addEventListener('mouseleave', hideTip);
  });

  // ===== Drag (pointer events) =====
  let draggingIndex = null;
  let draggingActive = false;

  function toLocal(clientX, clientY){
    const rect = svg.getBoundingClientRect();
    return { x: clientX - rect.left, y: clientY - rect.top };
  }

  circles.forEach((c)=>{
    c.addEventListener('pointerdown', (e)=>{
      const i = Number(c.dataset.index);
      draggingIndex = i;
      draggingActive = true;
      c.setPointerCapture(e.pointerId);
      c.style.cursor = 'grabbing';
      const p = toLocal(e.clientX, e.clientY);
      nodes[i].x = p.x; nodes[i].y = p.y;
      nodes[i].vx = 0;  nodes[i].vy = 0;
      // Si la simulación estaba parada, reanudar
      requestAnimationFrame(step);
    });

    c.addEventListener('pointermove', (e)=>{
      if (draggingIndex===null) return;
      if (Number(c.dataset.index)!==draggingIndex) return;
      const p = toLocal(e.clientX, e.clientY);
      const n = nodes[draggingIndex];
      n.x = p.x; n.y = p.y; n.vx = 0; n.vy = 0;
    });

    c.addEventListener('pointerup', (e)=>{
      if (Number(c.dataset.index)!==draggingIndex) return;
      c.releasePointerCapture(e.pointerId);
      c.style.cursor = 'grab';
      draggingIndex = null;
      draggingActive = false;
    });

    c.addEventListener('pointercancel', ()=>{
      draggingIndex = null; draggingActive = false; c.style.cursor='grab';
    });
  });

  // ===== Parámetros de física =====
  const kSpring = 0.02;       // rigidez del resorte
  const kRepel  = 1500;       // fuerza de repulsión
  const damping = 0.85;       // amortiguación
  const centerK = 0.01;       // atracción al centro
  const dt      = 0.02;       // paso de tiempo

  function step(){
    // reset fuerzas
    for (const n of nodes){ n.fx=0; n.fy=0; }

    // resortes (aristas)
    for (let i=0;i<edges.length;i++){
      const e = edges[i];
      const a = nodes[e.s], b = nodes[e.t];
      let dx = b.x - a.x, dy = b.y - a.y;
      let dist = Math.hypot(dx, dy) || 0.001;
      const diff = dist - LINK_DIST;
      const F = kSpring * diff;
      const fx = F * dx / dist, fy = F * dy / dist;
      a.fx +=  fx; a.fy +=  fy;
      b.fx += -fx; b.fy += -fy;
    }

    // repulsión O(N^2)
    for (let i=0;i<nodes.length;i++){
      for (let j=i+1;j<nodes.length;j++){
        let dx = nodes[j].x - nodes[i].x;
        let dy = nodes[j].y - nodes[i].y;
        let d2 = dx*dx + dy*dy + 0.01;
        const inv = 1/Math.sqrt(d2);
        const F = kRepel / d2;
        const fx = F * dx * inv, fy = F * dy * inv;
        nodes[i].fx -= fx; nodes[i].fy -= fy;
        nodes[j].fx += fx; nodes[j].fy += fy;
      }
    }

    // integración (si se está arrastrando un nodo, no aplicar fuerzas a ese)
    for (let i=0;i<nodes.length;i++){
      const n = nodes[i];
      if (i !== draggingIndex){
        n.fx += centerK * (W/2 - n.x);
        n.fy += centerK * (H/2 - n.y);
        n.vx = (n.vx + n.fx * dt) * damping;
        n.vy = (n.vy + n.fy * dt) * damping;
        n.x  += n.vx;
        n.y  += n.vy;
      }
    }

    // actualizar SVG
    for (let i=0;i<edges.length;i++){
      const a = nodes[edges[i].s], b = nodes[edges[i].t];
      const ln = lines[i];
      ln.setAttribute('x1', a.x); ln.setAttribute('y1', a.y);
      ln.setAttribute('x2', b.x); ln.setAttribute('y2', b.y);
    }
    for (let i=0;i<nodes.length;i++){
      const c = circles[i], n = nodes[i];
      c.setAttribute('cx', n.x); c.setAttribute('cy', n.y);
    }

    // energía cinética
    let ke = 0;
    for (const n of nodes){ ke += n.vx*n.vx + n.vy*n.vy; }

    // si se está arrastrando, seguimos; si no, paramos cuando se estabiliza
    if (draggingActive || ke > 0.01) requestAnimationFrame(step);
  }

  // Etiqueta de modo
  const p = document.createElement('p');
  p.style.margin = '6px 0 0';
  p.textContent = 'show_graph_force_vanilla() · drag + tooltip';
  root.appendChild(p);

  // iniciar
  requestAnimationFrame(step);
})();
</script>
""" % (cid, cid, data_json, width, height, node_radius, node_color, link_color, link_distance)

    return HTML(html)



# agregamos la funcionalidad de check list
def show_graph_force_vanilla_checklist(
    nodes, links, width=640, height=420, node_radius=8,
    node_color="#1976d2", link_color="#999",
    link_distance=70
):
    """
    Grafo con fuerza *sin D3* + checklist mínimo:
    - Click (sin teclas): toggle 'completado' (oculta el nodo y sus aristas).
    - Shift + click: toggle 'sin_interes' (atenúa el nodo y sus vecinos).
    - Botones: Reset, Solo activos.
    *Todo vive en JS (no Py↔JS aún).*
    """
    # Validación mínima
    if not isinstance(nodes, (list, tuple)) or not isinstance(links, (list, tuple)):
        raise TypeError("nodes y links deben ser listas/tuplas")
    for i, n in enumerate(nodes):
        if not isinstance(n, dict) or "id" not in n:
            raise ValueError(f"nodes[{i}] debe tener clave 'id'")

    node_ids = {str(n["id"]) for n in nodes}
    clean_links = []
    for j, e in enumerate(links):
        if not isinstance(e, dict) or "source" not in e or "target" not in e:
            raise ValueError(f"links[{j}] debe tener 'source' y 'target'")
        s, t = str(e["source"]), str(e["target"])
        if s in node_ids and t in node_ids:
            clean_links.append({"source": s, "target": t})

    import json, uuid
    data = {"nodes": nodes, "links": clean_links}
    data_json = json.dumps(data)
    cid = "ourlib-" + uuid.uuid4().hex

    from IPython.display import HTML
    html = """
<div id="%s" class="ourlib-graph"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui; position:relative;">
  <div style="display:flex; gap:8px; align-items:center; margin-bottom:6px;">
    <button class="btn-reset">Reset</button>
    <button class="btn-actives">Solo activos</button>
    <span style="font-size:12px; color:#555;">Click: completado · Shift+Click: sin interés</span>
  </div>
  <div class="viz"></div>
  <div class="tip" style="position:absolute; display:none; pointer-events:none; padding:4px 6px; background:#111; color:#fff; font-size:12px; border-radius:4px; box-shadow:0 2px 6px rgba(0,0,0,.2); transform:translate(12px, -8px);"></div>
</div>

<script>
(function(){
  const root = document.getElementById('%s');
  const viz  = root.querySelector('.viz');
  const tip  = root.querySelector('.tip');
  const btnReset   = root.querySelector('.btn-reset');
  const btnActives = root.querySelector('.btn-actives');
  const data = %s;

  const W = %d, H = %d, R = %d;
  const NODE_COLOR = "%s";
  const LINK_COLOR = "%s";
  const LINK_DIST  = %d;

  // ===== SVG =====
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('width', W); svg.setAttribute('height', H);
  viz.appendChild(svg);

  // ===== Índices, grados, adyacencia =====
  const idx = new Map(); data.nodes.forEach((n,i)=>idx.set(String(n.id), i));
  const degree = new Array(data.nodes.length).fill(0);
  const adj = Array.from({length: data.nodes.length}, ()=> new Set());
  const edges = (data.links||[])
    .map(l=>({ s: idx.get(String(l.source)), t: idx.get(String(l.target)) }))
    .filter(e=> e.s!=null && e.t!=null);
  for (const e of edges){
    degree[e.s]++; degree[e.t]++;
    adj[e.s].add(e.t); adj[e.t].add(e.s);
  }

  // ===== Estado de simulación y checklist =====
  const nodes = data.nodes.map((n,i)=>({
    id: String(n.id),
    x: Math.random()*W, y: Math.random()*H,
    vx: 0, vy: 0, fx: 0, fy: 0
  }));

  const STATE = {
    NORMAL: 0,
    COMPLETADO: 1,
    SIN_INTERES: 2
  };
  const state = new Array(nodes.length).fill(STATE.NORMAL);

  // ===== Elementos SVG =====
  let curEdges = edges.slice(); // aristas visibles (cambia si hay completados)
  const lines = curEdges.map(e=>{
    const ln = document.createElementNS(svgNS, 'line');
    ln.setAttribute('stroke', LINK_COLOR);
    ln.setAttribute('stroke-opacity', '0.7');
    ln.setAttribute('stroke-width', '1.5');
    svg.appendChild(ln);
    return ln;
  });

  const circles = nodes.map((n,i)=>{
    const c = document.createElementNS(svgNS, 'circle');
    c.setAttribute('r', R);
    c.setAttribute('fill', NODE_COLOR);
    c.setAttribute('opacity', '0.95');
    c.style.cursor = 'grab';
    c.dataset.index = String(i);
    svg.appendChild(c);
    return c;
  });

  // ===== Tooltip =====
  function showTip(i, clientX, clientY){
    tip.textContent = nodes[i].id + " · grado " + degree[i];
    const rect = root.getBoundingClientRect();
    tip.style.left = (clientX - rect.left + 12) + 'px';
    tip.style.top  = (clientY - rect.top  - 8) + 'px';
    tip.style.display = 'block';
  }
  function hideTip(){ tip.style.display = 'none'; }

  circles.forEach((c,i)=>{
    c.addEventListener('mouseenter', (e)=> showTip(i, e.clientX, e.clientY));
    c.addEventListener('mousemove',  (e)=> showTip(i, e.clientX, e.clientY));
    c.addEventListener('mouseleave', hideTip);
  });

  // ===== Drag =====
  let draggingIndex = null;
  let draggingActive = false;
  function toLocal(clientX, clientY){
    const rect = svg.getBoundingClientRect();
    return { x: clientX - rect.left, y: clientY - rect.top };
  }
  circles.forEach((c)=>{
    c.addEventListener('pointerdown', (e)=>{
      const i = Number(c.dataset.index);
      draggingIndex = i; draggingActive = true;
      c.setPointerCapture(e.pointerId);
      c.style.cursor = 'grabbing';
      const p = toLocal(e.clientX, e.clientY);
      nodes[i].x = p.x; nodes[i].y = p.y;
      nodes[i].vx = 0;  nodes[i].vy = 0;
      requestAnimationFrame(step);
    });
    c.addEventListener('pointermove', (e)=>{
      if (draggingIndex===null) return;
      if (Number(c.dataset.index)!==draggingIndex) return;
      const p = toLocal(e.clientX, e.clientY);
      const n = nodes[draggingIndex];
      n.x = p.x; n.y = p.y; n.vx = 0; n.vy = 0;
    });
    c.addEventListener('pointerup', (e)=>{
      if (Number(c.dataset.index)!==draggingIndex) return;
      c.releasePointerCapture(e.pointerId);
      c.style.cursor = 'grab';
      draggingIndex = null; draggingActive = false;
    });
    c.addEventListener('pointercancel', ()=>{
      draggingIndex = null; draggingActive = false; c.style.cursor='grab';
    });
  });

  // ===== Checklist: click / shift+click =====
  function recomputeEdges(){
    // recalcular aristas visibles (oculta las que tocan un COMPLETADO)
    const vis = [];
    for (const e of edges){
      if (state[e.s] !== STATE.COMPLETADO && state[e.t] !== STATE.COMPLETADO){
        vis.push(e);
      }
    }
    // reemplazamos elementos SVG de líneas acorde
    while (lines.length) { const ln = lines.pop(); ln.remove(); }
    curEdges = vis;
    for (const e of curEdges){
      const ln = document.createElementNS(svgNS, 'line');
      ln.setAttribute('stroke', LINK_COLOR);
      ln.setAttribute('stroke-opacity', '0.7');
      ln.setAttribute('stroke-width', '1.5');
      svg.appendChild(ln);
      lines.push(ln);
    }
  }

  function applyStyles(){
    // nodos
    circles.forEach((c,i)=>{
      if (state[i] === STATE.COMPLETADO){
        c.style.display = 'none';
      } else {
        c.style.display = '';
        // atenuación por SIN_INTERES (nodo o vecinos)
        let muted = (state[i] === STATE.SIN_INTERES);
        if (!muted){
          for (const v of adj[i]){
            if (state[v] === STATE.SIN_INTERES){ muted = true; break; }
          }
        }
        c.setAttribute('opacity', muted ? '0.25' : '0.95');
      }
    });
    // líneas
    lines.forEach((ln, k)=>{
      const e = curEdges[k];
      const a = e.s, b = e.t;
      // Atenuar si alguno es SIN_INTERES o vecinos de uno SIN_INTERES
      const muteA = state[a]===STATE.SIN_INTERES || [...adj[a]].some(v=>state[v]===STATE.SIN_INTERES);
      const muteB = state[b]===STATE.SIN_INTERES || [...adj[b]].some(v=>state[v]===STATE.SIN_INTERES);
      const muted = muteA || muteB;
      ln.setAttribute('opacity', muted ? '0.25' : '0.7');
    });
  }

  function kick(){
    // “reactiva” la simulación un rato
    let frames = 60;
    function pump(){ if (frames-- > 0){ requestAnimationFrame(pump); } }
    requestAnimationFrame(pump);
  }

  circles.forEach((c,i)=>{
    c.addEventListener('click', (e)=>{
      if (e.shiftKey){
        // Shift+click => SIN_INTERES (toggle)
        state[i] = (state[i]===STATE.SIN_INTERES) ? STATE.NORMAL : STATE.SIN_INTERES;
      } else {
        // Click normal => COMPLETADO (toggle)
        state[i] = (state[i]===STATE.COMPLETADO) ? STATE.NORMAL : STATE.COMPLETADO;
        recomputeEdges();
      }
      applyStyles();
      kick();
    });
  });

  // Botones
  btnReset.addEventListener('click', ()=>{
    for (let i=0;i<state.length;i++) state[i]=STATE.NORMAL;
    recomputeEdges(); applyStyles(); kick();
  });
  btnActives.addEventListener('click', ()=>{
    // Oculta los COMPLETADO; los demás se muestran (quita SIN_INTERES)
    for (let i=0;i<state.length;i++){
      state[i] = (state[i]===STATE.COMPLETADO) ? STATE.COMPLETADO : STATE.NORMAL;
    }
    recomputeEdges(); applyStyles(); kick();
  });

  // ===== Física =====
  const kSpring = 0.02, kRepel = 1500, damping = 0.85, centerK = 0.01, dt = 0.02;

  function step(){
    // reset fuerzas
    for (const n of nodes){ n.fx=0; n.fy=0; }

    // resortes (solo en aristas visibles)
    for (let i=0;i<curEdges.length;i++){
      const e = curEdges[i];
      const a = nodes[e.s], b = nodes[e.t];
      let dx = b.x - a.x, dy = b.y - a.y;
      let dist = Math.hypot(dx, dy) || 0.001;
      const diff = dist - LINK_DIST;
      const F = kSpring * diff;
      const fx = F * dx / dist, fy = F * dy / dist;
      a.fx +=  fx; a.fy +=  fy;
      b.fx += -fx; b.fy += -fy;
    }

    // repulsión O(N^2) solo para nodos visibles
    const visibleIdx = [];
    for (let i=0;i<nodes.length;i++){
      if (state[i] !== STATE.COMPLETADO) visibleIdx.push(i);
    }
    for (let ii=0; ii<visibleIdx.length; ii++){
      const i = visibleIdx[ii];
      for (let jj=ii+1; jj<visibleIdx.length; jj++){
        const j = visibleIdx[jj];
        let dx = nodes[j].x - nodes[i].x;
        let dy = nodes[j].y - nodes[i].y;
        let d2 = dx*dx + dy*dy + 0.01;
        const inv = 1/Math.sqrt(d2);
        const F = kRepel / d2;
        const fx = F * dx * inv, fy = F * dy * inv;
        nodes[i].fx -= fx; nodes[i].fy -= fy;
        nodes[j].fx += fx; nodes[j].fy += fy;
      }
    }

    // integración
    for (let i=0;i<nodes.length;i++){
      if (state[i]===STATE.COMPLETADO) continue; // no mover completados (están ocultos)
      const n = nodes[i];
      n.fx += centerK * (W/2 - n.x);
      n.fy += centerK * (H/2 - n.y);
      n.vx = (n.vx + n.fx * dt) * damping;
      n.vy = (n.vy + n.fy * dt) * damping;
      n.x  += n.vx;
      n.y  += n.vy;
    }

    // actualizar SVG
    for (let i=0;i<curEdges.length;i++){
      const a = nodes[curEdges[i].s], b = nodes[curEdges[i].t];
      const ln = lines[i];
      ln.setAttribute('x1', a.x); ln.setAttribute('y1', a.y);
      ln.setAttribute('x2', b.x); ln.setAttribute('y2', b.y);
    }
    for (let i=0;i<nodes.length;i++){
      const c = circles[i], n = nodes[i];
      if (state[i]===STATE.COMPLETADO){ c.style.display='none'; continue; }
      c.style.display='';
      c.setAttribute('cx', n.x); c.setAttribute('cy', n.y);
    }

    // energía
    let ke = 0;
    for (const n of nodes){ ke += n.vx*n.vx + n.vy*n.vy; }
    if (draggingActive || ke > 0.01) requestAnimationFrame(step);
  }

  // Inicial
  function initialLayout(){
    // ponlos en círculo para evitar solapes iniciales fuertes
    const n = nodes.length, cx=W/2, cy=H/2, rad=Math.min(W,H)/2 - (R+12);
    for (let i=0;i<n;i++){
      const ang = (i / Math.max(1,n)) * 2 * Math.PI;
      nodes[i].x = cx + rad*Math.cos(ang);
      nodes[i].y = cy + rad*Math.sin(ang);
    }
  }
  initialLayout();
  recomputeEdges();
  applyStyles();
  requestAnimationFrame(step);
})();
</script>
""" % (cid, cid, data_json, width, height, node_radius, node_color, link_color, link_distance)

    return HTML(html)