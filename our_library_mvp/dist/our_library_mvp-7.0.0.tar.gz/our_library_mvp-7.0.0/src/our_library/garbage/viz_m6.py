# src/our_library/recommender.py

import os, joblib, pandas as pd, numpy as np
import json, uuid, math
from math import radians, sin, cos, asin, sqrt
from IPython.display import HTML

# --- ============================================= ---
# --- PARTE 1: LÓGICA DEL MOTOR (recs.py)           ---
# --- ============================================= ---

# Variables globales para los modelos cargados
tfidf = None
knn = None
df_recs = None # DataFrame global para el motor
MODEL_DIR_CACHE = None

def _find_col(df, options):
    """Encuentra la primera columna que exista en el df, ignorando mayúsculas/minúsculas."""
    df_cols_lower = {c.lower(): c for c in df.columns}
    for opt in options:
        if opt.lower() in df_cols_lower:
            return df_cols_lower[opt.lower()]
    return None

def haversine_km(lat1, lon1, lat2, lon2):
    vals = [lat1, lon1, lat2, lon2]
    if any(pd.isna(v) for v in vals): return np.nan
    R = 6371.0
    dlat, dlon = radians(lat2-lat1), radians(lon2-lon1)
    a = sin(dlat/2)**2 + cos(radians(lat1))*cos(radians(lat2))*sin(dlon/2)**2
    return 2 * R * asin(np.sqrt(a))

def load_recs(model_dir):
    """
    Carga los modelos y datos en las variables globales.
    """
    global tfidf, knn, df_recs, MODEL_DIR_CACHE
    if MODEL_DIR_CACHE == model_dir and tfidf is not None:
        print("Modelos ya cargados.")
        return

    print(f"Cargando modelos desde {model_dir}...")
    MODEL_DIR_CACHE = model_dir
    
    tfidf_path = os.path.join(model_dir, "tfidf.joblib")
    knn_path = os.path.join(model_dir, "knn.joblib")
    
    assert os.path.exists(tfidf_path), f"No se encontró {tfidf_path}"
    assert os.path.exists(knn_path), f"No se encontró {knn_path}"

    tfidf = joblib.load(tfidf_path)
    knn = joblib.load(knn_path)

    # 1. Cargar Parquet
    df_recs_path = os.path.join(model_dir, "recursos.parquet")
    assert os.path.exists(df_recs_path), f"No se encontró {df_recs_path}"
    df_recs = pd.read_parquet(df_recs_path)

    # 2. Validar y renombrar columnas (basado en tu .info())
    lat_col = _find_col(df_recs, ['LATITUD', 'latitud'])
    lon_col = _find_col(df_recs, ['LONGITUD', 'longitud'])
    code_col = _find_col(df_recs, ['CODE', 'codigo'])
    text_col = _find_col(df_recs, ['TEXT', 'nombre del recurso'])
    name_col = _find_col(df_recs, ['NOMBRE DEL RECURSO', 'nombre'])

    assert lat_col, "Falta la columna 'LATITUD' en recursos.parquet"
    assert lon_col, "Falta la columna 'LONGITUD' en recursos.parquet"
    assert code_col, "Falta la columna 'CODE' en recursos.parquet"
    assert text_col, "Falta la columna 'TEXT' o 'NOMBRE DEL RECURSO' en recursos.parquet"
    assert name_col, "Falta la columna 'NOMBRE DEL RECURSO' en recursos.parquet"
    
    # Renombrar a un estándar interno
    df_recs = df_recs.rename(columns={
        lat_col: "LATITUD",
        lon_col: "LONGITUD",
        code_col: "CODE",
        text_col: "TEXT",
        name_col: "NOMBRE DEL RECURSO"
    })

    df_recs["LATITUD"] = pd.to_numeric(df_recs["LATITUD"], errors="coerce")
    df_recs["LONGITUD"] = pd.to_numeric(df_recs["LONGITUD"], errors="coerce")
            
    # 3. Resetear índice para que .iloc funcione
    df_recs = df_recs.reset_index(drop=True)
    
    # 4. Crear la clave de MERGE (para el ancla)
    df_recs["CODIGO_CAT_KEY"] = df_recs["CODE"].astype(str).str.split('.').str[0].str.strip()

    print(f"Registros: {len(df_recs):,}")

def recs_ready():
    """Comprueba si los modelos están listos."""
    return tfidf is not None and knn is not None and df_recs is not None

def _check_ready():
    if not recs_ready():
        raise RuntimeError("Modelos no cargados. Llama a 'load_recs(MODEL_DIR)' primero.")

def _neighbors_by_vector(q_vec, n):
    _check_ready()
    n = min(n, len(df_recs))
    distances, indices = knn.kneighbors(q_vec, n_neighbors=n)
    return indices[0].tolist(), distances[0].tolist()

def _rankear(base_idx, idxs, dists, alpha=1.0, geo_km=None, rg_mode=None, rg_weight=0.05, **kwargs):
    _check_ready()
    sim = pd.Series(1.0 - np.array(dists), index=idxs)
    
    cand = df_recs.iloc[idxs].copy() 
    
    if base_idx is not None and base_idx in cand.index:
        cand = cand.drop(index=base_idx)
    cand["SIM_TEXT"] = cand.index.map(sim).astype(float)

    if "REGION_GEOGRAFICA" in df_recs.columns and base_idx is not None:
        base_rg = df_recs.loc[base_idx, "REGION_GEOGRAFICA"]
        if rg_mode == "filter":
            cand = cand[cand["REGION_GEOGRAFICA"] == base_rg].copy()
            cand["RG_BONUS"] = 0.0
        elif rg_mode == "bonus":
            cand["RG_BONUS"] = (cand["REGION_GEOGRAFICA"] == base_rg).astype(float)
        else: cand["RG_BONUS"] = 0.0
    else: cand["RG_BONUS"] = 0.0

    if geo_km is not None and base_idx is not None:
        lat0, lon0 = df_recs.loc[base_idx, "LATITUD"], df_recs.loc[base_idx, "LONGITUD"]
        if pd.notna(lat0) and pd.notna(lon0):
            cand["DIST_KM"] = cand.apply(lambda r: haversine_km(lat0, lon0, r["LATITUD"], r["LONGITUD"]), axis=1)
            cand["GEO_BONUS"] = (1.0 - cand["DIST_KM"]/float(geo_km)).clip(lower=0, upper=1)
        else: cand["DIST_KM"] = np.nan; cand["GEO_BONUS"] = 0.0
    else: cand["DIST_KM"] = np.nan; cand["GEO_BONUS"] = 0.0

    cand["SCORE"] = alpha*cand["SIM_TEXT"] + (1.0 - alpha)*cand["GEO_BONUS"] + rg_weight*cand["RG_BONUS"]
    
    return cand.sort_values("SCORE", ascending=False)

def recomendar_por_code(code, topk=10, **kwargs):
    _check_ready()
    m = df_recs.index[df_recs["CODE"].astype(str) == str(code)]
    if len(m)==0: raise ValueError(f"No existe CODE={code}")
    base_idx = int(m[0])
    
    q = tfidf.transform([df_recs.loc[base_idx, "TEXT"]])
    
    idxs, dists = _neighbors_by_vector(q, n=max(topk+1, 200))
    recs = _rankear(base_idx, idxs, dists, **kwargs)
    
    if kwargs.get("filter_cat"):  recs = recs[recs["CATEGORIA"].astype(str).str.contains(kwargs["filter_cat"],  case=False, na=False)]
    
    base_cols = ["CODE","NOMBRE DEL RECURSO","REGION"]
    base = df_recs.loc[base_idx, [c for c in base_cols if c in df_recs.columns]].to_dict()
    return base, recs.head(topk).reset_index(drop=True)

def recomendar_por_nombre(fragmento, topk=10, **kwargs):
    _check_ready()
    hits = df_recs[df_recs["NOMBRE DEL RECURSO"].astype(str).str.contains(str(fragmento), case=False, na=False)]
    if hits.empty: raise ValueError(f"No hallé nombres que contengan: {fragmento}")
    base_idx = int(hits.index[0])
    return recomendar_por_code(df_recs.loc[base_idx, "CODE"], topk, **kwargs)

def recomendar_por_texto_libre(query, topk=10, **kwargs):
    """
    Función principal del motor.
    """
    _check_ready()
    q = tfidf.transform([str(query).lower()])
    idxs, dists = _neighbors_by_vector(q, n=max(topk+1, 200))
    
    base_idx = None
    
    geo_anchor_code = kwargs.pop('geo_anchor_code', None) 
    if geo_anchor_code is not None:
        m = df_recs.index[df_recs["CODE"].astype(str) == str(geo_anchor_code)]
        base_idx = int(m[0]) if len(m) else None
        
    recs = _rankear(base_idx, idxs, dists, **kwargs) # kwargs ya no contiene geo_anchor_code

    if kwargs.get("filter_cat"):  recs = recs[recs["CATEGORIA"].astype(str).str.contains(kwargs["filter_cat"],  case=False, na=False)]

    return recs.head(topk).reset_index(drop=True)

# --- ALIASES PARA __init__.py ---
recs_recommend_code = recomendar_por_code
recs_recommend_nombre = recomendar_por_nombre
recs_recommend_texto = recomendar_por_texto_libre
recs_recommend = recomendar_por_texto_libre 

# --- ============================================= ---
# --- PARTE 2: LÓGICA DEL VISUALIZADOR (DASHBOARD)  ---
# --- ============================================= ---

def _get_catalog():
    """Helper para obtener el catálogo ya cargado."""
    _check_ready() # Asegura que load_recs() se haya llamado
    return df_recs # Devuelve el DF global del motor

def _prep_nodes_for_dashboard(df_ranked, catalog, anchor_code=None):
    """
    Prepara los nodos para el dashboard. NO filtra por geo.
    """
    df_temp = df_ranked.copy().reset_index(drop=True)
    nodes, anchor_node = [], None
    
    if anchor_code is not None:
        anchor_code_str = str(anchor_code).split('.')[0].strip()
        a = catalog.loc[catalog["CODIGO_CAT_KEY"] == anchor_code_str]
        if not a.empty:
            ar = a.iloc[0]
            anchor_node = {
                "id": f"anchor:{anchor_code_str}", "code": anchor_code_str,
                "name": (ar.get("NOMBRE DEL RECURSO") or f"CODE {ar['CODE']}"),
                "region": ar.get("REGION"), "categoria": ar.get("CATEGORIA"),
                "url": ar.get("URL"), "is_anchor": True, "score": 1.0
            }
            nodes.append(anchor_node)
            
    for _, r in df_temp.iterrows():
        nid = str(r.get("CODE", r.get("CODIGO", ""))).split('.')[0].strip()
        if not nid: continue
        
        if anchor_node and anchor_node["code"] == nid: continue
        
        nodes.append({
            "id": nid, "code": nid, "name": r.get("NOMBRE DEL RECURSO", r.get("NOMBRE")),
            "region": r.get("REGION"), "provincia": r.get("PROVINCIA"),
            "distrito": r.get("DISTRITO"), "categoria": r.get("CATEGORIA"),
            "tipo": r.get("TIPO_DE_CATEGORIA"), "subtipo": r.get("SUB_TIPO_CATEGORIA"),
            "url": r.get("URL"),
            "score": float(r.get("SCORE", 0.0)),
            "sim_text": float(r.get("SIM_TEXT", 0.0)),
            "dist_km": float(r.get("DIST_KM")) if pd.notna(r.get("DIST_KM")) else None,
            "is_anchor": False
        })
            
    return nodes

# --- ============================================= ---
# --- FUNCIÓN DE DASHBOARD (COMPLETA Y CORREGIDA)   ---
# --- ============================================= ---
def viz_recs_dashboard_d3(query, topk=15, model_dir="/content/models",
                           geo_anchor_code=None, geo_km=None, alpha=0.85):
    """
    Genera un dashboard D3 (SIN MAPA) con Burbujas, Barras y Lista.
    """
    
    # 1. Llamar al motor (las funciones están en este mismo archivo)
    motor_params = {
        "topk": topk, # Pedimos solo el topk que vamos a mostrar
        "alpha": alpha,
        "geo_anchor_code": geo_anchor_code,
        "geo_km": geo_km
    }
    try:
        raw_results = recomendar_por_texto_libre( query=str(query), **motor_params )
        print(f"--- DEBUG: Motor OK. {len(raw_results)} resultados 'raw' recibidos.")
    except Exception as e:
        print(f"❌ Error al llamar al motor 'recomendar_por_texto_libre': {e}")
        return

    if raw_results.empty:
        print(f"❌ No se encontraron resultados para la query: '{query}'")
        return HTML(f"<div style='text-align:center; padding:20px; color:#c0392b;'>No se encontraron recomendaciones para la consulta: <strong>'{query}'</strong></div>")

    # 2. Obtener el catálogo (ya está cargado en df_recs)
    catalog = _get_catalog()
    
    # 3. Preparar datos para D3 (ya no necesitamos filtrar por geo)
    # Rellenar nulos de REGION/CATEGORIA antes de pasarlos
    raw_results['REGION'] = raw_results['REGION'].fillna('Sin Región')
    raw_results['CATEGORIA'] = raw_results['CATEGORIA'].fillna('Sin Categoría')
    
    nodes = _prep_nodes_for_dashboard(raw_results, catalog, anchor_code=geo_anchor_code)
    
    if not nodes:
        print(f"❌ No se pudieron procesar los nodos para D3.")
        return
        
    print(f"--- DEBUG: Preparación de JSON OK. {len(nodes)} nodos se enviarán a D3.")

    data_json = json.dumps({ "nodes": nodes }, ensure_ascii=False)
    
    # 4. Preparar HTML/JS (Dashboard de 3 paneles)
    dash_id = f"dash-{uuid.uuid4().hex[:6]}"
    bubble_id = f"bubble-{uuid.uuid4().hex[:6]}"
    bar_id = f"bar-{uuid.uuid4().hex[:6]}"
    list_id = f"list-{uuid.uuid4().hex[:6]}"
    
    # --- INICIO DEL BLOQUE HTML (COMPLETO Y SIN CORTES) ---
    html = """
<style>
  #%(dash)s { width:100%%; max-width: 1200px; margin:auto; font-family: system-ui, sans-serif; }
  .dash-panel { border: 1px solid #ccc; border-radius: 8px; padding: 12px; background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
  .dash-panel h4 { margin: 0 0 10px; padding-bottom: 8px; border-bottom: 2px solid #eee; font-size: 16px; color: #333; }
  .dash-panel .chart-container { height: 400px; border: 1px solid #eee; position: relative; }
  .dash-panel .list-container { height: 400px; overflow: auto; border: 1px solid #eee; }
  .list-item { padding: 8px 10px; border-bottom: 1px solid #f0f0f0; cursor: pointer; transition: background-color 0.2s; }
  .list-item:hover { background-color: #f7f7ff; }
  .list-item.selected { background-color: #fffbe5; border-left: 3px solid #ffca28; }
  .list-item strong { display: block; color: #1565c0; font-size: 14px; }
  .list-item .meta { font-size: 12px; color: #555; }
  .list-item .loc { font-size: 12px; color: #777; }
  .list-item .score-dist { font-size: 11px; color: #444; margin-top: 4px; display: flex; gap: 10px; }
  .list-item .score { color: #d32f2f; font-weight: 500; }
  .list-item .dist { color: #0277bd; }
  .d3-tooltip { position: absolute; background: rgba(0,0,0,0.75); color: #fff; padding: 6px 10px; border-radius: 4px; font-size: 13px; pointer-events: none; opacity: 0; transition: opacity 0.2s; z-index: 10; }
  /* Estilos para D3 */
  .d3-bubble { cursor: pointer; transition: all 0.2s; }
  .d3-bubble:hover { stroke: #333; stroke-width: 2px; }
  .d3-bar { cursor: pointer; transition: all 0.2s; }
  .d3-bar:hover { fill-opacity: 0.7; }
  svg { overflow: visible; }
</style>
<div id="%(dash)s">
  <div style="margin-bottom: 16px;">
    <h3 style="margin:0; font-size: 22px;">Recomendaciones para: "%(q)s"</h3>
  </div>
  <div style="display:grid; grid-template-columns: 1.5fr 1fr; gap:16px;">
    <div style="display:grid; grid-template-rows: auto auto; gap:16px;">
      <div class="dash-panel">
        <h4 style="color:#ed6c02;">📊 ¿Qué encontramos? (por Categoría)</h4>
        <div id="%(bubble)s" class="chart-container" style="height: 350px;"></div>
      </div>
      <div class="dash-panel">
        <h4 style="color:#2e7d32;">🗺️ ¿Dónde están? (por Región)</h4>
        <div id="%(bar)s" class="chart-container" style="height: 350px;"></div>
      </div>
    </div>
    <div class="dash-panel">
      <h4 style="color:#1976d2;">📋 Lista de Resultados (Top %(k)s)</h4>
      <div id="%(list)s" class="list-container" style="height: 716px;"></div>
    </div>
  </div>
  <div id="%(dash)s-tooltip" class="d3-tooltip"></div>
</div>
<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script>
(function(){
  const data = %(data)s;
  const nodes = data.nodes || [];
  const byId = new Map(nodes.map(d => [String(d.id), d]));
  const tooltip = d3.select("#%(dash)s-tooltip");

  if (nodes.length === 0) {
    console.warn("D3.js: No hay nodos para dibujar.");
    return;
  }
  
  // Estado compartido
  const state = { selected: [] };
  
  // Colores
  const categories = Array.from(new Set(nodes.map(d => d.categoria || "Sin Categoría")));
  const colorCategory = d3.scaleOrdinal(d3.schemeTableau10).domain(categories);
  const regions = Array.from(new Set(nodes.map(d => d.region || "Sin Región")));
  const colorRegion = d3.scaleOrdinal(d3.schemeCategory10).domain(regions);

  // ================== CONTROLADOR ==================
  function setSelection(ids){
    const uniq = []; const seen = new Set();
    ids.map(String).forEach(id => { if(!seen.has(id)){ seen.add(id); uniq.push(id); }});
    state.selected = uniq;
    
    renderList();
    updateBubbleChart();
    updateBarChart();
  }
  function toggleOne(id){
    const s = new Set(state.selected.map(String)); const k = String(id);
    if (s.has(k)) s.delete(k); else s.add(k);
    setSelection(Array.from(s));
  }
  window.__our_viz_toggle_one = toggleOne; // Exponer para la lista

  // ================== LISTA ==================
  function renderList(){
    const host = document.getElementById("%(list)s"); if (!host) return;
    const selSet = new Set(state.selected.map(String));
    
    const items = nodes.filter(d => !d.is_anchor)
                       .sort((a,b) => b.score - a.score);

    const html = items.map(n => {
      const id = String(n.id);
      const name = (n.name || n.id);
      const url = n.url ? ('<a href="'+n.url+'" target="_blank" rel="noopener" onclick="event.stopPropagation();">Ver Ficha</a>') : '';
      const meta = [n.categoria, n.tipo, n.subtipo].filter(Boolean).join(" · ");
      const loc  = [n.region, n.provincia, n.distrito].filter(Boolean).join(" · ");
      const sc   = "Score: " + (n.score).toFixed(3);
      const km   = Number.isFinite(+n.dist_km) ? (n.dist_km).toFixed(1) + " km" : "";
      const selectedClass = selSet.has(id) ? "selected" : "";
      
      return '<div class="list-item '+selectedClass+'" onclick="window.__our_viz_toggle_one(\''+id+'\');">'
           + '<strong>'+name+'</strong>'
           + (meta? '<div class="meta">'+meta+'</div>' : '')
           + (loc?  '<div class="loc">'+loc+'</div>'  : '')
           + '<div class="score-dist">'
           + '<span class="score">'+sc+'</span>'
           + (km? '<span class="dist">'+km+'</span>' : '')
           + (url? '<span style="margin-left: auto;">'+url+'</span>' : '')
           + '</div></div>';
    }).join("");
    host.innerHTML = html || "<em>Sin elementos</em>";
  }

  // ================== GRÁFICO DE BURBUJAS (Categoría) ==================
  let bubbleNodes;
  (function initBubbleChart(){
    const host = document.getElementById("%(bubble)s");
    const W = host.clientWidth, H = 350;
    const svg = d3.select(host).append("svg").attr("width", W).attr("height", H);

    const nodes_data = nodes.filter(d => !d.is_anchor);
    const counts = d3.rollups(nodes_data, v => v.length, d => d.categoria || "Sin Categoría");
    const hierData = { children: counts.map(([name, count]) => ({ name, count })) };

    const root = d3.hierarchy(hierData).sum(d => d.count || 0).sort((a,b) => b.value - a.value);
    const pack = d3.pack().size([W - 5, H - 5]).padding(5);
    const packedRoot = pack(root);

    bubbleNodes = svg.selectAll("g.bubble").data(packedRoot.leaves()).join("g")
      .attr("class", "bubble d3-bubble")
      .attr("transform", d => `translate(${d.x},${d.y})`)
      .on("click", (ev, d) => {
          const cat = d.data.name;
          const ids = nodes_data.filter(n => (n.categoria || "Sin Categoría") === cat).map(n => n.id);
          setSelection(ids);
      })
      .on("mouseover", (ev, d) => { 
         tooltip.style("opacity", 1).html(d.data.name + "<br/>" + d.data.count + " encontrado(s)"); 
      })
      .on("mousemove", (ev) => { 
         tooltip.style("left", (ev.pageX + 15) + "px").style("top", (ev.pageY - 20) + "px"); 
      })
      .on("mouseout", () => { 
         tooltip.style("opacity", 0); 
      });

    bubbleNodes.append("circle")
      .attr("r", d => d.r)
      .attr("fill", d => colorCategory(d.data.name))
      .attr("stroke", "#fff").attr("stroke-width", 1.5)
      .attr("fill-opacity", 0.8);

    bubbleNodes.append("text")
      .attr("dy", "0.3em").style("text-anchor", "middle")
      .style("font-size", d => Math.max(8, d.r / 4) + "px")
      .style("fill", "#111").style("pointer-events", "none")
      .text(d => d.data.name);
  })();
  
  function updateBubbleChart(){
    if (!bubbleNodes) return;
    const sel = state.selected;
    if (sel.length === 0) {
        bubbleNodes.attr("opacity", 1.0);
        return;
    }
    const selCats = new Set(sel.map(id => byId.get(String(id))?.categoria || "Sin Categoría"));
    bubbleNodes.attr("opacity", d => selCats.has(d.data.name) ? 1.0 : 0.25);
  }

  // ================== GRÁFICO DE BARRAS (Región) ==================
  let bars;
  (function initBarChart(){
    const host = document.getElementById("%(bar)s");
    const W_full = host.clientWidth, H_full = 350;
    const margin = { top: 10, right: 20, bottom: 20, left: 120 };
    const W = W_full - margin.left - margin.right;
    const H = H_full - margin.top - margin.bottom;
    
    const svg = d3.select(host).append("svg").attr("width", W_full).attr("height", H_full);
    const g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    const nodes_data = nodes.filter(d => !d.is_anchor);
    const counts_raw = d3.rollups(nodes_data, v => v.length, d => d.region || "Sin Región");
    const counts = counts_raw.map(([name, count]) => ({ name, count })).sort((a,b) => b.count - a.count);

    const x = d3.scaleLinear()
      .domain([0, d3.max(counts, d => d.count)]).nice()
      .range([0, W]);
      
    const y = d3.scaleBand()
      .domain(counts.map(d => d.name))
      .range([0, H])
      .padding(0.1);

    g.append("g").call(d3.axisLeft(y).tickSize(0)).select(".domain").remove();
    g.append("g").attr("transform", "translate(0," + H + ")").call(d3.axisBottom(x).ticks(Math.max(2, x.domain()[1])));

    bars = g.selectAll("rect").data(counts).join("rect")
      .attr("class", "d3-bar")
      .attr("y", d => y(d.name))
      .attr("width", d => x(d.count))
      .attr("height", y.bandwidth())
      .attr("fill", d => colorRegion(d.name))
      .on("click", (ev, d) => {
          const region = d.name;
          const ids = nodes_data.filter(n => (n.region || "Sin Región") === region).map(n => n.id);
          setSelection(ids);
      })
      .on("mouseover", (ev, d) => { 
         tooltip.style("opacity", 1).html(d.name + "<br/>" + d.count + " encontrado(s)"); 
      })
      .on("mousemove", (ev) => { 
         tooltip.style("left", (ev.pageX + 15) + "px").style("top", (ev.pageY - 20) + "px"); 
      })
      .on("mouseout", () => { 
         tooltip.style("opacity", 0); 
      });
  })();
  
  function updateBarChart(){
    if (!bars) return;
    const sel = state.selected;
    if (sel.length === 0) {
        bars.attr("opacity", 1.0);
        return;
    }
    const selRegions = new Set(sel.map(id => byId.get(String(id))?.region || "Sin Región"));
    bars.attr("opacity", d => selRegions.has(d.name) ? 1.0 : 0.25);
  }

  // ================== INICIALIZAR ==================
  setSelection([]);
})();
</script>
""" % {
        "dash": dash_id, "bubble": bubble_id, "bar": bar_id, "list": list_id,
        "k": topk, 
        "q": str(query), 
        "data": data_json
    }
    # --- FIN DEL BLOQUE HTML ---
    
    return HTML(html)