# src/our_library/turismo_extra_charts.py

from __future__ import annotations

import json
import unicodedata
import uuid
from pathlib import Path
from typing import Optional

import pandas as pd
from IPython.display import HTML


# ----------------- Helpers comunes ----------------- #

def _normalize_region(name: Optional[str]) -> str:
    """Normaliza nombres de región/departamento: quita tildes, mayúsculas."""
    if name is None:
        return ""
    s = str(name).strip()
    if not s:
        return ""
    s = unicodedata.normalize("NFD", s)
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return s.upper()


def _ensure_path(path: str | Path) -> Path:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"No encuentro el archivo: {p}")
    return p


# =========================================================
#  1) Acceso a la capital regional · Modos de transporte
# =========================================================

def show_transport_access(
    csv_path: str | Path,
    highlight_region: Optional[str] = None,
) -> HTML:
    """
    Visualización D3:

      - Matriz Departamento × Modo (Avión/Bus/Tren/Barco).
      - Cada celda es un círculo ⇒ "Sí" (color por modo) o "No" (gris).
      - Clic en departamento muestra detalle en un panel lateral.

    Parámetros
    ----------
    csv_path : ruta al CSV `acceso_capital_departamento_transportes_SI_NO.csv`
    highlight_region : nombre de departamento/región a resaltar (opcional),
                       se compara sin tildes y sin distinguir mayúsculas.
    """
    csv_path = _ensure_path(csv_path)
    df = pd.read_csv(csv_path)

    # Esperamos columnas como:
    # Departamento, Avión, Bus, Tren, Barco
    if "Departamento" not in df.columns:
        raise ValueError("Se esperaba una columna 'Departamento' en el CSV.")

    mode_cols = [c for c in df.columns if c != "Departamento"]
    if not mode_cols:
        raise ValueError("No encontré columnas de modos de transporte (Avión/Bus/Tren/Barco).")

    df["norm"] = df["Departamento"].map(_normalize_region)
    highlight_norm = _normalize_region(highlight_region) if highlight_region else None

    rows = []
    for _, r in df.iterrows():
        modes = []
        for m in mode_cols:
            val = str(r[m]).strip().lower()
            has_mode = val in ("si", "sí", "yes", "true", "1")
            modes.append({"mode": m, "has": bool(has_mode)})
        rows.append(
            {
                "dept": str(r["Departamento"]),
                "norm": str(r["norm"]),
                "modes": modes,
            }
        )

    payload = {
        "rows": rows,
        "modes": mode_cols,
        "highlight": highlight_norm,
    }

    data_json = json.dumps(payload, ensure_ascii=False)
    chart_id = f"transport-{uuid.uuid4().hex}"

    template = """
<div id="[CHART_ID]" style="width:100%; max-width:900px; margin:10px auto; font-family:system-ui;">
  <h3 style="margin:0 0 8px;">Acceso a la capital regional · Modos de transporte</h3>
  <p style="margin:0 0 10px; font-size:12px; color:#555;">
    Cada fila es un departamento. Cada columna, un modo de transporte. Los círculos llenos indican que puedes llegar usando ese modo.
  </p>
  <div style="display:flex; gap:16px; align-items:flex-start;">
    <div id="[CHART_ID]-svg" style="flex:1 1 auto; min-height:360px;"></div>
    <div id="[CHART_ID]-panel" style="width:260px; font-size:12px; background:#f8f9fa; border-radius:8px; padding:8px 10px; border:1px solid #e0e0e0;">
      <strong>Detalle de la selección</strong>
      <div id="[CHART_ID]-panel-body" style="margin-top:6px; line-height:1.4;">
        Haz clic en un departamento para ver sus combinaciones de transporte.
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script>
(function() {
  const payload = [DATA];
  const rows = payload.rows || [];
  const modes = payload.modes || [];
  const highlightNorm = payload.highlight || null;

  const rootId = "[CHART_ID]";
  const svgHost = document.getElementById(rootId + "-svg");
  const panelBody = document.getElementById(rootId + "-panel-body");
  if (!svgHost || !panelBody) return;

  const margin = { top: 30, right: 20, bottom: 30, left: 120 };
  const width = svgHost.clientWidth || 600;
  const height = Math.max(60 + rows.length * 22, 220);

  const svg = d3.select(svgHost)
    .append("svg")
    .attr("width", width)
    .attr("height", height);

  const g = svg.append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

  const innerWidth  = width  - margin.left - margin.right;
  const innerHeight = height - margin.top  - margin.bottom;

  const deptNames = rows.map(r => r.dept);
  const y = d3.scaleBand()
    .domain(deptNames)
    .range([0, innerHeight])
    .padding(0.2);

  const x = d3.scaleBand()
    .domain(modes)
    .range([0, innerWidth])
    .padding(0.2);

  const modeColor = d3.scaleOrdinal()
    .domain(modes)
    .range(["#1565c0", "#ef6c00", "#2e7d32", "#6a1b9a"]);

  // Fondo suave
  g.append("rect")
    .attr("x", -margin.left + 10)
    .attr("y", -margin.top + 5)
    .attr("width", width - 20)
    .attr("height", height - 20)
    .attr("fill", "#fafbff")
    .attr("rx", 10);

  // Eje X
  g.append("g")
    .attr("transform", `translate(0,${innerHeight})`)
    .call(d3.axisBottom(x))
    .selectAll("text")
    .attr("font-size", 11);

  // Eje Y
  g.append("g")
    .call(d3.axisLeft(y))
    .selectAll("text")
    .attr("font-size", 11)
    .attr("font-weight", d => {
      const row = rows.find(r => r.dept === d);
      return (row && row.norm === highlightNorm) ? "bold" : "normal";
    });

  // Datos planos (dept × modo)
  const flat = [];
  rows.forEach(r => {
    (r.modes || []).forEach(m => {
      flat.push({
        dept: r.dept,
        norm: r.norm,
        mode: m.mode,
        has: !!m.has
      });
    });
  });

  const rowByDept = new Map(rows.map(r => [r.dept, r]));

  const cells = g.selectAll("circle.cell")
    .data(flat)
    .join("circle")
    .attr("class", "cell")
    .attr("cx", d => (x(d.mode) || 0) + x.bandwidth() / 2)
    .attr("cy", d => (y(d.dept) || 0) + y.bandwidth() / 2)
    .attr("r", d => d.has ? Math.min(x.bandwidth(), y.bandwidth()) / 2.2
                           : Math.min(x.bandwidth(), y.bandwidth()) / 3.2)
    .attr("fill", d => d.has ? modeColor(d.mode) : "#e0e0e0")
    .attr("fill-opacity", d => d.has ? 0.95 : 0.3)
    .attr("stroke", d => {
      if (!highlightNorm) return "#ffffff";
      return d.norm === highlightNorm ? "#000" : "#ffffff";
    })
    .attr("stroke-width", d => (d.norm === highlightNorm ? 1.6 : 1.0))
    .style("cursor", "pointer")
    .on("click", (_, d) => {
      const row = rowByDept.get(d.dept);
      if (row) renderPanel(row);
    });

  function renderPanel(row) {
    const modesSorted = (row.modes || []).slice()
      .sort((a, b) => d3.ascending(a.mode, b.mode));

    const yes = modesSorted.filter(m => m.has);
    const no  = modesSorted.filter(m => !m.has);

    const yesList = yes.length
      ? `<ul style="padding-left:16px; margin:4px 0;">${
          yes.map(m => `<li>${m.mode}</li>`).join("")
        }</ul>`
      : "<em>No tiene conexión directa registrada.</em>";

    const noList = no.length
      ? `<ul style="padding-left:16px; margin:4px 0;">${
          no.map(m => `<li>${m.mode}</li>`).join("")
        }</ul>`
      : "<em>Tiene todos los modos listados.</em>";

    panelBody.innerHTML = `
      <div style="font-size:13px; margin-bottom:4px;">
        <strong>${row.dept}</strong>
      </div>
      <div style="margin-bottom:4px;">
        <span style="font-size:11px; color:#666;">Modos disponibles:</span>
        ${yesList}
      </div>
      <div>
        <span style="font-size:11px; color:#666;">No disponibles:</span>
        ${noList}
      </div>
    `;
  }

  // Autoselección si hay región destacada
  if (highlightNorm) {
    const row = rows.find(r => r.norm === highlightNorm);
    if (row) renderPanel(row);
  }
})();
</script>
"""

    html = template.replace("[CHART_ID]", chart_id).replace("[DATA]", data_json)
    return HTML(html)


# =========================================================
#  2) Denuncias 2024 por mes · Dashboard interactivo
# =========================================================

def show_crime_monthly_dashboard(
    csv_path: str | Path,
    region: Optional[str] = None,
) -> HTML:
    """
    Dashboard D3 para `denuncias_2024_por_mes_wide.csv`:

      - Selector de región.
      - Gráfico principal de línea + "barras de calor" por mes para la región
        seleccionada.
      - Panel lateral con resumen (total anual, mes pico, etc.).

    El CSV se espera en formato ancho:
      MES, AMAZONAS, ANCASH, APURIMAC, ..., UCAYALI
    """
    csv_path = _ensure_path(csv_path)
    df = pd.read_csv(csv_path)

    if "MES" not in df.columns:
        raise ValueError("Se esperaba una columna 'MES' con el número de mes (1-12).")

    month_col = "MES"
    region_cols = [c for c in df.columns if c != month_col]

    regions_meta = [{"name": c, "norm": _normalize_region(c)} for c in region_cols]

    series = []
    global_min = None
    global_max = None

    for col, meta in zip(region_cols, regions_meta):
        vals = []
        for _, row in df.iterrows():
            m = int(row[month_col])
            v = float(row[col])
            vals.append({"month": m, "value": v})
            if global_min is None or v < global_min:
                global_min = v
            if global_max is None or v > global_max:
                global_max = v
        series.append(
            {
                "region": meta["name"],
                "norm": meta["norm"],
                "values": vals,
            }
        )

    if global_min is None:
        global_min = 0.0
    if global_max is None:
        global_max = 1.0

    target_norm = _normalize_region(region) if region else None
    if target_norm and not any(s["norm"] == target_norm for s in series):
        target_norm = None

    payload = {
        "series": series,
        "regions": regions_meta,
        "globalMin": global_min,
        "globalMax": global_max,
        "defaultRegionNorm": target_norm,
    }

    data_json = json.dumps(payload, ensure_ascii=False)
    chart_id = f"crime-{uuid.uuid4().hex}"

    template = """
<div id="[CHART_ID]" style="width:100%; max-width:1000px; margin:10px auto; font-family:system-ui;">
  <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom:8px;">
    <h3 style="margin:0;">Denuncias 2024 · Serie mensual por región</h3>
    <div style="font-size:12px;">
      Región:
      <select id="[CHART_ID]-select" style="font-size:12px; padding:2px 4px;"></select>
    </div>
  </div>
  <p style="margin:0 0 8px; font-size:12px; color:#555;">
    El color de fondo por mes refleja la intensidad relativa de denuncias; la línea muestra la evolución mensual.
  </p>
  <div style="display:flex; gap:16px; align-items:stretch;">
    <div id="[CHART_ID]-svg" style="flex:1 1 auto; min-height:360px;"></div>
    <div id="[CHART_ID]-sidebar" style="width:260px; font-size:12px; background:#f8f9fa; border-radius:8px; padding:8px 10px; border:1px solid #e0e0e0;">
      <strong>Resumen anual</strong>
      <div id="[CHART_ID]-sidebar-body" style="margin-top:6px; line-height:1.4;">
        Selecciona una región para ver su resumen.
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script>
(function() {
  const payload = [DATA];
  const series = payload.series || [];
  const regions = payload.regions || [];
  const globalMin = payload.globalMin ?? 0;
  const globalMax = payload.globalMax ?? 1;
  const defaultNorm = payload.defaultRegionNorm || (regions[0] && regions[0].norm);

  const rootId = "[CHART_ID]";
  const svgHost = document.getElementById(rootId + "-svg");
  const sidebar = document.getElementById(rootId + "-sidebar-body");
  const select = document.getElementById(rootId + "-select");
  if (!svgHost || !sidebar || !select || !series.length) return;

  // Llenar el selector
  regions.forEach(r => {
    const opt = document.createElement("option");
    opt.value = r.norm;
    opt.textContent = r.name;
    select.appendChild(opt);
  });

  const margin = { top: 30, right: 20, bottom: 40, left: 60 };
  const width = svgHost.clientWidth || 640;
  const height = 380;

  const svg = d3.select(svgHost)
    .append("svg")
    .attr("width", width)
    .attr("height", height);

  const g = svg.append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

  const innerWidth  = width  - margin.left - margin.right;
  const innerHeight = height - margin.top  - margin.bottom;

  const months = d3.range(1, 13);
  const monthLabels = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];

  const x = d3.scaleBand()
    .domain(months)
    .range([0, innerWidth])
    .padding(0.15);

  const y = d3.scaleLinear()
    .range([innerHeight, 0]);

  const color = d3.scaleSequential(d3.interpolateOrRd)
    .domain([globalMin, globalMax]);

  const xAxisG = g.append("g")
    .attr("transform", `translate(0,${innerHeight})`)
    .call(
      d3.axisBottom(x)
        .tickFormat(m => monthLabels[m - 1])
    )
    .selectAll("text")
    .attr("font-size", 11);

  const yAxisG = g.append("g");

  g.append("text")
    .attr("x", innerWidth / 2)
    .attr("y", innerHeight + 32)
    .attr("text-anchor", "middle")
    .attr("font-size", 11)
    .text("Mes");

  const yLabel = g.append("text")
    .attr("x", -innerHeight / 2)
    .attr("y", -46)
    .attr("transform", "rotate(-90)")
    .attr("text-anchor", "middle")
    .attr("font-size", 11)
    .text("Denuncias registradas");

  // Rectángulos de fondo por mes (se recolorean según la región seleccionada)
  const bgRects = g.selectAll("rect.bg-month")
    .data(months)
    .join("rect")
    .attr("class", "bg-month")
    .attr("x", m => x(m))
    .attr("width", x.bandwidth())
    .attr("y", 0)
    .attr("height", innerHeight)
    .attr("fill", "#f5f5f5")
    .attr("fill-opacity", 0.4);

  const line = d3.line()
    .x(d => (x(d.month) || 0) + x.bandwidth() / 2)
    .y(d => y(d.value))
    .curve(d3.curveMonotoneX);

  const linePath = g.append("path")
    .attr("fill", "none")
    .attr("stroke", "#0d47a1")
    .attr("stroke-width", 2);

  const pointGroup = g.append("g");

  function getSeriesByNorm(norm) {
    return series.find(s => s.norm === norm) || series[0];
  }

  function update(norm) {
    const s = getSeriesByNorm(norm);
    const vals = (s && s.values) ? s.values.slice().sort((a, b) => a.month - b.month) : [];

    const localMax = d3.max(vals, d => d.value) || globalMax || 1;
    const yMax = Math.max(localMax * 1.1, (globalMax || localMax) * 0.4);
    y.domain([0, yMax]).nice();

    yAxisG.transition().duration(400).call(d3.axisLeft(y).ticks(5));

    const byMonth = new Map(vals.map(d => [d.month, d.value]));

    bgRects
      .transition().duration(400)
      .attr("fill", m => {
        const v = byMonth.get(m);
        if (v == null) return "#f5f5f5";
        return color(v);
      })
      .attr("fill-opacity", m => (byMonth.get(m) == null ? 0.3 : 0.7));

    linePath
      .datum(vals)
      .transition().duration(450)
      .attr("d", line);

    const pts = pointGroup.selectAll("circle.point")
      .data(vals, d => d.month);

    pts.join(
      enter => enter.append("circle")
        .attr("class", "point")
        .attr("r", 3.5)
        .attr("cx", d => (x(d.month) || 0) + x.bandwidth() / 2)
        .attr("cy", d => y(d.value))
        .attr("fill", "#0d47a1"),
      update => update
        .transition().duration(450)
        .attr("cx", d => (x(d.month) || 0) + x.bandwidth() / 2)
        .attr("cy", d => y(d.value)),
      exit => exit.remove()
    );

    // Sidebar resumen
    const total = d3.sum(vals, d => d.value);
    const maxItem = vals.reduce((acc, d) => (d.value > acc.value ? d : acc), { month: null, value: -Infinity });
    const minItem = vals.reduce((acc, d) => (d.value < acc.value ? d : acc), { month: null, value: Infinity });

    const maxLabel = maxItem.month ? monthLabels[maxItem.month - 1] : "–";
    const minLabel = minItem.month ? monthLabels[minItem.month - 1] : "–";

    sidebar.innerHTML = `
      <div style="font-size:13px; margin-bottom:4px;">
        <strong>${s.region}</strong>
      </div>
      <div style="margin-bottom:3px;">
        <span style="font-size:11px; color:#666;">Total anual:</span>
        <br><strong>${total.toLocaleString("es-PE")}</strong> denuncias
      </div>
      <div style="margin-bottom:3px;">
        <span style="font-size:11px; color:#666;">Mes más crítico:</span>
        <br><strong>${maxLabel}</strong> (${maxItem.value.toLocaleString("es-PE")})
      </div>
      <div>
        <span style="font-size:11px; color:#666;">Mes más bajo:</span>
        <br><strong>${minLabel}</strong> (${minItem.value.toLocaleString("es-PE")})
      </div>
    `;
  }

  // Eventos
  select.addEventListener("change", e => {
    update(e.target.value);
  });

  const initNorm = defaultNorm || (regions[0] && regions[0].norm);
  if (initNorm) {
    select.value = initNorm;
    update(initNorm);
  } else {
    update(regions[0].norm);
  }
})();
</script>
"""

    html = template.replace("[CHART_ID]", chart_id).replace("[DATA]", data_json)
    return HTML(html)


# =========================================================
#  3) Girasol de temperatura mensual por región (clima)
# =========================================================

# dentro de src/our_library/turismo_extra_charts.py
import json
import uuid
from pathlib import Path
import pandas as pd
from IPython.display import HTML


def show_temperature_sunflower(
    csv_path: str,
    region: str | None = None,
    date_col: str = "time",
    region_col: str = "REGION",
    tmax_col: str = "temperature_2m_max (°C)",
    tmin_col: str = "temperature_2m_min (°C)",
):
    """
    Girasol térmico:
      - Vista inicial: 1 pétalo por MES (longitud = Tmax media del mes, color = intensidad de calor).
      - Al hacer click en un pétalo de mes: se abre la vista de DÍAS de ese mes (1 pétalo por día).
      - Click en el centro de la flor: vuelve a vista de meses.
    """
    csv_path = Path(csv_path)
    if not csv_path.exists():
        raise FileNotFoundError(f"No encuentro el CSV de clima: {csv_path}")

    df = pd.read_csv(csv_path)

    # Validar columnas
    missing = [c for c in (date_col, region_col, tmax_col, tmin_col) if c not in df.columns]
    if missing:
        raise ValueError(f"Faltan columnas requeridas en el CSV de clima: {missing}")

    # Parsear fecha
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
    df = df.dropna(subset=[date_col])

    # Filtro por región (case-insensitive)
    if region is not None:
        mask = df[region_col].astype(str).str.upper() == str(region).upper()
        df_reg = df[mask].copy()
        if df_reg.empty:
            raise ValueError(
                f"No hallé registros para la región '{region}' "
                f"usando la columna {region_col}."
            )
    else:
        df_reg = df.copy()

    # Normalizar nombres de columnas para enviar al JS
    df_reg["month"] = df_reg[date_col].dt.month
    df_reg["day"] = df_reg[date_col].dt.day
    df_reg["date_str"] = df_reg[date_col].dt.strftime("%Y-%m-%d")

    df_reg["tmax"] = pd.to_numeric(df_reg[tmax_col], errors="coerce")
    df_reg["tmin"] = pd.to_numeric(df_reg[tmin_col], errors="coerce")
    df_reg = df_reg.dropna(subset=["tmax", "tmin"])

    if df_reg.empty:
        raise ValueError("Después de limpiar tmax/tmin no quedó data para dibujar el girasol.")

    # --- Agregados mensuales (para vista 'mes') ---
    month_names = {
        1: "Enero", 2: "Febrero", 3: "Marzo", 4: "Abril",
        5: "Mayo", 6: "Junio", 7: "Julio", 8: "Agosto",
        9: "Septiembre", 10: "Octubre", 11: "Noviembre", 12: "Diciembre",
    }

    monthly = (
        df_reg.groupby("month")
        .agg(
            tmax_mean=("tmax", "mean"),
            tmin_mean=("tmin", "mean"),
            tmax_max=("tmax", "max"),
            tmin_min=("tmin", "min"),
            n_days=("tmax", "size"),
        )
        .reset_index()
    )
    monthly["month_name"] = monthly["month"].map(month_names)

    monthly_data = monthly.to_dict(orient="records")
    daily_data = df_reg[["month", "day", "date_str", "tmax", "tmin"]].to_dict(orient="records")

    region_label = str(region or df_reg[region_col].astype(str).iloc[0])

    payload = {
        "region": region_label,
        "monthly": monthly_data,
        "daily": daily_data,
    }
    data_json = json.dumps(payload, ensure_ascii=False, default=float)

    sun_id = f"sun-{uuid.uuid4().hex}"

    html = f"""
<div style="border:3px solid #ffb300; border-radius:16px; padding:10px; max-width:900px;">
  <h3 style="margin:4px 0 6px;">Clima · Girasol térmico — {region_label}</h3>
  <p style="margin:0 0 8px; font-size:12px;">
    Vista inicial: cada pétalo es un <strong>mes</strong> (longitud = temperatura máxima media,
    color = intensidad de calor).<br>
    Haz clic en un pétalo para ver los <strong>días</strong> de ese mes como pétalos individuales.
    Haz clic en el <strong>centro</strong> para volver a la vista por meses.
  </p>
  <div id="{sun_id}" style="width:100%; height:600px;"></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script src="https://cdn.jsdelivr.net/npm/d3-scale-chromatic@3"></script>

<script>
(function(){{
  const hostId = "{sun_id}";
  const payload = {data_json};

  const container = document.getElementById(hostId);
  const W = container.clientWidth || 800;
  const H = 560;

  const svg = d3.select(container)
    .append("svg")
    .attr("width", W)
    .attr("height", H);

  const cx = W / 2;
  const cy = H / 2 - 30;
  const coreRadius = 40;

  // --------- Tallo y hojas decorativas ----------
  const stemTopY = cy + coreRadius;
  const stemHeight = 170;

  svg.append("rect")
    .attr("x", cx - 8)
    .attr("y", stemTopY)
    .attr("width", 16)
    .attr("height", stemHeight)
    .attr("rx", 8)
    .attr("fill", "#66bb6a")
    .attr("opacity", 0.9);

  // Hoja izquierda
  const leafLeftPath =
    "M " + (cx - 55) + " " + (stemTopY + 70) +
    " Q " + (cx - 110) + " " + (stemTopY + 25) + " " + (cx - 25) + " " + (stemTopY + 5) +
    " Q " + (cx - 70)  + " " + (stemTopY + 55) + " " + (cx - 20) + " " + (stemTopY + 80) +
    " Z";

  svg.append("path")
    .attr("d", leafLeftPath)
    .attr("fill", "#81c784")
    .attr("opacity", 0.9);

  // Hoja derecha (simétrica)
  const leafRightPath =
    "M " + (cx + 55) + " " + (stemTopY + 70) +
    " Q " + (cx + 110) + " " + (stemTopY + 25) + " " + (cx + 25) + " " + (stemTopY + 5) +
    " Q " + (cx + 70)  + " " + (stemTopY + 55) + " " + (cx + 20) + " " + (stemTopY + 80) +
    " Z";

  svg.append("path")
    .attr("d", leafRightPath)
    .attr("fill", "#81c784")
    .attr("opacity", 0.9);

  // --------- Centro de la flor ----------
  const core = svg.append("circle")
    .attr("cx", cx)
    .attr("cy", cy)
    .attr("r", coreRadius)
    .attr("fill", "#5d4037");

  svg.append("text")
    .attr("x", cx)
    .attr("y", cy + 4)
    .attr("text-anchor", "middle")
    .attr("font-size", 11)
    .attr("fill", "#ffe082")
    .attr("font-weight", "bold")
    .text(payload.region.toUpperCase());

  const petalGroup = svg.append("g");
  const labelGroup = svg.append("g");

  // --------- Escalas para meses (Tmax media) ----------
  const tMaxMonth = d3.max(payload.monthly, d => d.tmax_mean);
  const tMinMonth = d3.min(payload.monthly, d => d.tmax_mean);

  const lenScaleMonth = d3.scaleLinear()
    .domain([tMinMonth, tMaxMonth])
    .range([60, 150]);

  const colorScaleMonth = d3.scaleSequential(d3.interpolateYlOrRd)
    .domain([tMinMonth, tMaxMonth]); // amarillo claro -> rojo intenso

  // --------- Escalas para días ----------
  const tMaxDay = d3.max(payload.daily, d => d.tmax);
  const tMinDay = d3.min(payload.daily, d => d.tmax);

  const lenScaleDay = d3.scaleLinear()
    .domain([tMinDay, tMaxDay])
    .range([50, 160]);

  const colorScaleDay = d3.scaleSequential(d3.interpolateYlOrRd)
    .domain([tMinDay, tMaxDay]);

  let mode = "month";
  let currentMonth = null;

  // --------- Helper: path de un pétalo (curvado) ----------
  function petalPath(angle, innerR, outerR){{
    const spread = Math.PI / 36; // apertura del pétalo
    const a1 = angle - spread;
    const a2 = angle + spread;

    const x0 = cx + innerR * Math.cos(a1);
    const y0 = cy + innerR * Math.sin(a1);

    const x1 = cx + outerR * Math.cos(angle);
    const y1 = cy + outerR * Math.sin(angle);

    const x2 = cx + innerR * Math.cos(a2);
    const y2 = cy + innerR * Math.sin(a2);

    return `M ${{x0}} ${{y0}} Q ${{cx}} ${{cy}} ${{x1}} ${{y1}} Q ${{cx}} ${{cy}} ${{x2}} ${{y2}} Z`;
  }}

  // --------- Tooltip flotante ----------
  const tooltip = d3.select("body")
    .append("div")
    .style("position", "absolute")
    .style("pointer-events", "none")
    .style("background", "rgba(33,33,33,0.85)")
    .style("color", "#fffde7")
    .style("padding", "6px 8px")
    .style("border-radius", "6px")
    .style("font-size", "11px")
    .style("opacity", 0);

  // --------- Render vista mensual ----------
  function renderMonthView(){{
    mode = "month";
    currentMonth = null;

    const petals = petalGroup.selectAll("path.petal")
      .data(payload.monthly, d => d.month);

    const total = payload.monthly.length;
    const innerR = coreRadius + 10;

    petals.enter()
      .append("path")
      .attr("class", "petal")
      .attr("fill", d => colorScaleMonth(d.tmax_mean))
      .attr("stroke", "#fdd835")
      .attr("stroke-width", 1.2)
      .attr("opacity", 0.95)
      .attr("d", (d, i) => {{
        const angle = 2 * Math.PI * i / total - Math.PI / 2;
        const outR = lenScaleMonth(d.tmax_mean);
        return petalPath(angle, innerR, outR);
      }})
      .on("mouseover", function(event, d){{
        d3.select(this).attr("stroke-width", 2.2);
        tooltip
          .style("opacity", 1)
          .html(`<strong>${{d.month_name}}</strong><br/>
                 Tmax media: ${{d.tmax_mean.toFixed(1)}}°C<br/>
                 Días: ${{d.n_days}}`)
          .style("left", (event.pageX + 12) + "px")
          .style("top", (event.pageY - 28) + "px");
      }})
      .on("mousemove", function(event){{
        tooltip
          .style("left", (event.pageX + 12) + "px")
          .style("top", (event.pageY - 28) + "px");
      }})
      .on("mouseout", function(){{
        d3.select(this).attr("stroke-width", 1.2);
        tooltip.style("opacity", 0);
      }})
      .on("click", (event, d) => {{
        renderDayView(d.month);
        event.stopPropagation();
      }});

    petals.transition().duration(600)
      .attr("fill", d => colorScaleMonth(d.tmax_mean))
      .attr("stroke", "#fdd835")
      .attr("d", (d, i) => {{
        const angle = 2 * Math.PI * i / total - Math.PI / 2;
        const outR = lenScaleMonth(d.tmax_mean);
        return petalPath(angle, innerR, outR);
      }});

    petals.exit().remove();

    // Etiquetas con siglas de mes
    const labels = labelGroup.selectAll("text.month-label")
      .data(payload.monthly, d => d.month);

    labels.enter()
      .append("text")
      .attr("class", "month-label")
      .attr("text-anchor", "middle")
      .attr("font-size", 11)
      .attr("fill", "#424242")
      .merge(labels)
      .transition().duration(600)
      .attr("x", (d, i) => {{
        const angle = 2 * Math.PI * i / total - Math.PI / 2;
        const r = lenScaleMonth(d.tmax_mean) + 16;
        return cx + r * Math.cos(angle);
      }})
      .attr("y", (d, i) => {{
        const angle = 2 * Math.PI * i / total - Math.PI / 2;
        const r = lenScaleMonth(d.tmax_mean) + 16;
        return cy + r * Math.sin(angle);
      }})
      .text(d => d.month_name.substring(0, 3));

    labels.exit().remove();

    legendMonth();
  }}

  // --------- Render vista diaria de un mes ----------
  function renderDayView(month){{
    mode = "day";
    currentMonth = month;

    const days = payload.daily
      .filter(d => d.month === month)
      .sort((a, b) => d3.ascending(a.day, b.day));

    const n = days.length;
    const innerR = coreRadius + 10;

    const petals = petalGroup.selectAll("path.petal")
      .data(days, d => d.date_str);

    petals.enter()
      .append("path")
      .attr("class", "petal")
      .attr("fill", d => colorScaleDay(d.tmax))
      .attr("stroke", "#ffeb3b")
      .attr("stroke-width", 0.9)
      .attr("opacity", 0.96)
      .attr("d", (d, i) => {{
        const angle = 2 * Math.PI * i / n - Math.PI / 2;
        const outR = lenScaleDay(d.tmax);
        return petalPath(angle, innerR, outR);
      }})
      .on("mouseover", function(event, d){{
        d3.select(this).attr("stroke-width", 1.8);
        tooltip
          .style("opacity", 1)
          .html(`Día ${{d.day}} · ${{d.date_str}}<br/>
                 Tmax: ${{d.tmax.toFixed(1)}}°C<br/>
                 Tmin: ${{d.tmin.toFixed(1)}}°C`)
          .style("left", (event.pageX + 12) + "px")
          .style("top", (event.pageY - 28) + "px");
      }})
      .on("mousemove", function(event){{
        tooltip
          .style("left", (event.pageX + 12) + "px")
          .style("top", (event.pageY - 28) + "px");
      }})
      .on("mouseout", function(){{
        d3.select(this).attr("stroke-width", 0.9);
        tooltip.style("opacity", 0);
      }});

    petals.transition().duration(600)
      .attr("fill", d => colorScaleDay(d.tmax))
      .attr("stroke", "#ffeb3b")
      .attr("d", (d, i) => {{
        const angle = 2 * Math.PI * i / n - Math.PI / 2;
        const outR = lenScaleDay(d.tmax);
        return petalPath(angle, innerR, outR);
      }});

    petals.exit().remove();

    // Etiquetas: números de día
    const labels = labelGroup.selectAll("text.month-label")
      .data(days, d => d.date_str);

    labels.enter()
      .append("text")
      .attr("class", "month-label")
      .attr("text-anchor", "middle")
      .attr("font-size", 9)
      .attr("fill", "#455a64")
      .merge(labels)
      .transition().duration(600)
      .attr("x", (d, i) => {{
        const angle = 2 * Math.PI * i / n - Math.PI / 2;
        const r = lenScaleDay(d.tmax) + 10;
        return cx + r * Math.cos(angle);
      }})
      .attr("y", (d, i) => {{
        const angle = 2 * Math.PI * i / n - Math.PI / 2;
        const r = lenScaleDay(d.tmax) + 10;
        return cy + r * Math.sin(angle);
      }})
      .text(d => d.day);

    labels.exit().remove();

    legendDay(month);
  }}

  // --------- Leyendas ----------
  function legendMonth(){{
    svg.selectAll("g.legend").remove();
    const g = svg.append("g").attr("class", "legend");
    const x0 = 40;
    const y0 = 40;

    const gradId = "grad-month-" + hostId;
    const defs = svg.append("defs");
    const grad = defs.append("linearGradient")
      .attr("id", gradId)
      .attr("x1", "0%")
      .attr("y1", "0%")
      .attr("x2", "100%")
      .attr("y2", "0%");

    grad.append("stop")
      .attr("offset", "0%")
      .attr("stop-color", colorScaleMonth(tMinMonth));
    grad.append("stop")
      .attr("offset", "100%")
      .attr("stop-color", colorScaleMonth(tMaxMonth));

    g.append("text")
      .attr("x", x0)
      .attr("y", y0 - 8)
      .attr("font-size", 11)
      .attr("fill", "#424242")
      .text("Meses · Tmax media");

    g.append("rect")
      .attr("x", x0)
      .attr("y", y0)
      .attr("width", 120)
      .attr("height", 10)
      .attr("fill", `url(#${{gradId}})`);

    g.append("text")
      .attr("x", x0)
      .attr("y", y0 + 22)
      .attr("font-size", 10)
      .attr("fill", "#616161")
      .text(`${{tMinMonth.toFixed(1)}}°C`);

    g.append("text")
      .attr("x", x0 + 120)
      .attr("y", y0 + 22)
      .attr("text-anchor", "end")
      .attr("font-size", 10)
      .attr("fill", "#616161")
      .text(`${{tMaxMonth.toFixed(1)}}°C`);
  }}

  function legendDay(month){{
    svg.selectAll("g.legend").remove();
    const g = svg.append("g").attr("class", "legend");
    const x0 = 40;
    const y0 = 40;

    const gradId = "grad-day-" + hostId;
    const defs = svg.append("defs");
    const grad = defs.append("linearGradient")
      .attr("id", gradId)
      .attr("x1", "0%")
      .attr("y1", "0%")
      .attr("x2", "100%")
      .attr("y2", "0%");

    grad.append("stop")
      .attr("offset", "0%")
      .attr("stop-color", colorScaleDay(tMinDay));
    grad.append("stop")
      .attr("offset", "100%")
      .attr("stop-color", colorScaleDay(tMaxDay));

    const monthObj = payload.monthly.find(m => m.month === month) || {{}};
    const monthName = monthObj.month_name || ("Mes " + month);

    g.append("text")
      .attr("x", x0)
      .attr("y", y0 - 8)
      .attr("font-size", 11)
      .attr("fill", "#424242")
      .text("Días · " + monthName);

    g.append("rect")
      .attr("x", x0)
      .attr("y", y0)
      .attr("width", 120)
      .attr("height", 10)
      .attr("fill", `url(#${{gradId}})`);

    g.append("text")
      .attr("x", x0)
      .attr("y", y0 + 22)
      .attr("font-size", 10)
      .attr("fill", "#616161")
      .text(`${{tMinDay.toFixed(1)}}°C`);

    g.append("text")
      .attr("x", x0 + 120)
      .attr("y", y0 + 22)
      .attr("text-anchor", "end")
      .attr("font-size", 10)
      .attr("fill", "#616161")
      .text(`${{tMaxDay.toFixed(1)}}°C`);
  }}

  // --------- Click en el centro -> vuelve a meses ----------
  svg.on("click", function(event){{
    const [x, y] = d3.pointer(event, this);
    const dx = x - cx;
    const dy = y - cy;
    if (Math.sqrt(dx*dx + dy*dy) <= coreRadius + 6){{
      renderMonthView();
    }}
  }});

  // Primera renderización
  renderMonthView();
}})();
</script>
"""
    return HTML(html)