# src/our_library/graph.py
import json, uuid, math, base64
from pathlib import Path
from IPython.display import HTML
# mylib/dashboard.py
from flask import Flask, request, jsonify
from threading import Thread

# en graph2_1.py (y exportar en __init__.py)
try:
    from google.colab import output as _colab_output
    _IN_COLAB = True
except Exception:
    _IN_COLAB = False

def enable_colab_bridge():
    """Registra el callback JS→Python en Colab para recibir nodos clicados."""
    if not _IN_COLAB:
        return False
    def _cb(node):
        global global_node_, global_clicks_
        global_node_ = node
        global_clicks_.append(node)  # <- acumula
        return {"status": "ok"}
    _colab_output.register_callback("ourlib.update_node", _cb)
    return True


global_node_ = None
global_clicks_ = []
app = Flask(__name__)

@app.route("/update_node", methods=["POST"])
def update_node():
    global global_node_, global_clicks_
    data = request.get_json()
    global_node_ = data.get("node")
    if global_node_ is not None:
        global_clicks_.append(global_node_)  # <- acumula
    return jsonify({"status": "ok", "node": global_node_})

def start_server(port=5000):
    thread = Thread(target=lambda: app.run(port=port, debug=False, use_reloader=False))
    thread.daemon = True
    thread.start()

def get_current_node():
    return global_node_

def get_click_history(clear: bool = False):
    """Devuelve la lista de todos los nodos clicados (en orden)."""
    global global_clicks_
    hist = list(global_clicks_)
    if clear:
        global_clicks_.clear()
    return hist

def clear_click_history():
    """Limpia el historial de clics."""
    global global_clicks_
    global_clicks_.clear()

def get_unique_clicks(key: str = "id"):
    """Devuelve nodos únicos (por id), en el orden en que se clicaron."""
    seen = set()
    out = []
    for n in global_clicks_:
        k = n.get(key)
        if k not in seen:
            seen.add(k)
            out.append(n)
    return out


# [Todas tus funciones existentes permanecen igual hasta show_matrix_layout...]
def hello1_d3(width=260, height=160, radius=36, color="#1976d2"):
    """
    Dibuja un círculo con D3. Si D3 no se puede cargar desde CDN (CSP),
    cae a un fallback con SVG nativo.
    """
    html = """
<div class="ourlib-hello-d3"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui;">
  <div class="viz"></div>
</div>

<!-- 1) Intentamos cargar D3 desde CDN -->
<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>

<!-- 2) Script que dibuja con D3 o cae a fallback -->
<script>
(function() {
  const container = document.currentScript.previousElementSibling; // el <div class="ourlib-hello-d3">
  const viz = container.querySelector('.viz');

  // Helper para mensajes
  const say = function(msg) {
    const p = document.createElement('p');
    p.style.margin = '6px 0 0 0';
    p.textContent = msg;
    container.appendChild(p);
  };

  const W = %d, H = %d, R = %d;
  const COLOR = "%s";

  if (typeof d3 !== 'undefined') {
    // ========== Con D3 ==========
    const svg = d3.select(viz)
      .append('svg')
      .attr('width', W)
      .attr('height', H);

    svg.append('circle')
      .attr('cx', W/2)
      .attr('cy', H/2)
      .attr('r', R)
      .attr('fill', COLOR)
      .attr('opacity', 0.9);

    say("D3 cargado: " + d3.version);
  } else {
    // ========== Fallback sin D3 (SVG nativo) ==========
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', W);
    svg.setAttribute('height', H);

    const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    c.setAttribute('cx', W/2);
    c.setAttribute('cy', H/2);
    c.setAttribute('r', R);
    c.setAttribute('fill', COLOR);
    c.setAttribute('opacity', '0.9');

    svg.appendChild(c);
    viz.appendChild(svg);

    say("D3 no disponible (CSP). Mostrando fallback SVG.");
  }
})();
</script>
""" % (width, height, radius, color)
    return HTML(html)


# --- NUEVA FUNCIÓN ---
def show_graph1(nodes, links, width=520, height=360, node_radius=8,
               node_color="#1976d2", link_color="#999"):
    """
    Dibuja un grafo ESTÁTICO (sin fuerzas) con SVG nativo.
    - nodes: lista de dicts con al menos {"id": ...}
    - links: lista de dicts con {"source": <id>, "target": <id>}
    """
    # Validación mínima en Python (errores claros si los datos vienen mal)
    if not isinstance(nodes, (list, tuple)) or not isinstance(links, (list, tuple)):
        raise TypeError("nodes y links deben ser listas/tuplas")

    for i, n in enumerate(nodes):
        if not isinstance(n, dict) or "id" not in n:
            raise ValueError(f"nodes[{i}] debe tener clave 'id'")

    node_ids = {str(n["id"]) for n in nodes}
    clean_links = []
    for j, e in enumerate(links):
        if not isinstance(e, dict) or "source" not in e or "target" not in e:
            raise ValueError(f"links[{j}] debe tener 'source' y 'target'")
        s, t = str(e["source"]), str(e["target"])
        # Ignoramos aristas con ids inexistentes (para que no reviente)
        if s in node_ids and t in node_ids:
            clean_links.append({"source": s, "target": t})

    data = {"nodes": nodes, "links": clean_links}
    data_json = json.dumps(data)  # seguro para incrustar en JS
    cid = "ourlib-" + uuid.uuid4().hex  # id único del contenedor

    html = """
<div id="%s" class="ourlib-graph"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui;">
  <div class="viz"></div>
</div>

<script>
(function(){
  const root = document.getElementById('%s');
  const viz  = root.querySelector('.viz');
  const data = %s;

  const W = %d, H = %d, R = %d;
  const NODE_COLOR = "%s";
  const LINK_COLOR = "%s";

  // 1) Posicionamos nodos en un círculo (layout simple)
  const n = data.nodes.length;
  const cx = W/2, cy = H/2;
  const rad = Math.min(W, H)/2 - (R + 12);
  const pos = {};
  data.nodes.forEach((node, i) => {
    const ang = (i / Math.max(1, n)) * 2 * Math.PI;
    pos[String(node.id)] = {
      x: cx + rad * Math.cos(ang),
      y: cy + rad * Math.sin(ang)
    };
  });

  // 2) Creamos el SVG
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('width', W);
  svg.setAttribute('height', H);
  viz.appendChild(svg);

  // 3) Dibujamos aristas
  (data.links || []).forEach(link => {
    const a = pos[String(link.source)];
    const b = pos[String(link.target)];
    if (!a || !b) return;
    const line = document.createElementNS(svgNS, 'line');
    line.setAttribute('x1', a.x);
    line.setAttribute('y1', a.y);
    line.setAttribute('x2', b.x);
    line.setAttribute('y2', b.y);
    line.setAttribute('stroke', LINK_COLOR);
    line.setAttribute('stroke-width', 1.5);
    line.setAttribute('opacity', 0.8);
    svg.appendChild(line);
  });

  // 4) Dibujamos nodos
  data.nodes.forEach(node => {
    const p = pos[String(node.id)];
    const c = document.createElementNS(svgNS, 'circle');
    c.setAttribute('cx', p.x);
    c.setAttribute('cy', p.y);
    c.setAttribute('r', R);
    c.setAttribute('fill', NODE_COLOR);
    c.setAttribute('opacity', 0.9);
    svg.appendChild(c);
  });

  // Nota
  const note = document.createElement('p');
  note.style.margin = '6px 0 0';
  note.textContent = 'show_graph1() estático (sin fuerzas).';
  root.appendChild(note);
})();
</script>
""" % (cid, cid, data_json, width, height, node_radius, node_color, link_color)

    return HTML(html)


# --- NUEVA FUNCIÓN ---
# src/our_library/graph.py


# no funciona la parte dinámica porque vscode bloquea al tratar de inyectar D3 
def show_graph_force1(nodes, links, width=640, height=420, node_radius=8,
                     node_color="#1976d2", link_color="#999",
                     link_distance=70, charge_strength=-160):
    """
    Grafo con layout de fuerzas usando D3 cargado INLINE (sin CDN, sin data:, sin eval).
    Si no se logra inyectar D3, cae a un render estático simple.
    """
    # Validaciones mínimas
    if not isinstance(nodes, (list, tuple)) or not isinstance(links, (list, tuple)):
        raise TypeError("nodes y links deben ser listas/tuplas")
    for i, n in enumerate(nodes):
        if not isinstance(n, dict) or "id" not in n:
            raise ValueError(f"nodes[{i}] debe tener clave 'id'")

    node_ids = {str(n["id"]) for n in nodes}
    clean_links = []
    for j, e in enumerate(links):
        if not isinstance(e, dict) or "source" not in e or "target" not in e:
            raise ValueError(f"links[{j}] debe tener 'source' y 'target'")
        s, t = str(e["source"]), str(e["target"])
        if s in node_ids and t in node_ids:
            clean_links.append({"source": s, "target": t})

    data = {"nodes": nodes, "links": clean_links}
    data_json = json.dumps(data)
    cid = "ourlib-" + uuid.uuid4().hex

    # 1) Leemos d3.v7.min.js (local)
    d3_path = Path(__file__).parent / "_static" / "d3.v7.min.js"
    try:
        d3_text = d3_path.read_text(encoding="utf-8")
    except Exception:
        d3_text = None  # si no está, haremos fallback

    # 2) Construimos HTML por piezas para evitar problemas con % en el código de D3
    parts = []

    # Contenedor
    parts.append(f"""
<div id="{cid}" class="ourlib-graph"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui;">
  <div class="viz"></div>
</div>
""")

    if d3_text is not None:
        # 3) Inyectamos D3 como <script> inline (sin eval)
        parts.append("<script>\n" + d3_text + "\n</script>\n")

        # 4) Script principal que usa D3 (con formato seguro separando el bloque JS)
        main_js = """
(function(){
  const root = document.getElementById('%(cid)s');
  const viz  = root.querySelector('.viz');
  const data = %(data_json)s;

  const W = %(W)d, H = %(H)d, R = %(R)d;
  const NODE_COLOR = "%(NODE_COLOR)s";
  const LINK_COLOR = "%(LINK_COLOR)s";
  const LINK_DIST  = %(LINK_DIST)d;
  const CHARGE_STR = %(CHARGE_STR)d;

  if (typeof d3 !== 'undefined') {
    const svg = d3.select(viz).append('svg')
      .attr('width', W).attr('height', H);

    const link = svg.append('g')
      .attr('stroke', LINK_COLOR).attr('stroke-opacity', 0.7)
      .selectAll('line').data(data.links).join('line')
      .attr('stroke-width', 1.5);

    const node = svg.append('g')
      .selectAll('circle').data(data.nodes).join('circle')
      .attr('r', R).attr('fill', NODE_COLOR).attr('opacity', 0.95);

    const sim = d3.forceSimulation(data.nodes)
      .force('link', d3.forceLink(data.links).id(d => String(d.id)).distance(LINK_DIST))
      .force('charge', d3.forceManyBody().strength(CHARGE_STR))
      .force('center', d3.forceCenter(W/2, H/2));

    sim.on('tick', () => {
      link.attr('x1', d => d.source.x)
          .attr('y1', d => d.source.y)
          .attr('x2', d => d.target.x)
          .attr('y2', d => d.target.y);

      node.attr('cx', d => d.x)
          .attr('cy', d => d.y);
    });

    const p = document.createElement('p');
    p.style.margin = '6px 0 0';
    p.textContent = 'show_graph_force1() con D3 local (inline).';
    root.appendChild(p);
  } else {
    const p = document.createElement('p');
    p.style.margin = '6px 0 0';
    p.textContent = 'D3 no disponible (inline no ejecutó). Fallback estático.';
    root.appendChild(p);
  }
})();
"""
        parts.append("<script>\n" + (main_js % {
            "cid": cid,
            "data_json": data_json,
            "W": width, "H": height, "R": node_radius,
            "NODE_COLOR": node_color, "LINK_COLOR": link_color,
            "LINK_DIST": link_distance, "CHARGE_STR": charge_strength
        }) + "\n</script>\n")

    else:
        # 5) Fallback estático si no pudimos leer D3
        fallback_js = """
(function(){
  const root = document.getElementById('%(cid)s');
  const viz  = root.querySelector('.viz');
  const data = %(data_json)s;

  const W = %(W)d, H = %(H)d, R = %(R)d;
  const NODE_COLOR = "%(NODE_COLOR)s";
  const LINK_COLOR = "%(LINK_COLOR)s";

  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('width', W); svg.setAttribute('height', H);
  viz.appendChild(svg);

  const n = data.nodes.length;
  const cx = W/2, cy = H/2;
  const rad = Math.min(W,H)/2 - (R+12);
  const pos = {};
  data.nodes.forEach((node, i) => {
    const ang = (i / Math.max(1, n)) * 2 * Math.PI;
    pos[String(node.id)] = { x: cx + rad*Math.cos(ang), y: cy + rad*Math.sin(ang) };
  });

  (data.links || []).forEach(link => {
    const a = pos[String(link.source)], b = pos[String(link.target)];
    if (!a || !b) return;
    const line = document.createElementNS(svgNS, 'line');
    line.setAttribute('x1', a.x); line.setAttribute('y1', a.y);
    line.setAttribute('x2', b.x); line.setAttribute('y2', b.y);
    line.setAttribute('stroke', LINK_COLOR);
    line.setAttribute('stroke-width', 1.5);
    line.setAttribute('opacity', '0.7');
    svg.appendChild(line);
  });

  data.nodes.forEach(node => {
    const p = pos[String(node.id)];
    const c = document.createElementNS(svgNS, 'circle');
    c.setAttribute('cx', p.x); c.setAttribute('cy', p.y);
    c.setAttribute('r', R);
    c.setAttribute('fill', NODE_COLOR);
    c.setAttribute('opacity', '0.95');
    svg.appendChild(c);
  });

  const note = document.createElement('p');
  note.style.margin = '6px 0 0';
  note.textContent = 'D3 no disponible. Fallback estático.';
  root.appendChild(note);
})();
"""
        parts.append("<script>\n" + (fallback_js % {
            "cid": cid,
            "data_json": data_json,
            "W": width, "H": height, "R": node_radius,
            "NODE_COLOR": node_color, "LINK_COLOR": link_color
        }) + "\n</script>\n")

    return HTML("".join(parts))


# usaremos js puro
# ---- Fuerzas sin D3 (mini física en JS puro) ----


def show_graph_force_vanilla1(nodes, links, width=640, height=420, node_radius=8,
                             node_color="#1976d2", link_color="#999",
                             link_distance=70):
    """
    Grafo con layout de fuerzas *sin D3* (mini simulación) + interacciones:
    - Drag para arrastrar nodos.
    - Hover con tooltip (id y grado del nodo).
    """
    # Validación mínima
    if not isinstance(nodes, (list, tuple)) or not isinstance(links, (list, tuple)):
        raise TypeError("nodes y links deben ser listas/tuplas")
    for i, n in enumerate(nodes):
        if not isinstance(n, dict) or "id" not in n:
            raise ValueError(f"nodes[{i}] debe tener clave 'id'")

    node_ids = {str(n["id"]) for n in nodes}
    clean_links = []
    for j, e in enumerate(links):
        if not isinstance(e, dict) or "source" not in e or "target" not in e:
            raise ValueError(f"links[{j}] debe tener 'source' y 'target'")
        s, t = str(e["source"]), str(e["target"])
        if s in node_ids and t in node_ids:
            clean_links.append({"source": s, "target": t})

    data = {"nodes": nodes, "links": clean_links}
    import json, uuid
    data_json = json.dumps(data)
    cid = "ourlib-" + uuid.uuid4().hex

    from IPython.display import HTML
    html = """
<div id="%s" class="ourlib-graph"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui; position:relative;">
  <div class="viz"></div>
  <div class="tip" style="position:absolute; display:none; pointer-events:none; padding:4px 6px; background:#111; color:#fff; font-size:12px; border-radius:4px; box-shadow:0 2px 6px rgba(0,0,0,.2); transform:translate(12px, -8px);"></div>
</div>

<script>
(function(){
  const root = document.getElementById('%s');
  const viz  = root.querySelector('.viz');
  const tip  = root.querySelector('.tip');
  const data = %s;

  const W = %d, H = %d, R = %d;
  const NODE_COLOR = "%s";
  const LINK_COLOR = "%s";
  const LINK_DIST  = %d;

  // ===== SVG =====
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('width', W); svg.setAttribute('height', H);
  viz.appendChild(svg);

  // ===== Índices y grados =====
  const idx = new Map(); data.nodes.forEach((n,i)=>idx.set(String(n.id), i));
  const degree = new Array(data.nodes.length).fill(0);
  const edges = (data.links||[])
    .map(l=>({ s: idx.get(String(l.source)), t: idx.get(String(l.target)) }))
    .filter(e=> e.s!=null && e.t!=null);
  for (const e of edges){ degree[e.s]++; degree[e.t]++; }

  // ===== Estado de simulación =====
  const nodes = data.nodes.map((n,i)=>({
    id: String(n.id),
    x: Math.random()*W, y: Math.random()*H,
    vx: 0, vy: 0, fx: 0, fy: 0
  }));

  // ===== Elementos SVG =====
  const lines = edges.map(e=>{
    const ln = document.createElementNS(svgNS, 'line');
    ln.setAttribute('stroke', LINK_COLOR);
    ln.setAttribute('stroke-opacity', '0.7');
    ln.setAttribute('stroke-width', '1.5');
    svg.appendChild(ln);
    return ln;
  });

  const circles = nodes.map((n,i)=>{
    const c = document.createElementNS(svgNS, 'circle');
    c.setAttribute('r', R);
    c.setAttribute('fill', NODE_COLOR);
    c.setAttribute('opacity', '0.95');
    c.style.cursor = 'grab';
    c.dataset.index = String(i);
    svg.appendChild(c);
    return c;
  });

  // ===== Tooltip (hover) =====
  function showTip(i, clientX, clientY){
    tip.textContent = nodes[i].id + " · grado " + degree[i];
    const rect = root.getBoundingClientRect();
    tip.style.left = (clientX - rect.left + 12) + 'px';
    tip.style.top  = (clientY - rect.top  - 8) + 'px';
    tip.style.display = 'block';
  }
  function hideTip(){ tip.style.display = 'none'; }

  circles.forEach((c,i)=>{
    c.addEventListener('mouseenter', (e)=> showTip(i, e.clientX, e.clientY));
    c.addEventListener('mousemove',  (e)=> showTip(i, e.clientX, e.clientY));
    c.addEventListener('mouseleave', hideTip);
  });

  // ===== Drag (pointer events) =====
  let draggingIndex = null;
  let draggingActive = false;

  function toLocal(clientX, clientY){
    const rect = svg.getBoundingClientRect();
    return { x: clientX - rect.left, y: clientY - rect.top };
  }

  circles.forEach((c)=>{
    c.addEventListener('pointerdown', (e)=>{
      const i = Number(c.dataset.index);
      draggingIndex = i;
      draggingActive = true;
      c.setPointerCapture(e.pointerId);
      c.style.cursor = 'grabbing';
      const p = toLocal(e.clientX, e.clientY);
      nodes[i].x = p.x; nodes[i].y = p.y;
      nodes[i].vx = 0;  nodes[i].vy = 0;
      // Si la simulación estaba parada, reanudar
      requestAnimationFrame(step);
    });

    c.addEventListener('pointermove', (e)=>{
      if (draggingIndex===null) return;
      if (Number(c.dataset.index)!==draggingIndex) return;
      const p = toLocal(e.clientX, e.clientY);
      const n = nodes[draggingIndex];
      n.x = p.x; n.y = p.y; n.vx = 0; n.vy = 0;
    });

    c.addEventListener('pointerup', (e)=>{
      if (Number(c.dataset.index)!==draggingIndex) return;
      c.releasePointerCapture(e.pointerId);
      c.style.cursor = 'grab';
      draggingIndex = null;
      draggingActive = false;
    });

    c.addEventListener('pointercancel', ()=>{
      draggingIndex = null; draggingActive = false; c.style.cursor='grab';
    });
  });

  // ===== Parámetros de física =====
  const kSpring = 0.02;       // rigidez del resorte
  const kRepel  = 1500;       // fuerza de repulsión
  const damping = 0.85;       // amortiguación
  const centerK = 0.01;       // atracción al centro
  const dt      = 0.02;       // paso de tiempo

  function step(){
    // reset fuerzas
    for (const n of nodes){ n.fx=0; n.fy=0; }

    // resortes (aristas)
    for (let i=0;i<edges.length;i++){
      const e = edges[i];
      const a = nodes[e.s], b = nodes[e.t];
      let dx = b.x - a.x, dy = b.y - a.y;
      let dist = Math.hypot(dx, dy) || 0.001;
      const diff = dist - LINK_DIST;
      const F = kSpring * diff;
      const fx = F * dx / dist, fy = F * dy / dist;
      a.fx +=  fx; a.fy +=  fy;
      b.fx += -fx; b.fy += -fy;
    }

    // repulsión O(N^2)
    for (let i=0;i<nodes.length;i++){
      for (let j=i+1;j<nodes.length;j++){
        let dx = nodes[j].x - nodes[i].x;
        let dy = nodes[j].y - nodes[i].y;
        let d2 = dx*dx + dy*dy + 0.01;
        const inv = 1/Math.sqrt(d2);
        const F = kRepel / d2;
        const fx = F * dx * inv, fy = F * dy * inv;
        nodes[i].fx -= fx; nodes[i].fy -= fy;
        nodes[j].fx += fx; nodes[j].fy += fy;
      }
    }

    // integración (si se está arrastrando un nodo, no aplicar fuerzas a ese)
    for (let i=0;i<nodes.length;i++){
      const n = nodes[i];
      if (i !== draggingIndex){
        n.fx += centerK * (W/2 - n.x);
        n.fy += centerK * (H/2 - n.y);
        n.vx = (n.vx + n.fx * dt) * damping;
        n.vy = (n.vy + n.fy * dt) * damping;
        n.x  += n.vx;
        n.y  += n.vy;
      }
    }

    // actualizar SVG
    for (let i=0;i<edges.length;i++){
      const a = nodes[edges[i].s], b = nodes[edges[i].t];
      const ln = lines[i];
      ln.setAttribute('x1', a.x); ln.setAttribute('y1', a.y);
      ln.setAttribute('x2', b.x); ln.setAttribute('y2', b.y);
    }
    for (let i=0;i<nodes.length;i++){
      const c = circles[i], n = nodes[i];
      c.setAttribute('cx', n.x); c.setAttribute('cy', n.y);
    }

    // energía cinética
    let ke = 0;
    for (const n of nodes){ ke += n.vx*n.vx + n.vy*n.vy; }

    // si se está arrastrando, seguimos; si no, paramos cuando se estabiliza
    if (draggingActive || ke > 0.01) requestAnimationFrame(step);
  }

  // Etiqueta de modo
  const p = document.createElement('p');
  p.style.margin = '6px 0 0';
  p.textContent = 'show_graph_force_vanilla1() · drag + tooltip';
  root.appendChild(p);

  // iniciar
  requestAnimationFrame(step);
})();
</script>
""" % (cid, cid, data_json, width, height, node_radius, node_color, link_color, link_distance)

    return HTML(html)



# agregamos la funcionalidad de check list
def show_graph_force_vanilla_checklist1(
    nodes, links, width=640, height=420, node_radius=8,
    node_color="#1976d2", link_color="#999",
    link_distance=70
):
    """
    Grafo con fuerza *sin D3* + checklist mínimo:
    - Click (sin teclas): toggle 'completado' (oculta el nodo y sus aristas).
    - Shift + click: toggle 'sin_interes' (atenúa el nodo y sus vecinos).
    - Botones: Reset, Solo activos.
    *Todo vive en JS (no Py↔JS aún).*
    """
    # Validación mínima
    if not isinstance(nodes, (list, tuple)) or not isinstance(links, (list, tuple)):
        raise TypeError("nodes y links deben ser listas/tuplas")
    for i, n in enumerate(nodes):
        if not isinstance(n, dict) or "id" not in n:
            raise ValueError(f"nodes[{i}] debe tener clave 'id'")

    node_ids = {str(n["id"]) for n in nodes}
    clean_links = []
    for j, e in enumerate(links):
        if not isinstance(e, dict) or "source" not in e or "target" not in e:
            raise ValueError(f"links[{j}] debe tener 'source' y 'target'")
        s, t = str(e["source"]), str(e["target"])
        if s in node_ids and t in node_ids:
            clean_links.append({"source": s, "target": t})

    import json, uuid
    data = {"nodes": nodes, "links": clean_links}
    data_json = json.dumps(data)
    cid = "ourlib-" + uuid.uuid4().hex

    from IPython.display import HTML
    html = """
<div id="%s" class="ourlib-graph"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui; position:relative;">
  <div style="display:flex; gap:8px; align-items:center; margin-bottom:6px;">
    <button class="btn-reset">Reset</button>
    <button class="btn-actives">Solo activos</button>
    <span style="font-size:12px; color:#555;">Click: completado · Shift+Click: sin interés</span>
  </div>
  <div class="viz"></div>
  <div class="tip" style="position:absolute; display:none; pointer-events:none; padding:4px 6px; background:#111; color:#fff; font-size:12px; border-radius:4px; box-shadow:0 2px 6px rgba(0,0,0,.2); transform:translate(12px, -8px);"></div>
</div>

<script>
(function(){
  const root = document.getElementById('%s');
  const viz  = root.querySelector('.viz');
  const tip  = root.querySelector('.tip');
  const btnReset   = root.querySelector('.btn-reset');
  const btnActives = root.querySelector('.btn-actives');
  const data = %s;

  const W = %d, H = %d, R = %d;
  const NODE_COLOR = "%s";
  const LINK_COLOR = "%s";
  const LINK_DIST  = %d;

  // ===== SVG =====
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('width', W); svg.setAttribute('height', H);
  viz.appendChild(svg);

  // ===== Índices, grados, adyacencia =====
  const idx = new Map(); data.nodes.forEach((n,i)=>idx.set(String(n.id), i));
  const degree = new Array(data.nodes.length).fill(0);
  const adj = Array.from({length: data.nodes.length}, ()=> new Set());
  const edges = (data.links||[])
    .map(l=>({ s: idx.get(String(l.source)), t: idx.get(String(l.target)) }))
    .filter(e=> e.s!=null && e.t!=null);
  for (const e of edges){
    degree[e.s]++; degree[e.t]++;
    adj[e.s].add(e.t); adj[e.t].add(e.s);
  }

  // ===== Estado de simulación y checklist =====
  const nodes = data.nodes.map((n,i)=>({
    id: String(n.id),
    x: Math.random()*W, y: Math.random()*H,
    vx: 0, vy: 0, fx: 0, fy: 0
  }));

  const STATE = {
    NORMAL: 0,
    COMPLETADO: 1,
    SIN_INTERES: 2
  };
  const state = new Array(nodes.length).fill(STATE.NORMAL);

  // ===== Elementos SVG =====
  let curEdges = edges.slice(); // aristas visibles (cambia si hay completados)
  const lines = curEdges.map(e=>{
    const ln = document.createElementNS(svgNS, 'line');
    ln.setAttribute('stroke', LINK_COLOR);
    ln.setAttribute('stroke-opacity', '0.7');
    ln.setAttribute('stroke-width', '1.5');
    svg.appendChild(ln);
    return ln;
  });

  const circles = nodes.map((n,i)=>{
    const c = document.createElementNS(svgNS, 'circle');
    c.setAttribute('r', R);
    c.setAttribute('fill', NODE_COLOR);
    c.setAttribute('opacity', '0.95');
    c.style.cursor = 'grab';
    c.dataset.index = String(i);
    svg.appendChild(c);
    return c;
  });

  // ===== Tooltip =====
  function showTip(i, clientX, clientY){
    tip.textContent = nodes[i].id + " · grado " + degree[i];
    const rect = root.getBoundingClientRect();
    tip.style.left = (clientX - rect.left + 12) + 'px';
    tip.style.top  = (clientY - rect.top  - 8) + 'px';
    tip.style.display = 'block';
  }
  function hideTip(){ tip.style.display = 'none'; }

  circles.forEach((c,i)=>{
    c.addEventListener('mouseenter', (e)=> showTip(i, e.clientX, e.clientY));
    c.addEventListener('mousemove',  (e)=> showTip(i, e.clientX, e.clientY));
    c.addEventListener('mouseleave', hideTip);
  });

  // ===== Drag =====
  let draggingIndex = null;
  let draggingActive = false;
  function toLocal(clientX, clientY){
    const rect = svg.getBoundingClientRect();
    return { x: clientX - rect.left, y: clientY - rect.top };
  }
  circles.forEach((c)=>{
    c.addEventListener('pointerdown', (e)=>{
      const i = Number(c.dataset.index);
      draggingIndex = i; draggingActive = true;
      c.setPointerCapture(e.pointerId);
      c.style.cursor = 'grabbing';
      const p = toLocal(e.clientX, e.clientY);
      nodes[i].x = p.x; nodes[i].y = p.y;
      nodes[i].vx = 0;  nodes[i].vy = 0;
      requestAnimationFrame(step);
    });
    c.addEventListener('pointermove', (e)=>{
      if (draggingIndex===null) return;
      if (Number(c.dataset.index)!==draggingIndex) return;
      const p = toLocal(e.clientX, e.clientY);
      const n = nodes[draggingIndex];
      n.x = p.x; n.y = p.y; n.vx = 0; n.vy = 0;
    });
    c.addEventListener('pointerup', (e)=>{
      if (Number(c.dataset.index)!==draggingIndex) return;
      c.releasePointerCapture(e.pointerId);
      c.style.cursor = 'grab';
      draggingIndex = null; draggingActive = false;
    });
    c.addEventListener('pointercancel', ()=>{
      draggingIndex = null; draggingActive = false; c.style.cursor='grab';
    });
  });

  // ===== Checklist: click / shift+click =====
  function recomputeEdges(){
    // recalcular aristas visibles (oculta las que tocan un COMPLETADO)
    const vis = [];
    for (const e of edges){
      if (state[e.s] !== STATE.COMPLETADO && state[e.t] !== STATE.COMPLETADO){
        vis.push(e);
      }
    }
    // reemplazamos elementos SVG de líneas acorde
    while (lines.length) { const ln = lines.pop(); ln.remove(); }
    curEdges = vis;
    for (const e of curEdges){
      const ln = document.createElementNS(svgNS, 'line');
      ln.setAttribute('stroke', LINK_COLOR);
      ln.setAttribute('stroke-opacity', '0.7');
      ln.setAttribute('stroke-width', '1.5');
      svg.appendChild(ln);
      lines.push(ln);
    }
  }

  function applyStyles(){
    // nodos
    circles.forEach((c,i)=>{
      if (state[i] === STATE.COMPLETADO){
        c.style.display = 'none';
      } else {
        c.style.display = '';
        // atenuación por SIN_INTERES (nodo o vecinos)
        let muted = (state[i] === STATE.SIN_INTERES);
        if (!muted){
          for (const v of adj[i]){
            if (state[v] === STATE.SIN_INTERES){ muted = true; break; }
          }
        }
        c.setAttribute('opacity', muted ? '0.25' : '0.95');
      }
    });
    // líneas
    lines.forEach((ln, k)=>{
      const e = curEdges[k];
      const a = e.s, b = e.t;
      // Atenuar si alguno es SIN_INTERES o vecinos de uno SIN_INTERES
      const muteA = state[a]===STATE.SIN_INTERES || [...adj[a]].some(v=>state[v]===STATE.SIN_INTERES);
      const muteB = state[b]===STATE.SIN_INTERES || [...adj[b]].some(v=>state[v]===STATE.SIN_INTERES);
      const muted = muteA || muteB;
      ln.setAttribute('opacity', muted ? '0.25' : '0.7');
    });
  }

  function kick(){
    // “reactiva” la simulación un rato
    let frames = 60;
    function pump(){ if (frames-- > 0){ requestAnimationFrame(pump); } }
    requestAnimationFrame(pump);
  }

  circles.forEach((c,i)=>{
    c.addEventListener('click', (e)=>{
      if (e.shiftKey){
        // Shift+click => SIN_INTERES (toggle)
        state[i] = (state[i]===STATE.SIN_INTERES) ? STATE.NORMAL : STATE.SIN_INTERES;
      } else {
        // Click normal => COMPLETADO (toggle)
        state[i] = (state[i]===STATE.COMPLETADO) ? STATE.NORMAL : STATE.COMPLETADO;
        recomputeEdges();
      }
      applyStyles();
      kick();
    });
  });

  // Botones
  btnReset.addEventListener('click', ()=>{
    for (let i=0;i<state.length;i++) state[i]=STATE.NORMAL;
    recomputeEdges(); applyStyles(); kick();
  });
  btnActives.addEventListener('click', ()=>{
    // Oculta los COMPLETADO; los demás se muestran (quita SIN_INTERES)
    for (let i=0;i<state.length;i++){
      state[i] = (state[i]===STATE.COMPLETADO) ? STATE.COMPLETADO : STATE.NORMAL;
    }
    recomputeEdges(); applyStyles(); kick();
  });

  // ===== Física =====
  const kSpring = 0.02, kRepel = 1500, damping = 0.85, centerK = 0.01, dt = 0.02;

  function step(){
    // reset fuerzas
    for (const n of nodes){ n.fx=0; n.fy=0; }

    // resortes (solo en aristas visibles)
    for (let i=0;i<curEdges.length;i++){
      const e = curEdges[i];
      const a = nodes[e.s], b = nodes[e.t];
      let dx = b.x - a.x, dy = b.y - a.y;
      let dist = Math.hypot(dx, dy) || 0.001;
      const diff = dist - LINK_DIST;
      const F = kSpring * diff;
      const fx = F * dx / dist, fy = F * dy / dist;
      a.fx +=  fx; a.fy +=  fy;
      b.fx += -fx; b.fy += -fy;
    }

    // repulsión O(N^2) solo para nodos visibles
    const visibleIdx = [];
    for (let i=0;i<nodes.length;i++){
      if (state[i] !== STATE.COMPLETADO) visibleIdx.push(i);
    }
    for (let ii=0; ii<visibleIdx.length; ii++){
      const i = visibleIdx[ii];
      for (let jj=ii+1; jj<visibleIdx.length; jj++){
        const j = visibleIdx[jj];
        let dx = nodes[j].x - nodes[i].x;
        let dy = nodes[j].y - nodes[i].y;
        let d2 = dx*dx + dy*dy + 0.01;
        const inv = 1/Math.sqrt(d2);
        const F = kRepel / d2;
        const fx = F * dx * inv, fy = F * dy * inv;
        nodes[i].fx -= fx; nodes[i].fy -= fy;
        nodes[j].fx += fx; nodes[j].fy += fy;
      }
    }

    // integración
    for (let i=0;i<nodes.length;i++){
      if (state[i]===STATE.COMPLETADO) continue; // no mover completados (están ocultos)
      const n = nodes[i];
      n.fx += centerK * (W/2 - n.x);
      n.fy += centerK * (H/2 - n.y);
      n.vx = (n.vx + n.fx * dt) * damping;
      n.vy = (n.vy + n.fy * dt) * damping;
      n.x  += n.vx;
      n.y  += n.vy;
    }

    // actualizar SVG
    for (let i=0;i<curEdges.length;i++){
      const a = nodes[curEdges[i].s], b = nodes[curEdges[i].t];
      const ln = lines[i];
      ln.setAttribute('x1', a.x); ln.setAttribute('y1', a.y);
      ln.setAttribute('x2', b.x); ln.setAttribute('y2', b.y);
    }
    for (let i=0;i<nodes.length;i++){
      const c = circles[i], n = nodes[i];
      if (state[i]===STATE.COMPLETADO){ c.style.display='none'; continue; }
      c.style.display='';
      c.setAttribute('cx', n.x); c.setAttribute('cy', n.y);
    }

    // energía
    let ke = 0;
    for (const n of nodes){ ke += n.vx*n.vx + n.vy*n.vy; }
    if (draggingActive || ke > 0.01) requestAnimationFrame(step);
  }

  // Inicial
  function initialLayout(){
    // ponlos en círculo para evitar solapes iniciales fuertes
    const n = nodes.length, cx=W/2, cy=H/2, rad=Math.min(W,H)/2 - (R+12);
    for (let i=0;i<n;i++){
      const ang = (i / Math.max(1,n)) * 2 * Math.PI;
      nodes[i].x = cx + rad*Math.cos(ang);
      nodes[i].y = cy + rad*Math.sin(ang);
    }
  }
  initialLayout();
  recomputeEdges();
  applyStyles();
  requestAnimationFrame(step);
})();
</script>
""" % (cid, cid, data_json, width, height, node_radius, node_color, link_color, link_distance)

    return HTML(html)


# ------------------------------------------------------------
# ------------------------------------------------------------
# ------------------------------------------------------------


def show_matrix_layout1(nodes_list, links_list, sizes_list, nrows=2, ncols=2, node_radius=8,
                       node_color="#1976d2", link_color="#999", link_distance=70, layout="circle"):
    """
    Dibuja un layout de matriz N x M donde cada celda tiene un grafo estático con un tamaño distinto.
    - nodes_list: lista de listas de diccionarios, cada lista corresponde a los nodos de una celda
    - links_list: lista de listas de diccionarios, cada lista corresponde a los enlaces de una celda
    - sizes_list: lista de tuplas (ancho, alto) para cada celda
    - nrows: número de filas en la matriz
    - ncols: número de columnas en la matriz
    - layout: tipo de distribución de nodos: "circle", "grid"
    """
    # Validación mínima
    if not isinstance(nodes_list, (list, tuple)) or not isinstance(links_list, (list, tuple)):
        raise TypeError("nodes_list y links_list deben ser listas/tuplas")
    
    # Verificar que el número de celdas coincida con las filas y columnas
    if len(nodes_list) != nrows * ncols or len(links_list) != nrows * ncols or len(sizes_list) != nrows * ncols:
        raise ValueError("El número de nodos, enlaces o tamaños no coincide con la cantidad de celdas especificadas.")

    html = f"""
    <div style="display: grid; grid-template-columns: repeat({ncols}, 1fr); grid-gap: 20px;">
    """
    
    # Iterar sobre cada celda de la matriz
    for i in range(nrows * ncols):
        nodes = nodes_list[i]  # Nodos para la celda actual
        links = links_list[i]  # Enlaces para la celda actual
        width, height = sizes_list[i]  # Tamaño de la celda actual

        # Creamos el contenedor para cada celda
        html += f"""
        <div class="matrix-cell" style="width:{width}px; height:{height}px; border: 1px solid #ddd; padding: 8px; text-align: center;">
            <h4>Grafo {i+1}</h4>
            <svg width="{width}" height="{height}" style="background-color: #f0f0f0;">
                <g>
        """
        
        pos = {}  # Posiciones de los nodos
        
        if layout == "circle":
            # Layout circular
            cx = width / 2
            cy = height / 2
            radius = min(width, height) / 3  # Un radio relativo a las dimensiones de la celda
            for idx, node in enumerate(nodes):
                angle = 2 * 3.14159 * (idx / len(nodes))  # Ángulo de distribución
                x = cx + radius * math.cos(angle)
                y = cy + radius * math.sin(angle)
                pos[node["id"]] = {"x": x, "y": y}

        elif layout == "grid":
            # Layout en cuadrícula
            rows = 2
            cols = len(nodes) // rows
            for idx, node in enumerate(nodes):
                x = (idx % cols) * (width / cols)
                y = (idx // cols) * (height / rows)
                pos[node["id"]] = {"x": x, "y": y}

        # Dibujamos los enlaces
        for link in links:
            source = link["source"]
            target = link["target"]
            # Filtrar y dibujar las aristas solo si los nodos existen
            source_node = next((node for node in nodes if node["id"] == source), None)
            target_node = next((node for node in nodes if node["id"] == target), None)
            if source_node and target_node:
                # Dibujamos la arista entre los nodos
                x1, y1 = pos[source]["x"], pos[source]["y"]
                x2, y2 = pos[target]["x"], pos[target]["y"]
                html += f"""
                <line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{link_color}" stroke-width="1.5"/>
                """

        # Dibujamos los nodos
        for node in nodes:
            x = pos[node["id"]]["x"]
            y = pos[node["id"]]["y"]
            html += f"""
            <circle cx="{x}" cy="{y}" r="{node_radius}" fill="{node_color}" opacity="0.9"/>
            """

        html += """
                </g>
            </svg>
        </div>
        """
    
    html += "</div>"  # Cierra la grid de la matriz
    return HTML(html)

def show_radar_layout1(nodes, links, width=400, height=300, node_radius=8,
                      node_color="#1976d2", link_color="#999"):
    """
    Layout Radar: distribuye los nodos en círculos concéntricos según su grado
    - Los nodos con mayor grado van en círculos internos
    - Los nodos con menor grado van en círculos externos
    """
    # Validación mínima
    if not isinstance(nodes, (list, tuple)) or not isinstance(links, (list, tuple)):
        raise TypeError("nodes y links deben ser listas/tuplas")
    for i, n in enumerate(nodes):
        if not isinstance(n, dict) or "id" not in n:
            raise ValueError(f"nodes[{i}] debe tener clave 'id'")

    node_ids = {str(n["id"]) for n in nodes}
    clean_links = []
    for j, e in enumerate(links):
        if not isinstance(e, dict) or "source" not in e or "target" not in e:
            raise ValueError(f"links[{j}] debe tener 'source' y 'target'")
        s, t = str(e["source"]), str(e["target"])
        if s in node_ids and t in node_ids:
            clean_links.append({"source": s, "target": t})

    data = {"nodes": nodes, "links": clean_links}
    data_json = json.dumps(data)
    cid = "ourlib-" + uuid.uuid4().hex

    html = f"""
<div id="{cid}" class="ourlib-radar"
     style="display:inline-block; padding:8px; border:1px solid #ddd; border-radius:8px; font-family:system-ui;">
  <div class="viz"></div>
</div>

<script>
(function(){{
    const root = document.getElementById('{cid}');
    const viz = root.querySelector('.viz');
    const data = {data_json};

    const W = {width}, H = {height}, R = {node_radius};
    const NODE_COLOR = "{node_color}";
    const LINK_COLOR = "{link_color}";

    // ===== Calcular grados =====
    const idx = new Map();
    data.nodes.forEach((n, i) => idx.set(String(n.id), i));
    
    const degree = new Array(data.nodes.length).fill(0);
    data.links.forEach(link => {{
        const s = idx.get(String(link.source));
        const t = idx.get(String(link.target));
        if (s !== undefined && t !== undefined) {{
            degree[s]++;
            degree[t]++;
        }}
    }});

    // ===== SVG =====
    const svgNS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('width', W);
    svg.setAttribute('height', H);
    viz.appendChild(svg);

    // ===== Layout Radar =====
    const cx = W/2, cy = H/2;
    const maxRadius = Math.min(W, H)/2 - (R + 20);
    
    // Agrupar nodos por grado
    const nodesByDegree = data.nodes.map((node, i) => ({{
        ...node,
        degree: degree[i],
        index: i
    }})).sort((a, b) => b.degree - a.degree);

    // Asignar radios según el grado (mayor grado = radio más pequeño)
    const uniqueDegrees = [...new Set(nodesByDegree.map(n => n.degree))].sort((a, b) => b - a);
    const radiusMap = new Map();
    
    uniqueDegrees.forEach((deg, i) => {{
        const radius = maxRadius * (0.2 + 0.8 * (i / Math.max(1, uniqueDegrees.length - 1)));
        radiusMap.set(deg, radius);
    }});

    const pos = {{}};
    const nodesInDegree = {{}};
    
    // Agrupar nodos por grado
    nodesByDegree.forEach(node => {{
        const deg = node.degree;
        if (!nodesInDegree[deg]) nodesInDegree[deg] = [];
        nodesInDegree[deg].push(node);
    }});

    // Posicionar nodos en círculos concéntricos
    Object.keys(nodesInDegree).forEach(deg => {{
        const nodesInThisDegree = nodesInDegree[deg];
        const radius = radiusMap.get(parseInt(deg));
        
        nodesInThisDegree.forEach((node, i) => {{
            const angle = (i / nodesInThisDegree.length) * 2 * Math.PI;
            pos[String(node.id)] = {{
                x: cx + radius * Math.cos(angle),
                y: cy + radius * Math.sin(angle)
            }};
        }});
    }});

    // ===== Dibujar enlaces =====
    data.links.forEach(link => {{
        const a = pos[String(link.source)];
        const b = pos[String(link.target)];
        if (!a || !b) return;
        
        const line = document.createElementNS(svgNS, 'line');
        line.setAttribute('x1', a.x);
        line.setAttribute('y1', a.y);
        line.setAttribute('x2', b.x);
        line.setAttribute('y2', b.y);
        line.setAttribute('stroke', LINK_COLOR);
        line.setAttribute('stroke-width', '1.5');
        line.setAttribute('opacity', '0.6');
        svg.appendChild(line);
    }});

    // ===== Dibujar nodos =====
    data.nodes.forEach((node, i) => {{
        const p = pos[String(node.id)];
        if (!p) return;
        
        const c = document.createElementNS(svgNS, 'circle');
        c.setAttribute('cx', p.x);
        c.setAttribute('cy', p.y);
        c.setAttribute('r', R);
        c.setAttribute('fill', NODE_COLOR);
        c.setAttribute('opacity', '0.9');
        
        // Tooltip simple
        c.setAttribute('title', `${{node.id}} (grado: ${{degree[i]}})`);
        svg.appendChild(c);
    }});

    // ===== Dibujar círculos de referencia =====
    uniqueDegrees.forEach(deg => {{
        const radius = radiusMap.get(deg);
        const circle = document.createElementNS(svgNS, 'circle');
        circle.setAttribute('cx', cx);
        circle.setAttribute('cy', cy);
        circle.setAttribute('r', radius);
        circle.setAttribute('fill', 'none');
        circle.setAttribute('stroke', '#eee');
        circle.setAttribute('stroke-dasharray', '2,2');
        svg.appendChild(circle);
    }});

    // Nota
    const note = document.createElement('p');
    note.style.margin = '6px 0 0';
    note.textContent = 'Layout Radar - nodos organizados por grado';
    root.appendChild(note);
}})();
</script>
"""
    return HTML(html)


def show_dashboard_matrix_radar_force7(nodes, links, width=1200, height=900):
    """
    Dashboard con los 3 gráficos ORIGINALES - Versión corregida y adaptable
    (incluye puente JS→Python que funciona en Colab o con Flask local).
    """
    import json, uuid
    from IPython.display import HTML
    
    # IDs únicos
    dashboard_id = "dashboard-" + uuid.uuid4().hex
    radar_id = "radar-" + uuid.uuid4().hex
    force_id = "force-" + uuid.uuid4().hex  
    matrix_id = "matrix-" + uuid.uuid4().hex
    info_id = "info-" + uuid.uuid4().hex
    
    # Preparar datos
    data_json = json.dumps({"nodes": nodes, "links": links}, default=str)

    html = f'''
<div id="{dashboard_id}" style="width: {width}px; font-family: system-ui;">
    
    <div style="text-align: center; margin-bottom: 30px;">
        <h2>Dashboard de Análisis</h2>
        <p>Nodos: {len(nodes)}, Enlaces: {len(links)}</p>
    </div>
    
    <!-- Fila 1: Radar y Force -->
    <div style="display: flex; gap: 20px; margin-bottom: 30px;">
        <!-- Radar -->
        <div style="flex: 1; border: 2px solid #1976d2; padding: 15px; border-radius: 8px;">
            <h4 style="color: #1976d2;">Radar Chart</h4>
            <select id="city-{radar_id}" style="margin-bottom: 10px; width: 100%;">
                <option value="">Seleccionar ciudad...</option>
            </select>
            <div id="viz-radar-{radar_id}" style="width: 100%; height: 400px; border: 1px solid #ccc;"></div>
        </div>
        
        <!-- Force -->
        <div style="flex: 1; border: 2px solid #d32f2f; padding: 15px; border-radius: 8px;">
            <h4 style="color: #d32f2f;">Force Graph</h4>
            <div style="margin-bottom: 10px;">
                <label>Tau: <input type="range" id="tau-{force_id}" min="0" max="1" step="0.01" value="0.5"></label>
                <span id="tauVal-{force_id}">0.50</span>
                <label>TopK: 
                    <select id="topk-{force_id}">
                        <option value="5">5</option>
                        <option value="10">10</option>
                    </select>
                </label>
                <input type="text" id="search-{force_id}" placeholder="Search..." style="margin-left: 10px;">
            </div>
            <div id="viz-force-{force_id}" style="width: 100%; height: 400px; border: 1px solid #ccc;"></div>
            <div id="legend-{force_id}" style="margin-top: 10px;"></div>
        </div>
    </div>
    
    <!-- Matrix -->
    <div style="border: 2px solid #388e3c; padding: 15px; border-radius: 8px; margin-bottom: 30px;">
        <h4 style="color: #388e3c;">Matrix Heatmap</h4>
        <div id="viz-matrix-{matrix_id}" style="width: 100%; height: 500px; border: 1px solid #ccc;"></div>
    </div>

    <!-- Info Panel -->
    <div style="border: 2px solid #7b1fa2; padding: 15px; border-radius: 8px;">
        <h4 style="color: #7b1fa2;">Información del Nodo</h4>
        <div id="{info_id}" style="min-height: 100px; padding: 10px; background: #f8f9fa;">
            <em>Selecciona un nodo...</em>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>

<script>
(function(){{
    console.log("🚀 INICIANDO DASHBOARD...");
    const data = {data_json};
    
    function showNodeInfo(node, source) {{
      const infoDiv = document.getElementById("{info_id}");
      infoDiv.innerHTML = `
        <h5>${{node.name || node.id}}</h5>
        <p><strong>ID:</strong> ${{node.id}}</p>
        <p><strong>Desde:</strong> ${{source}}</p>
        <p><strong>Región:</strong> ${{node.region || 'N/A'}}</p>
      `;
    }}

    // ===== RADAR =====
    function initRadar() {{
        console.log("📊 Iniciando Radar...");
        const container = document.getElementById("viz-radar-{radar_id}");
        const W = container.clientWidth;
        const H = 400;
        const R = Math.min(W, H) * 0.35;

        const svg = d3.select("#viz-radar-{radar_id}")
            .append("svg")
            .attr("width", W)
            .attr("height", H);
            
        const g = svg.append("g")
            .attr("transform", `translate(${{W/2}},${{H/2}})`);

        const scoreCols = ["Food", "Altitude", "Physical activity", "Cultural activity", "Safety", "Costs", "Weather",
            "Outdoor/nature", "Party", "Open culture", "Mobility", "Accessibility", "Adventure/Adrenaline"];

        const angle = d3.scaleLinear().domain([0, scoreCols.length]).range([0, 2 * Math.PI]);
        const radius = d3.scaleLinear().domain([0, 5]).range([0, R]);

        const line = d3.lineRadial().curve(d3.curveLinearClosed)
            .angle((d, i) => angle(i))
            .radius(d => radius(d));

        const citySel = document.getElementById("city-{radar_id}");

        // Llenar selector
        data.nodes.forEach(n => {{
            const opt = document.createElement("option");
            opt.value = n.id;
            opt.textContent = n.name || n.id;
            citySel.appendChild(opt);
        }});

        const avg = scoreCols.map(c => d3.mean(data.nodes, n => +n[c] || 0));

        function draw(id){{
            const n = data.nodes.find(x => x.id === id);
            if (!n) return;
            
            const vals = scoreCols.map(c => +n[c] || 0);
            g.selectAll("*").remove();

            // Círculos de referencia
            [1, 2, 3, 4, 5].forEach(k => {{
                g.append("circle")
                    .attr("r", radius(k))
                    .attr("fill", "none")
                    .attr("stroke", "#ddd");
            }});

            // Ejes
            scoreCols.forEach((c, i) => {{
                const a = angle(i) - Math.PI / 2;
                g.append("line")
                    .attr("x1", 0).attr("y1", 0)
                    .attr("x2", Math.cos(a) * R).attr("y2", Math.sin(a) * R)
                    .attr("stroke", "#eee");
            }});

            // Promedio y ciudad
            g.append("path").datum(avg).attr("d", line)
                .attr("fill", "#6baed6").attr("fill-opacity", 0.15)
                .attr("stroke", "#6baed6").attr("stroke-width", 1.5);

            g.append("path").datum(vals).attr("d", line)
                .attr("fill", "#fd8d3c").attr("fill-opacity", 0.25)
                .attr("stroke", "#e6550d").attr("stroke-width", 2.0);

            showNodeInfo(n, "Radar");
        }}

        citySel.addEventListener("change", () => draw(citySel.value));
        if (data.nodes.length > 0) draw(data.nodes[0].id);
    }}

    // ===== FORCE =====
    function initForce() {{
        console.log("🔗 Iniciando Force...");
        const container = document.getElementById("viz-force-{force_id}");
        const W = container.clientWidth;
        const H = 400;

        const svg = d3.select("#viz-force-{force_id}")
            .append("svg")
            .attr("width", W)
            .attr("height", H);

        // SIMPLIFICADO: posicionamiento aleatorio
        const nodes = data.nodes.slice(0, 15).map((d, i) => ({{
            ...d,
            x: Math.random() * (W - 100) + 50,
            y: Math.random() * (H - 100) + 50
        }}));

        // Enlaces simples
        const links = [];
        for (let i = 0; i < nodes.length - 1; i++) {{
            if (i % 2 === 0) {{
                links.push({{
                    source: nodes[i].id,
                    target: nodes[i + 1].id,
                    similarity: 0.5
                }});
            }}
        }}

        // Dibujar enlaces
        svg.selectAll("line")
            .data(links)
            .enter().append("line")
            .attr("stroke", "#999")
            .attr("stroke-width", 2)
            .attr("stroke-opacity", 0.6)
            .attr("x1", d => nodes.find(n => n.id === d.source).x)
            .attr("y1", d => nodes.find(n => n.id === d.source).y)
            .attr("x2", d => nodes.find(n => n.id === d.target).x)
            .attr("y2", d => nodes.find(n => n.id === d.target).y);

        // Dibujar nodos
        const nodeElements = svg.selectAll("g.node")
            .data(nodes)
            .enter().append("g")
            .attr("class", "node");

        nodeElements.append("circle")
            .attr("r", 8)
            .attr("fill", d => d.region ? d3.schemeTableau10[0] : "#1976d2")
            .attr("stroke", "#fff")
            .attr("stroke-width", 2)
            .attr("cx", d => d.x)
            .attr("cy", d => d.y)
            .style("cursor", "pointer")
            .on("click", function(event, d) {{
                showNodeInfo(d, "Force Graph");
                d3.select(this).attr("fill", "red");

                const payload = {{ ...d, __ts: new Date().toISOString(), __src: "force" }};

                // ======= Enviar nodo a Python (Colab o Flask local) =======
                (function sendToPython(payload) {{
                  const inColab = !!(window.google && google.colab && google.colab.kernel && google.colab.kernel.invokeFunction);
                  if (inColab) {{
                    // Colab: requiere enable_colab_bridge() en Python
                    google.colab.kernel.invokeFunction('ourlib.update_node', [payload], {{}})
                      .catch(err => console.warn('Colab bridge error:', err));
                  }} else {{
                    const body = JSON.stringify({{ node: payload }});
                    // Intento 1: localhost normal
                    fetch('http://127.0.0.1:5000/update_node', {{
                      method: 'POST',
                      headers: {{ 'Content-Type': 'application/json' }},
                      body
                    }}).catch(() => {{
                      // Intento 2: proxy típico de Jupyter
                      fetch('/proxy/5000/update_node', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body
                      }}).catch(err => console.warn('Fetch bridge failed:', err));
                    }});
                  }}
                }})(payload);
            }});

        nodeElements.append("text")
            .text(d => d.name || d.id)
            .attr("x", d => d.x + 12)
            .attr("y", d => d.y + 4)
            .attr("font-size", "10px")
            .attr("fill", "#333");

        console.log("✅ Force simplificado listo");
    }}

    // ===== MATRIX =====
    function initMatrix() {{
        console.log("🔲 Iniciando Matrix...");
        const container = document.getElementById("viz-matrix-{matrix_id}");
        const W = container.clientWidth;
        const H = 500;

        const svg = d3.select("#viz-matrix-{matrix_id}")
            .append("svg")
            .attr("width", W)
            .attr("height", H);

        // Matriz simple para demostración
        const size = Math.min(10, data.nodes.length);
        const cellSize = Math.min(W, H) / size;

        for (let i = 0; i < size; i++) {{
            for (let j = 0; j < size; j++) {{
                const value = i === j ? 1 : Math.random();
                const color = d3.interpolateBlues(value);
                
                svg.append("rect")
                    .attr("x", j * cellSize)
                    .attr("y", i * cellSize)
                    .attr("width", cellSize - 2)
                    .attr("height", cellSize - 2)
                    .attr("fill", color)
                    .attr("stroke", "#fff")
                    .on("click", function() {{
                        const nodeIndex = i % data.nodes.length;
                        const node = data.nodes[nodeIndex];
                        showNodeInfo(node, "Matrix");
                    }});
            }}
        }}

        svg.append("text")
            .attr("x", W/2)
            .attr("y", 20)
            .attr("text-anchor", "middle")
            .attr("font-weight", "bold")
            .text("Matrix Heatmap");

        console.log("✅ Matrix listo");
    }}

    // INICIALIZAR TODO
    setTimeout(() => {{
        console.log("🎯 Inicializando gráficos...");
        try {{
            initRadar();
            initForce();
            initMatrix();
            console.log("✅ TODOS los gráficos inicializados");
        }} catch (error) {{
            console.error("❌ Error:", error);
        }}
    }}, 100);
    
}})();
</script>
'''
    return HTML(html)



# --- NEW: dashboard enlazado (force + radar + scatter con brush) ---
from IPython.display import HTML
import json, uuid

def show_linked_dashboard(nodes, links, width=1200):
    """
    Dashboard enlazado:
    - Force: click selecciona (click simple = solo ese; Ctrl/Cmd+click = toggle)
    - Scatter (Costs vs Safety): brush para multiselección
    - Radar: muestra promedio global + seleccionado(s)
    - Todo queda sincronizado en tiempo real; envía payloads a Python (Colab/Flask) en cada click.
    """
    data_json = json.dumps({"nodes": nodes, "links": links}, default=str)
    dash_id   = "dash-"   + uuid.uuid4().hex
    force_id  = "force-"  + uuid.uuid4().hex
    radar_id  = "radar-"  + uuid.uuid4().hex
    scat_id   = "scat-"   + uuid.uuid4().hex
    info_id   = "info-"   + uuid.uuid4().hex
    ctr_id    = "ctr-"    + uuid.uuid4().hex
    clear_id  = "clear-"  + uuid.uuid4().hex

    html = f"""
<div id="{dash_id}" style="width:{width}px; font-family:system-ui; margin:auto;">
  <div style="display:flex; align-items:center; gap:12px; margin:6px 0 12px;">
    <strong>Seleccionados:</strong>
    <span id="{ctr_id}">0</span>
    <button id="{clear_id}">Clear</button>
  </div>

  <div style="display:grid; grid-template-columns: 1fr 1fr; gap:18px; margin-bottom:18px;">
    <div style="border:2px solid #d32f2f; border-radius:8px; padding:10px;">
      <h4 style="margin:4px 0; color:#d32f2f">Force (click para seleccionar)</h4>
      <div id="{force_id}" style="height:420px; border:1px solid #ccc;"></div>
    </div>

    <div style="border:2px solid #1976d2; border-radius:8px; padding:10px;">
      <h4 style="margin:4px 0; color:#1976d2">Radar (promedios dinámicos)</h4>
      <div id="{radar_id}" style="height:420px; border:1px solid #ccc;"></div>
    </div>
  </div>

  <div style="border:2px solid #388e3c; border-radius:8px; padding:10px;">
    <h4 style="margin:4px 0; color:#388e3c">Scatter (Costs vs Safety · brush para multi-selección)</h4>
    <div id="{scat_id}" style="height:420px; border:1px solid #ccc;"></div>
  </div>

  <div style="margin-top:14px; border:1px dashed #aaa; border-radius:6px; padding:10px;">
    <div id="{info_id}" style="min-height:40px; color:#444;">Selecciona un nodo para ver detalles aquí…</div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script>
(function(){{
  const data   = {data_json};
  const FORCE  = document.getElementById("{force_id}");
  const RADAR  = document.getElementById("{radar_id}");
  const SCAT   = document.getElementById("{scat_id}");
  const INFO   = document.getElementById("{info_id}");
  const CTR    = document.getElementById("{ctr_id}");
  const CLEAR  = document.getElementById("{clear_id}");
  const Wf = FORCE.clientWidth, Hf = 420;
  const Wr = RADAR.clientWidth, Hr = 420;
  const Ws = SCAT.clientWidth,  Hs = 420;

  // --------------------- Store compartido ---------------------
  const Store = (() => {{
    const sel = new Set();
    const listeners = new Set();
    function emit() {{ for (const fn of listeners) fn(); CTR.textContent = String(sel.size); }}
    return {{
      get: ()=> new Set(sel),
      replace: ids => {{ sel.clear(); ids.forEach(id=>sel.add(id)); emit(); }},
      toggle: id => {{ sel.has(id)? sel.delete(id): sel.add(id); emit(); }},
      clear: ()=> {{ sel.clear(); emit(); }},
      on: fn => listeners.add(fn),
      off: fn => listeners.delete(fn),
    }};
  }})();
  CLEAR.addEventListener('click', ()=> Store.clear());

  // ---- Bridge JS→Python (Colab/Flask) ----
  function sendToPython(payload){{
    try {{
      const inColab = !!(window.google && google.colab && google.colab.kernel && google.colab.kernel.invokeFunction);
      if (inColab) {{
        google.colab.kernel.invokeFunction('ourlib.update_node', [payload], {{}})
          .catch(err => console.warn('Colab bridge error:', err));
      }} else {{
        fetch('http://127.0.0.1:5000/update_node', {{
          method: 'POST',
          headers: {{ 'Content-Type': 'application/json' }},
          body: JSON.stringify({{ node: payload }})
        }}).catch(()=>{{
          fetch('/proxy/5000/update_node', {{
            method: 'POST',
            headers: {{ 'Content-Type': 'application/json' }},
            body: JSON.stringify({{ node: payload }})
          }}).catch(err => console.warn('Fetch bridge failed:', err));
        }});
      }}
    }} catch(e) {{ console.warn('sendToPython failed:', e); }}
  }}

  // ---- Colores por región ----
  const regions = Array.from(new Set((data.nodes||[]).map(d => d.region||'UNK')));
  const colorByRegion = d3.scaleOrdinal().domain(regions).range(d3.schemeTableau10);

  // ---- Panel info ----
  function showInfo(node, source){{
    if (!node) {{ INFO.textContent=''; return; }}
    INFO.innerHTML = `
      <div><strong>${{node.name||node.id}}</strong></div>
      <div>ID: ${{node.id}}</div>
      <div>Región: ${{node.region||'N/A'}} · Fuente: ${{source}}</div>
      <div><a href="${{node.url||'#'}}" target="_blank" rel="noopener">Ver ficha</a></div>
    `;
  }}

  // --------------------- FORCE ---------------------
  (function initForce(){{
    const svg = d3.select(FORCE).append('svg').attr('width', Wf).attr('height', Hf);
    const sim = d3.forceSimulation(data.nodes)
      .force('link', d3.forceLink(data.links).id(d=>String(d.id)).distance(60))
      .force('charge', d3.forceManyBody().strength(-160))
      .force('center', d3.forceCenter(Wf/2, Hf/2));

    const link = svg.append('g').attr('stroke', '#999').attr('stroke-opacity', .6)
      .selectAll('line').data(data.links).join('line').attr('stroke-width', 1.5);

    const node = svg.append('g').selectAll('circle').data(data.nodes).join('circle')
      .attr('r', 7)
      .attr('fill', d => colorByRegion(d.region||'UNK'))
      .attr('stroke', '#fff').attr('stroke-width', 1.5)
      .style('cursor', 'pointer')
      .on('click', (event, d) => {{
        if (event.metaKey || event.ctrlKey) Store.toggle(d.id);
        else Store.replace([d.id]);
        showInfo(d, 'Force');
        sendToPython({{ ...d, __ts: new Date().toISOString(), __src: 'force' }});
        event.stopPropagation();
      }})
      .call(d3.drag()
        .on('start', (event, d) => {{
          if (!event.active) sim.alphaTarget(0.3).restart();
          d.fx = d.x; d.fy = d.y;
        }})
        .on('drag', (event, d) => {{ d.fx = event.x; d.fy = event.y; }})
        .on('end',  (event, d) => {{
          if (!event.active) sim.alphaTarget(0);
          d.fx = null; d.fy = null;
        }}));

    sim.on('tick', ()=>{{
      link.attr('x1', d=>d.source.x).attr('y1', d=>d.source.y)
          .attr('x2', d=>d.target.x).attr('y2', d=>d.target.y);
      node.attr('cx', d=>d.x).attr('cy', d=>d.y);
    }});

    Store.on(() => {{
      const sel = Store.get();
      node.attr('opacity', d => sel.size===0 || sel.has(d.id) ? 1 : 0.2)
          .attr('stroke-width', d => sel.has(d.id) ? 3 : 1.5);
      link.attr('opacity', e => (sel.size===0 || (sel.has(e.source.id||e.source) && sel.has(e.target.id||e.target))) ? 0.6 : 0.1);
    }});

    svg.on('click', (e)=>{{ if (e.target===svg.node()) Store.clear(); }});
  }})();

  // --------------------- RADAR ---------------------
  (function initRadar(){{
    const cols = ["Food","Altitude","Physical activity","Cultural activity","Safety","Costs","Weather","Outdoor/nature","Party","Open culture","Mobility","Accessibility","Adventure/Adrenaline"];
    const W = Wr, H = Hr, R = Math.min(W,H)*0.38;
    const svg = d3.select(RADAR).append('svg').attr('width', W).attr('height', H);
    const g = svg.append('g').attr('transform', `translate(${{W/2}},${{H/2}})`);
    const angle = d3.scaleLinear().domain([0, cols.length]).range([0, 2*Math.PI]);
    const radius= d3.scaleLinear().domain([0,5]).range([0, R]);
    const line  = d3.lineRadial().curve(d3.curveLinearClosed).angle((d,i)=>angle(i)).radius(d=>radius(d));

    [1,2,3,4,5].forEach(k => g.append('circle').attr('r', radius(k)).attr('fill','none').attr('stroke','#eee'));
    cols.forEach((c,i) => {{
      const a = angle(i)-Math.PI/2;
      g.append('line').attr('x1',0).attr('y1',0).attr('x2',Math.cos(a)*R).attr('y2',Math.sin(a)*R).attr('stroke','#f4f4f4');
      const tx = Math.cos(a)* (R+10), ty = Math.sin(a)*(R+10);
      svg.append('text').attr('x', W/2 + tx).attr('y', H/2 + ty).attr('text-anchor','middle').attr('font-size',10).text(c);
    }});

    const avgAll = cols.map(c => d3.mean(data.nodes, n => +n[c] || 0));
    const areaAvg = g.append('path').attr('fill','#90caf9').attr('fill-opacity',.18).attr('stroke','#64b5f6').attr('stroke-width',1.5);
    const areaSel = g.append('path').attr('fill','#ffb74d').attr('fill-opacity',.22).attr('stroke','#fb8c00').attr('stroke-width',2);
    const linesSel = g.append('g').attr('stroke','#fb8c00').attr('stroke-opacity',.4).attr('fill','none');

    function polygon(values){{ return line(values); }}
    function profileOf(node){{ return cols.map(c => +node[c]||0); }}

    function render(){{
      const sel = Store.get();
      areaAvg.attr('d', polygon(avgAll));
      linesSel.selectAll('path').remove();

      if (sel.size===0){{
        areaSel.attr('d', polygon(new Array(cols.length).fill(0))).attr('opacity',0);
        return;
      }}
      const selNodes = data.nodes.filter(n => sel.has(n.id));
      const avgSel   = cols.map(c => d3.mean(selNodes, n => +n[c]||0));
      areaSel.attr('opacity',1).attr('d', polygon(avgSel));

      if (sel.size>1){{
        linesSel.selectAll('path').data(selNodes).join('path').attr('d', d => polygon(profileOf(d)));
      }}
    }}

    Store.on(render);
    render();
  }})();

  // --------------------- SCATTER + Brush ---------------------
  (function initScatter(){{
    const xField = 'Costs', yField = 'Safety';
    const margin = {{top:20,right:20,bottom:40,left:40}};
    const W = Ws - margin.left - margin.right;
    const H = Hs - margin.top - margin.bottom;

    const svg = d3.select(SCAT).append('svg').attr('width', Ws).attr('height', Hs);
    const g = svg.append('g').attr('transform', `translate(${{margin.left}},${{margin.top}})`);

    const x = d3.scaleLinear().domain([0,5]).range([0,W]);
    const y = d3.scaleLinear().domain([0,5]).range([H,0]);
    const r = d3.scaleSqrt().domain([1,10]).range([3,12]); // tamaño por want_to_go

    g.append('g').attr('transform', `translate(0,${{H}})`).call(d3.axisBottom(x).ticks(5));
    g.append('g').call(d3.axisLeft(y).ticks(5));
    g.append('text').attr('x', W/2).attr('y', H+32).attr('text-anchor','middle').text(xField);
    g.append('text').attr('x', -H/2).attr('y', -28).attr('transform','rotate(-90)').attr('text-anchor','middle').text(yField);

    const pts = g.selectAll('circle').data(data.nodes).join('circle')
      .attr('cx', d => x(+d[xField]||0))
      .attr('cy', d => y(+d[yField]||0))
      .attr('r',  d => r(+d.want_to_go||1))
      .attr('fill', d => colorByRegion(d.region||'UNK'))
      .attr('stroke', '#fff').attr('stroke-width', 1.2)
      .attr('opacity', 0.9).style('cursor','pointer')
      .on('click', (event, d) => {{
        if (event.metaKey || event.ctrlKey) Store.toggle(d.id);
        else Store.replace([d.id]);
        showInfo(d, 'Scatter');
        sendToPython({{ ...d, __ts: new Date().toISOString(), __src: 'scatter' }});
        event.stopPropagation();
      }});

    const brush = d3.brush()
      .extent([[0,0],[W,H]])
      .on('end', (event) => {{
        if (!event.selection) return;
        const [[x0,y0],[x1,y1]] = event.selection;
        const ids = data.nodes.filter(d => {{
          const px = x(+d[xField]||0), py = y(+d[yField]||0);
          return x0 <= px && px <= x1 && y0 <= py && py <= y1;
        }}).map(d => d.id);
        if (ids.length) Store.replace(ids);
        g.call(brush.move, null);
      }});
    g.append('g').call(brush);

    Store.on(() => {{
      const sel = Store.get();
      pts.attr('opacity', d => sel.size===0 || sel.has(d.id) ? 1 : 0.2)
         .attr('stroke-width', d => sel.has(d.id) ? 3 : 1.2);
    }});

    svg.on('click', (e)=>{{ if (e.target===svg.node()) Store.clear(); }});
  }})();
}})();
</script>
"""
    return HTML(html)



def show_dashboard_map_force_radar_linked(nodes, links, width=1200, height=900, grid_cols=2, grid_rows=2):
    """
    Dashboard linkeado (configurable en columnas y filas):
     - Force (click)  ↔  Mapa Perú (brush/click)  ↔  Radar (1=ciudad, >1=promedio)
     - JS→Python bridge (Colab o Flask local) en cada click
    Layout:
     - grid_cols=2  ->  Número de columnas en la grilla (por defecto 2)
     - grid_rows=2  ->  Número de filas en la grilla (por defecto 2)
    """
    import json, uuid
    from IPython.display import HTML

    dash_id   = "dash-"   + uuid.uuid4().hex
    force_id  = "force-"  + uuid.uuid4().hex
    map_id    = "map-"    + uuid.uuid4().hex
    radar_id  = "radar-"  + uuid.uuid4().hex
    info_id   = "info-"   + uuid.uuid4().hex

    data_json = json.dumps({"nodes": nodes, "links": links}, default=str)

    # Filtrar Top-3 conexiones por nodo
    filtered_links = []
    for node in nodes:
        outgoing = [l for l in links if l["source"] == node["id"]]
        incoming = [l for l in links if l["target"] == node["id"]]
        top3 = sorted(outgoing + incoming, key=lambda x: x["similarity"], reverse=True)[:3]
        filtered_links.extend(top3)
    
    # Quitamos duplicados que pueden surgir del filtrado
    filtered_links = list({json.dumps(l, sort_keys=True): l for l in filtered_links}.values())


    html = f"""
<div id="{dash_id}" style="
  width:{width}px; font-family:system-ui;
  display:grid; grid-template-columns:repeat({grid_cols}, 1fr);
  grid-template-rows:repeat({grid_rows}, 1fr);
  gap:18px; align-items:start;">

  <div style="border:3px solid #d32f2f; border-radius:12px; padding:10px; min-height:450px;">
    <h3 style="margin:0 0 6px;">Graph</h3>
    <div style="font-size:11px; margin-bottom:5px; display:flex; flex-direction:column; align-items:flex-start; gap:4px;">
      <span>Conexiones: Top 3. <strong>Grosor y color</strong> = Nivel de similaridad</span>
      <span style="font-size:10px; white-space:nowrap;">(Menos
        <span style="display:inline-block; width:30px; height:5px; background:linear-gradient(to right, #f7fbff, #08306b); border:1px solid #ccc; vertical-align:middle;"></span>
      Más)</span>
    </div>
    <div id="{force_id}" style="width:100%; height:450px; border:1px solid #ccc;"></div>
  </div>

  <div style="border:3px solid #2e7d32; border-radius:12px; padding:10px; min-height:450px;">
    <h3 style="margin:0 0 6px;">Map</h3>
    <div id="{map_id}" style="width:100%; height:450px; border:1px solid #ccc;"></div>
    <div style="display:flex; gap:15px; margin-top:10px; font-size:12px;">
      <span><span style="color:#fbc02d; font-size:1.2em; -webkit-text-stroke: 1px #ccc;">●</span> Costa</span>
      <span><span style="color:#8D6E63; font-size:1.2em; -webkit-text-stroke: 1px #ccc;">●</span> Sierra</span>
      <span><span style="color:#4CAF50; font-size:1.2em; -webkit-text-stroke: 1px #ccc;">●</span> Selva</span>
    </div>
  </div>

  <div style="border:3px solid #1976d2; border-radius:12px; padding:10px; min-height:420px;">
    <h3 style="margin:0 0 6px;">Radar</h3>
    <div id="{radar_id}" style="width:100%; height:420px; border:1px solid #ccc;"></div>
    <div style="margin-top:10px;">
      <p style="font-size:12px;">
        <span style="color:#6baed6; font-size:1.2em;">■</span> Promedio Global &nbsp;
        <span style="color:#ff7f0e; font-size:1.2em;">■</span> Ciudades (ver "Selection")
      </p>
    </div>
  </div>

  <div style="border:3px solid #7b1fa2; border-radius:12px; padding:10px; min-height:420px;">
    <h3 style="margin:0 0 6px;">Selection</h3>
    <div id="{info_id}" style="min-height:420px; background:#f8f9fa; padding:10px; overflow:auto;">
      <em>Haz click en el Force o usa el brush en el mapa…</em>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script src="https://cdn.jsdelivr.net/npm/topojson-client@3"></script>

<script>
(function() {{
  const data = {data_json};
  const filteredLinks = {json.dumps(filtered_links, default=str)};

  // ===== Bridge JS→Python (Colab o Flask local) =====
  function _sendToPython(payload) {{
    try {{
      const inColab = !!(window.google && google.colab && google.colab.kernel && google.colab.kernel.invokeFunction);
      if (inColab) {{
        google.colab.kernel.invokeFunction('ourlib.update_node', [payload], {{}})
          .catch(err => console.warn('Colab bridge error:', err));
      }} else {{
        const body = JSON.stringify({{ node: payload }});
        fetch('http://127.0.0.1:5000/update_node', {{
          method: 'POST', headers: {{ 'Content-Type': 'application/json' }}, body
        }}).catch(() => {{
          fetch('/proxy/5000/update_node', {{
            method: 'POST', headers: {{ 'Content-Type': 'application/json' }}, body
          }}).catch(err => console.warn('Fetch bridge failed:', err));
        }});
      }}
    }} catch(e) {{
      console.warn('sendToPython failed:', e);
    }}
  }}
  const sendToPython = _sendToPython;
  window.sendToPython = _sendToPython;

  // ====== EventBus + estado compartido ======
  const bus = new EventTarget();
  // Usar un Array para preservar el orden de selección para la ruta del mapa
  const state = {{ selected: [] }}; 
  const byId = new Map(data.nodes.map(d => [String(d.id), d]));

  // --- Colores fijos para Costa/Sierra/Selva ---
  const zoneMap = {{
    // Costa (Amarillo/Naranja)
    "LIMA":       {{ zone: "Costa", scale: d3.scaleSequential(d3.interpolateRgb("#fff9c4", "#fbc02d")).domain([0, 1]) }},
    "ICA":        {{ zone: "Costa", scale: d3.scaleSequential(d3.interpolateRgb("#fff9c4", "#fbc02d")).domain([0, 1]) }},
    "LALIBERTAD": {{ zone: "Costa", scale: d3.scaleSequential(d3.interpolateRgb("#fff9c4", "#fbc02d")).domain([0, 1]) }},
    "LAMBAYEQUE": {{ zone: "Costa", scale: d3.scaleSequential(d3.interpolateRgb("#fff9c4", "#fbc02d")).domain([0, 1]) }},
    "PIURA":      {{ zone: "Costa", scale: d3.scaleSequential(d3.interpolateRgb("#fff9c4", "#fbc02d")).domain([0, 1]) }},
    // Sierra (Marrón)
    "ANCASH":     {{ zone: "Sierra", scale: d3.scaleSequential(d3.interpolateRgb("#d7ccc8", "#8D6E63")).domain([0, 1]) }},
    "AREQUIPA":   {{ zone: "Sierra", scale: d3.scaleSequential(d3.interpolateRgb("#d7ccc8", "#8D6E63")).domain([0, 1]) }},
    "PUNO":       {{ zone: "Sierra", scale: d3.scaleSequential(d3.interpolateRgb("#d7ccc8", "#8D6E63")).domain([0, 1]) }},
    "CUSCO":      {{ zone: "Sierra", scale: d3.scaleSequential(d3.interpolateRgb("#d7ccc8", "#8D6E63")).domain([0, 1]) }},
    // Selva (Verde)
    "LORETO":       {{ zone: "Selva", scale: d3.scaleSequential(d3.interpolateRgb("#c8e6c9", "#4CAF50")).domain([0, 1]) }},
    "AMAZONAS":     {{ zone: "Selva", scale: d3.scaleSequential(d3.interpolateRgb("#c8e6c9", "#4CAF50")).domain([0, 1]) }},
    "MADREDEDIOS":  {{ zone: "Selva", scale: d3.scaleSequential(d3.interpolateRgb("#c8e6c9", "#4CAF50")).domain([0, 1]) }},
    // Fallback
    "DEFAULT":    {{ zone: "Other", scale: d3.scaleSequential(d3.interpolateGreys).domain([0, 1]) }}
  }};

  // Helper para obtener el color (normaliza 'want_to_go' de 4-9 a 0-1)
  function getNodeColor(d) {{
    const mapping = zoneMap[d.region] || zoneMap["DEFAULT"];
    const val = (+d.want_to_go - 4) / 5; // (val - min) / (max - min)
    return mapping.scale(val || 0.5);
  }}

  // --- Escala de colores para el Radar ---
  const radarColors = d3.scaleOrdinal(d3.schemeCategory10);

  // setSelection ahora maneja un array ordenado
  function setSelection(ids, src) {{
    const uniqueIds = [];
    const seen = new Set();
    for (const id of ids.map(String)) {{
      if (!seen.has(id)) {{
        uniqueIds.push(id);
        seen.add(id);
      }}
    }}
    state.selected = uniqueIds; // Guardar como array
    bus.dispatchEvent(new CustomEvent('selection', {{ detail: {{ ids: state.selected, src }} }}));
  }}

  // toggleOne ahora maneja un array ordenado
  function toggleOne(id, src) {{
    const strId = String(id);
    const currentIds = Array.from(state.selected); // Copia del estado actual
    const index = currentIds.indexOf(strId);
    
    if (index > -1) {{
      currentIds.splice(index, 1);
    }} else {{
      currentIds.push(strId);
    }}
    setSelection(currentIds, src);
  }}

  // ====== Panel info (AHORA CON LEYENDA DE RADAR) ======
  function renderInfo(ids) {{
    const box = document.getElementById("{info_id}");
    if (!ids.length) {{ box.innerHTML = "<em>Sin selección</em>"; return; }}
    const items = ids.map(id => byId.get(String(id))).filter(Boolean);
    const lis = items.map(n => {{
      const nm = (n.name || n.id);
      const reg = (n.region || "");
      const link = n.url ? ('<a href="' + n.url + '" target="_blank" rel="noopener noreferrer">' + nm + '</a>') : nm;
      
      const color = radarColors(n.id);
      // Corrección de f-string: se escapa ${{...}}
      const swatch = `<span style="color:${{color}}; font-size:1.2em; -webkit-text-stroke: 1px #ccc;">●</span> `;
      
      return '<li>' + swatch + '<strong>' + link + '</strong>' + (reg ? ' · ' + reg : '') + '</li>';
    }}).join("");
    box.innerHTML = '<p><strong>' + ids.length + '</strong> seleccionado(s):</p><ul>' + lis + '</ul>';
  }}

  // ====== FORCE (CON GROSOR Y COLOR MEJORADOS) ======
  (function initForce() {{
    const host = document.getElementById("{force_id}");
    const W = host.clientWidth, H = 450;
    const svg = d3.select(host).append("svg").attr("width", W).attr("height", H);
    const g = svg.append("g");

    // --- NUEVO: Escalas para grosor y color de links ---
    const simExtent = d3.extent(filteredLinks, d => d.similarity);
    const linkWidthScale = d3.scaleLinear().domain(simExtent).range([1, 4]); // Rango de 1px a 4px
    const linkColorScale = d3.scaleSequential(d3.interpolateBlues).domain(simExtent); // Rango de color maximizado
    // --- FIN NUEVO ---

    const sim = d3.forceSimulation(data.nodes.map(d => Object.assign({{}}, d)))
      .force('link', d3.forceLink(filteredLinks).id(d => String(d.id)).distance(70))
      .force('charge', d3.forceManyBody().strength(-200))
      .force('center', d3.forceCenter(W/2, H/2));

    const link = g.append('g').attr('stroke', '#999').attr('stroke-opacity', 0.4)
      .selectAll('line').data(filteredLinks).join('line')
      // --- MODIFICADO: Usar escalas dinámicas ---
      .attr('stroke-width', d => linkWidthScale(d.similarity))
      .attr('stroke', d => linkColorScale(d.similarity));
    
    // Corrección de f-string: se escapa ${{...}}
    link.append('title')
      .text(d => `Similaridad: ${{d.similarity.toFixed(2)}}`);

    const nodeG = g.append('g').selectAll('g').data(sim.nodes()).join('g').style("cursor","pointer");

    nodeG.append('circle')
      .attr('r', 8)
      .attr('fill', d => getNodeColor(d))
      .attr('stroke', '#fff').attr('stroke-width', 2)
      .call(d3.drag().on("drag", (event, d) => {{ d.x += event.dx; d.y += event.dy; sim.alpha(0.3).restart(); }}))
      .on('click', (ev, d) => {{
        toggleOne(d.id, 'force');
        sendToPython(Object.assign({{}}, d, {{ __ts: new Date().toISOString(), __src: 'force' }}));
      }});

    nodeG.append('text')
      .attr('x', 12).attr('y', 4).attr('font-size', '11px').attr('fill', '#222')
      .style('paint-order', 'stroke').style('stroke', 'white').style('stroke-width', '3px')
      .text(d => d.name || d.id);

    sim.on('tick', () => {{
      link.attr('x1', d => d.source.x).attr('y1', d => d.source.y)
          .attr('x2', d => d.target.x).attr('y2', d => d.target.y);
      nodeG.attr('transform', d => 'translate(' + d.x + ',' + d.y + ')');
    }});

    bus.addEventListener('selection', e => {{
      const sel = new Set(e.detail.ids), has = sel.size > 0;
      nodeG.select('circle')
        .attr('opacity', d => !has || sel.has(String(d.id)) ? 1.0 : 0.25)
        .attr('stroke',  d => sel.has(String(d.id)) ? '#d32f2f' : '#fff')
        .attr('stroke-width', d => sel.has(String(d.id)) ? 3 : 2);
      // --- MODIFICADO: Opacidad del link al seleccionar ---
      link
        .attr('stroke-opacity', d => {{
          if (!has) return 0.25;
          const s = String(d.source.id || d.source), t = String(d.target.id || d.target);
          return (sel.has(s) || sel.has(t)) ? 0.6 : 0.08; // Más opaco al seleccionar
        }})
        .attr('stroke-width', d => {{
          if (!has) return linkWidthScale(d.similarity);
          const s = String(d.source.id || d.source), t = String(d.target.id || d.target);
          // Opcional: hacer más gruesa la línea seleccionada
          return (sel.has(s) || sel.has(t)) ? linkWidthScale(d.similarity) * 1.5 : linkWidthScale(d.similarity);
        }});
    }});
  }})();

  // ====== MAPA (CON COLOR FIJO Y CAPAS CORREGIDAS) ======
  (function initMap() {{
    const host = document.getElementById("{map_id}");
    const W = host.clientWidth, H = 450;
    const svg = d3.select(host).append("svg").attr("width", W).attr("height", H);
    const gMap = svg.append("g");

    d3.json("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json").then(world => {{
      
      const countries = topojson.feature(world, world.objects.countries);
      const peru = countries.features.find(f => f.id === "604") || countries.features.find(f => f.properties.name === "Peru");

      const proj = d3.geoMercator().fitExtent([[20,20],[W-20,H-20]], peru);
      const path = d3.geoPath(proj);

      const lineGen = d3.line()
        .x(d => proj([+d.lon, +d.lat])[0])
        .y(d => proj([+d.lon, +d.lat])[1]);

      // 1. DIBUJAR EL FONDO DEL MAPA (PRIMERO)
      gMap.append("path").datum(peru)
        .attr("d", path).attr("fill", "#f3f6ff")
        .attr("stroke", "#9db2ff").attr("stroke-width", 1.0);

      // 2. DIBUJAR LA RUTA (SEGUNDO, ENCIMA DEL MAPA)
      const routePath = gMap.append("path")
        .attr("fill", "none")
        .attr("stroke", "#d32f2f")
        .attr("stroke-width", 2.5)
        .attr("stroke-dasharray", "5 5")
        .style("pointer-events", "none"); 

      const pts = data.nodes.filter(d => Number.isFinite(+d.lat) && Number.isFinite(+d.lon));

      // 3. DIBUJAR LOS NODOS (TERCERO, ENCIMA DE LA RUTA)
      const nodeG = gMap.append("g").selectAll("g")
        .data(pts, d => d.id)
        .join("g")
        .attr("transform", d => "translate(" + proj([+d.lon, +d.lat])[0] + "," + proj([+d.lon, +d.lat])[1] + ")")
        .style("cursor", "pointer")
        .on("click", (ev, d) => {{
            toggleOne(d.id, 'map-click');
            sendToPython(Object.assign({{}}, d, {{ __ts: new Date().toISOString(), __src: 'map' }}));
        }});

      nodeG.append("circle")
        .attr("r", 6)
        .attr("fill", d => getNodeColor(d))
        .attr("stroke", "#fff").attr("stroke-width", 1.5);

      nodeG.append("text")
        .attr("x", 9)
        .attr("y", 4)
        .attr("font-size", "10px")
        .attr("fill", "#222")
        .style('paint-order', 'stroke')
        .style('stroke', 'white')
        .style('stroke-width', '3px')
        .style("display", "none")
        .text(d => d.name || d.id);

      nodeG.append("title").text(d => (d.name || d.id));

      // 4. DIBUJAR EL BRUSH (ÚLTIMO, ENCIMA DE TODO)
      const brush = d3.brush()
        .extent([[0, 0], [W, H]])
        .on("brush end", (event) => {{
          const sel = event.selection;
          if (!sel) {{ setSelection([], 'map-brush'); return; }}
          const [[x0, y0], [x1, y1]] = sel;
          const ids = pts.filter(d => {{
              const p = proj([+d.lon, +d.lat]);
              return x0 <= p[0] && p[0] <= x1 && y0 <= p[1] && p[1] <= y1;
            }}).map(d => String(d.id));
          
          setSelection(ids, 'map-brush');
        }});
      gMap.append("g").attr("class", "brush").call(brush);

      bus.addEventListener('selection', (e) => {{
        const selIds = e.detail.ids;
        const sel = new Set(selIds);
        const has = sel.size > 0;

        nodeG.attr("opacity", d => !has || sel.has(String(d.id)) ? 1.0 : 0.25);
        
        nodeG.select("circle")
          .attr("stroke",  d => sel.has(String(d.id)) ? "#d32f2f" : "#fff")
          .attr("stroke-width", d => sel.has(String(d.id)) ? 3 : 1.5);
        
        nodeG.select("text")
          .style("display", d => sel.has(String(d.id)) ? "inline" : "none");

        const items = selIds.map(id => byId.get(String(id))).filter(Boolean);
        const routePoints = items.filter(d => 
            Number.isFinite(+d.lat) && Number.isFinite(+d.lon)
        );

        if (routePoints.length < 2) {{
            routePath.attr("d", null); 
        }} else {{
            routePath.datum(routePoints).attr("d", lineGen);
        }}
      }});
      
    }}); 
  }})();

  // ====== RADAR (CON CATEGORÍAS CLICKEABLES IMPLEMENTADAS) ======
  (function initRadar() {{
    const host = document.getElementById("{radar_id}");
    const W = host.clientWidth, H = 420, R = Math.min(W,H)*0.36;

    const svg = d3.select(host).append("svg").attr("width", W).attr("height", H);
    const g = svg.append("g").attr("transform", "translate(" + (W/2) + "," + (H/2) + ")");

    const cols = ["Food","Altitude","Physical activity","Cultural activity","Safety",
                "Costs","Weather","Outdoor/nature","Party","Open culture",
                "Mobility","Accessibility","Adventure/Adrenaline"];

    const angle = d3.scaleLinear().domain([0, cols.length]).range([0, 2*Math.PI]);
    const radius = d3.scaleLinear().domain([0,5]).range([0,R]);
    const line = d3.lineRadial().curve(d3.curveLinearClosed)
                    .angle((d,i) => angle(i)).radius(d => radius(d));

    const avgAll = cols.map(c => d3.mean(data.nodes, n => +n[c] || 0));

    // --- NUEVO: Variable para estado de click ---
    let selectedCategory = null;

    // Anillos de fondo
    [1,2,3,4,5].forEach(k => g.append("circle").attr("r", radius(k)).attr("fill","none").attr("stroke","#ddd"));
    
    // --- NUEVO: Refactorización para guardar selección de ejes y etiquetas ---
    const axisGroups = g.selectAll(".axis-group")
      .data(cols)
      .join("g")
      .attr("class", "axis-group");

    const axisLines = axisGroups.append("line")
      .attr("x1", 0).attr("y1", 0)
      .attr("x2", (c,i) => Math.cos(angle(i) - Math.PI/2) * R)
      .attr("y2", (c,i) => Math.sin(angle(i) - Math.PI/2) * R)
      .attr("stroke", "#eee")
      .attr("stroke-width", 1.5); // Un poco más gruesas

    const axisLabels = axisGroups.append("text")
      .attr("x", (c,i) => Math.cos(angle(i) - Math.PI/2) * (R + 12))
      .attr("y", (c,i) => Math.sin(angle(i) - Math.PI/2) * (R + 12))
      .attr("text-anchor", (c,i) => Math.cos(angle(i) - Math.PI/2) > 0.01 ? "start" : (Math.cos(angle(i) - Math.PI/2) < -0.01 ? "end" : "middle"))
      .attr("dominant-baseline","central")
      .attr("font-size","10px")
      .text(c => c)
      .style("cursor", "pointer")
      .on("click", (ev, c) => {{ // 'c' es el datum (la categoría)
          // Implementación del toggle
          selectedCategory = (selectedCategory === c) ? null : c;
          updateHighlight();
          console.log("Categoría seleccionada:", selectedCategory);
      }});
    
    // --- NUEVO: Función para actualizar el resaltado ---
    function updateHighlight() {{
      axisLines
        .attr("stroke", d => (selectedCategory === null || selectedCategory === d) ? "#aaa" : "#eee") // Resaltar línea
        .attr("stroke-width", d => (selectedCategory === null || selectedCategory === d) ? 2 : 1.5);
      axisLabels
        .attr("font-weight", d => (selectedCategory === null || selectedCategory === d) ? "bold" : "normal") // Resaltar texto
        .attr("opacity", d => (selectedCategory === null || selectedCategory === d) ? 1.0 : 0.6); // Atenuar otros
    }}
    // --- FIN NUEVO ---

    // Capa para el promedio global (azul)
    const layerAvg   = g.append("path")
        .attr("fill","#6baed6")
        .attr("fill-opacity",0.15)
        .attr("stroke","#6baed6")
        .attr("stroke-width",1.5);
        
    // Grupo para las líneas de selección
    const layersSelectedG = g.append("g").attr("class", "selected-layers");

    function render(ids) {{
      const items = ids.map(id => byId.get(String(id))).filter(Boolean);
      
      layerAvg.datum(avgAll).attr("d", line);
      layersSelectedG.selectAll("path").remove();

      if (items.length === 1) {{
        const d = cols.map(c => +items[0][c] || 0);
        layersSelectedG.append("path")
            .datum(d)
            .attr("d", line)
            .attr("fill", radarColors(items[0].id))
            .attr("stroke", radarColors(items[0].id))
            .attr("fill-opacity", 0.25)
            .attr("stroke-width", 2.0);
            
      }} else if (items.length > 1) {{
        items.forEach(item => {{
            const d = cols.map(c => +item[c] || 0);
            layersSelectedG.append("path")
                .datum(d)
                .attr("d", line)
                .attr("fill", "none")
                .attr("stroke", radarColors(item.id))
                .attr("stroke-width", 2.0)
                .attr("stroke-opacity", 0.7);
        }});
      }}
    }}
    bus.addEventListener('selection', e => render(e.detail.ids));
  }})();

  // Panel info sincronizado
  bus.addEventListener('selection', e => renderInfo(e.detail.ids));

  // Estado inicial (disparar un evento de selección vacío)
  bus.dispatchEvent(new CustomEvent('selection', {{ detail: {{ ids: [], src: 'init' }} }}));
}})();
</script>
"""
    return HTML(html)