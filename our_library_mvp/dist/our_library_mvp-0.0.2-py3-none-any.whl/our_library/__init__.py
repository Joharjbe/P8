"""
our_library — MVP de visualización de grafos en notebooks.
"""

from .graph import (
    hello_d3,
    show_graph,
    show_graph_force,                 # puede caer a estático por CSP
    show_graph_force_vanilla,         # fuerzas en JS puro
    show_graph_force_vanilla_checklist
)

__all__ = [
    "hello_d3",
    "show_graph",
    "show_graph_force",
    "show_graph_force_vanilla",
    "show_graph_force_vanilla_checklist",
    "__version__",
]

__version__ = "0.0.2"  # subimos versión interna del paquete