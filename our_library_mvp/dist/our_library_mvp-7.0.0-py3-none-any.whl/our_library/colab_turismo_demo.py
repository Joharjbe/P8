# src/our_library/colab_turismo_demo.py

"""
Demo mínima para Google Colab:

from our_library.colab_turismo_demo import run_demo
run_demo()
"""

from .graph2_1 import (
    enable_colab_bridge,
    start_server,
    show_dashboard_map_force_radar_linked,
)


def _sample_nodes_and_links():
    # Nodos de ejemplo (Lima, Cusco, Arequipa, Iquitos, Trujillo, Puno)
    # Incluye todas las columnas que usa el radar.
    nodes = [
        {
            "id": "LIM-01",
            "name": "Centro Histórico de Lima",
            "region": "LIMA",
            "REGION": "LIMA",
            "lat": -12.0464,
            "lon": -77.0428,
            "LATITUD": -12.0464,
            "LONGITUD": -77.0428,
            "want_to_go": 9,
            "Food": 4.5,
            "Altitude": 1.0,
            "Physical activity": 2.5,
            "Cultural activity": 5.0,
            "Safety": 2.0,
            "Costs": 3.0,
            "Weather": 3.5,
            "Outdoor/nature": 2.5,
            "Party": 4.0,
            "Open culture": 4.5,
            "Mobility": 4.0,
            "Accessibility": 4.0,
            "Adventure/Adrenaline": 2.5,
            "url": "https://es.wikipedia.org/wiki/Centro_hist%C3%B3rico_de_Lima",
        },
        {
            "id": "CUS-01",
            "name": "Machu Picchu",
            "region": "CUSCO",
            "REGION": "CUSCO",
            "lat": -13.1631,
            "lon": -72.5450,
            "LATITUD": -13.1631,
            "LONGITUD": -72.5450,
            "want_to_go": 10,
            "Food": 4.0,
            "Altitude": 4.5,
            "Physical activity": 4.5,
            "Cultural activity": 5.0,
            "Safety": 3.5,
            "Costs": 2.0,
            "Weather": 3.5,
            "Outdoor/nature": 5.0,
            "Party": 2.0,
            "Open culture": 4.5,
            "Mobility": 3.0,
            "Accessibility": 3.0,
            "Adventure/Adrenaline": 4.5,
            "url": "https://es.wikipedia.org/wiki/Machu_Picchu",
        },
        {
            "id": "ARE-01",
            "name": "Cañón del Colca",
            "region": "AREQUIPA",
            "REGION": "AREQUIPA",
            "lat": -15.6420,
            "lon": -71.8050,
            "LATITUD": -15.6420,
            "LONGITUD": -71.8050,
            "want_to_go": 8,
            "Food": 4.0,
            "Altitude": 4.0,
            "Physical activity": 4.0,
            "Cultural activity": 3.5,
            "Safety": 3.0,
            "Costs": 3.0,
            "Weather": 3.5,
            "Outdoor/nature": 4.5,
            "Party": 2.5,
            "Open culture": 4.0,
            "Mobility": 2.5,
            "Accessibility": 2.5,
            "Adventure/Adrenaline": 4.5,
            "url": "https://es.wikipedia.org/wiki/Ca%C3%B1%C3%B3n_del_Colca",
        },
        {
            "id": "LOR-01",
            "name": "Iquitos y Amazonas",
            "region": "LORETO",
            "REGION": "LORETO",
            "lat": -3.7437,
            "lon": -73.2516,
            "LATITUD": -3.7437,
            "LONGITUD": -73.2516,
            "want_to_go": 8,
            "Food": 4.0,
            "Altitude": 1.0,
            "Physical activity": 3.5,
            "Cultural activity": 3.0,
            "Safety": 2.5,
            "Costs": 3.0,
            "Weather": 4.0,
            "Outdoor/nature": 5.0,
            "Party": 3.0,
            "Open culture": 4.0,
            "Mobility": 2.5,
            "Accessibility": 2.5,
            "Adventure/Adrenaline": 4.0,
            "url": "https://es.wikipedia.org/wiki/Iquitos",
        },
        {
            "id": "LAL-01",
            "name": "Chan Chan",
            "region": "LALIBERTAD",
            "REGION": "LALIBERTAD",
            "lat": -8.0876,
            "lon": -79.0740,
            "LATITUD": -8.0876,
            "LONGITUD": -79.0740,
            "want_to_go": 7,
            "Food": 4.0,
            "Altitude": 1.5,
            "Physical activity": 2.5,
            "Cultural activity": 4.5,
            "Safety": 3.0,
            "Costs": 3.5,
            "Weather": 3.5,
            "Outdoor/nature": 3.0,
            "Party": 3.0,
            "Open culture": 4.0,
            "Mobility": 3.5,
            "Accessibility": 3.5,
            "Adventure/Adrenaline": 2.5,
            "url": "https://es.wikipedia.org/wiki/Zona_arqueol%C3%B3gica_de_Chan_Chan",
        },
        {
            "id": "PUN-01",
            "name": "Lago Titicaca",
            "region": "PUNO",
            "REGION": "PUNO",
            "lat": -15.8402,
            "lon": -69.3319,
            "LATITUD": -15.8402,
            "LONGITUD": -69.3319,
            "want_to_go": 9,
            "Food": 3.5,
            "Altitude": 5.0,
            "Physical activity": 3.5,
            "Cultural activity": 4.5,
            "Safety": 3.0,
            "Costs": 3.0,
            "Weather": 3.0,
            "Outdoor/nature": 4.5,
            "Party": 2.5,
            "Open culture": 4.0,
            "Mobility": 2.5,
            "Accessibility": 2.5,
            "Adventure/Adrenaline": 3.5,
            "url": "https://es.wikipedia.org/wiki/Lago_Titicaca",
        },
    ]

    links = [
        {"source": "LIM-01", "target": "CUS-01", "similarity": 0.85},
        {"source": "LIM-01", "target": "ARE-01", "similarity": 0.75},
        {"source": "LIM-01", "target": "LAL-01", "similarity": 0.70},
        {"source": "CUS-01", "target": "ARE-01", "similarity": 0.80},
        {"source": "CUS-01", "target": "PUN-01", "similarity": 0.88},
        {"source": "ARE-01", "target": "PUN-01", "similarity": 0.77},
        {"source": "LIM-01", "target": "LOR-01", "similarity": 0.65},
        {"source": "LOR-01", "target": "CUS-01", "similarity": 0.60},
    ]

    return nodes, links


def run_demo():
    """
    Demo pensada para Google Colab:
    - Intenta activar el puente Colab → Python.
    - Intenta levantar el servidor Flask en background (si no se puede, ignora el error).
    - Muestra el dashboard mapa+force+radar con datos de ejemplo.
    """
    # Puente Colab (JS -> Python)
    try:
        enable_colab_bridge()
    except Exception as e:
        print("[our_library] No se pudo registrar callback Colab:", e)

    # Servidor Flask local en background (para VS Code / Jupyter clásico)
    try:
        start_server()
        print("[our_library] Servidor Flask iniciado en 127.0.0.1:5000")
    except Exception as e:
        print("[our_library] No se pudo iniciar Flask (quizá ya está corriendo):", e)

    nodes, links = _sample_nodes_and_links()
    return show_dashboard_map_force_radar_linked(nodes, links)