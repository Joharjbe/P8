"""
our_library — MVP de visualización de grafos en notebooks.

from .graph2 import (
    hello1_d3,
    show_graph1,
    show_graph_force1,                 # puede caer a estático por CSP
    show_graph_force_vanilla1,         # fuerzas en JS puro
    show_graph_force_vanilla_checklist1,
    show_matrix_layout1,  # matrix
    show_radar_layout1,   # radar - NUEVA FUNCIÓN
    
    show_dashboard_matrix_radar_force # NUEVO DASHBOARD
)

__all__ = [
    "hello1_d3",
    "show_graph1",
    "show_graph_force1",
    "show_graph_force_vanilla1",
    "show_graph_force_vanilla_checklist1",
    "show_matrix_layout1",
    "show_radar_layout1",  
    "show_dashboard_matrix_radar_force", # NUEVA EXPORTACIÓN
    "__version__",
]
"""
from .graph2_1 import (
    show_dashboard_matrix_radar_force7, update_node, start_server, get_current_node, get_click_history, clear_click_history, get_unique_clicks, enable_colab_bridge,
    show_linked_dashboard, 
    show_dashboard_map_force_radar_linked, 
)

__all__ = [
    "update_node",
    "start_server",
    "get_current_node",
    "show_dashboard_matrix_radar_force7", # NUEVA EXPORTACIÓN
    "enable_colab_bridge",
    "get_current_node", "get_click_history", "get_unique_clicks",
    "clear_click_history",
    "show_linked_dashboard",
    "show_dashboard_map_force_radar_linked",
    "__version__",
]
__version__ = "4.0.6"  # actualizamos por el nuevo dashboard