# src/our_library/graph.py
import json, uuid, math, base64
from pathlib import Path
from IPython.display import HTML
# mylib/dashboard.py
from flask import Flask, request, jsonify
from threading import Thread

# en graph2_1.py (y exportar en __init__.py)

# ============================================================
#  Colab / Flask bridge for JS → Python (update_node)
# ============================================================

try:
    from google.colab import output as _colab_output
    _IN_COLAB = True
except Exception:  # pragma: no cover
    _IN_COLAB = False


def enable_colab_bridge():
    """
    Registra el callback JS→Python en Colab para que el dashboard
    pueda enviar el nodo clicado a Python.

    En notebooks locales (VSCode, Jupyter) esto es un no-op.
    """
    if not _IN_COLAB:
        return False

    def _cb(node):
        global global_node_, global_clicks_
        global_node_ = node
        global_clicks_.append(node)
        return {"status": "ok"}

    _colab_output.register_callback("ourlib.update_node", _cb)
    return True


global_node_ = None
global_clicks_ = []

app = Flask(__name__)


@app.route("/update_node", methods=["POST"])
def update_node():
    """Endpoint HTTP para que el JS notifique a Python el nodo clicado."""
    global global_node_, global_clicks_
    data = request.get_json() or {}
    global_node_ = data.get("node")
    if global_node_ is not None:
        global_clicks_.append(global_node_)
    return jsonify({"status": "ok", "node": global_node_})


def start_server(port: int = 5000):
    """
    Levanta un pequeño servidor Flask en un thread aparte para que
    el JS del notebook pueda hacer POST a /update_node.
    """
    thread = Thread(
        target=lambda: app.run(port=port, debug=False, use_reloader=False)
    )
    thread.daemon = True
    thread.start()


def get_current_node():
    """Devuelve el último nodo recibido desde JS (o None)."""
    return global_node_


def get_click_history(clear: bool = False):
    """Devuelve el historial de nodos clicados."""
    global global_clicks_
    hist = list(global_clicks_)
    if clear:
        global_clicks_.clear()
    return hist


def clear_click_history():
    """Limpia el historial de clics."""
    global global_clicks_
    global_clicks_.clear()


# ============================================================
#  Main dashboard: Graph + Map + SCORE bars + Selection panel
# ============================================================


def show_dashboard_map_force_radar_linked(
    nodes, links, width: int = 1200, height: int = 900, grid_cols: int = 2, grid_rows: int = 2
):
    """
    Dashboard linkeado para recomendaciones de turismo:

    - Graph (force) con top-3 aristas de similaridad por nodo.
    - Map de Perú con puntos (lat, lon) y brush de selección.
    - Panel de SCORE (barras horizontales por recomendación).
    - Panel de Selection con la lista de recursos seleccionados.
    - En cada click se manda un payload a Python (Colab o Flask).

    Espera que cada nodo tenga al menos:
      { "id", "name", "region", "lat", "lon", "SCORE", "want_to_go" }

    Y cada enlace:
      { "source", "target", "similarity" }.
    """
    dash_id = "dash-" + uuid.uuid4().hex
    force_id = "force-" + uuid.uuid4().hex
    map_id = "map-" + uuid.uuid4().hex
    radar_id = "radar-" + uuid.uuid4().hex  # ahora SCORE bars
    info_id = "info-" + uuid.uuid4().hex

    data_json = json.dumps({"nodes": nodes, "links": links}, default=str)

    # ---- Filtramos Top-3 conexiones por nodo para el Graph ----
    filtered_links = []
    for node in nodes:
        nid = node.get("id")
        outgoing = [l for l in links if l.get("source") == nid]
        incoming = [l for l in links if l.get("target") == nid]
        top3 = sorted(
            outgoing + incoming,
            key=lambda x: x.get("similarity", 0),
            reverse=True,
        )[:3]
        filtered_links.extend(top3)

    # Quitamos duplicados (pueden salir si la arista aparece desde source y target)
    filtered_links = list(
        {json.dumps(l, sort_keys=True): l for l in filtered_links}.values()
    )

    html = f"""
<div id="{dash_id}" style="
  width:{width}px; font-family:system-ui;
  display:grid; grid-template-columns:repeat({grid_cols}, 1fr);
  grid-template-rows:repeat({grid_rows}, 1fr);
  gap:18px; align-items:start;">

  <!-- Graph -->
  <div style="border:3px solid #d32f2f; border-radius:12px; padding:10px; min-height:450px;">
    <h3 style="margin:0 0 6px;">Graph</h3>
    <div style="font-size:11px; margin-bottom:5px; display:flex; flex-direction:column; align-items:flex-start; gap:4px;">
      <span>Conexiones: Top 3. <strong>Grosor y color</strong> = Nivel de similaridad</span>
      <span style="font-size:10px; white-space:nowrap;">(Menos
        <span style="display:inline-block; width:30px; height:5px; background:linear-gradient(to right, #f7fbff, #08306b); border:1px solid #ccc; vertical-align:middle;"></span>
      Más)</span>
    </div>
    <div id="{force_id}" style="width:100%; height:450px; border:1px solid #ccc;"></div>
  </div>

  <!-- Map -->
  <div style="border:3px solid #2e7d32; border-radius:12px; padding:10px; min-height:450px;">
    <h3 style="margin:0 0 6px;">Map</h3>
    <div id="{map_id}" style="width:100%; height:450px; border:1px solid #ccc;"></div>
    <div style="display:flex; gap:15px; margin-top:10px; font-size:12px;">
      <span><span style="color:#fbc02d; font-size:1.2em; -webkit-text-stroke: 1px #ccc;">●</span> Costa</span>
      <span><span style="color:#8D6E63; font-size:1.2em; -webkit-text-stroke: 1px #ccc;">●</span> Sierra</span>
      <span><span style="color:#4CAF50; font-size:1.2em; -webkit-text-stroke: 1px #ccc;">●</span> Selva</span>
    </div>
  </div>

  <!-- SCORE bars -->
  <div style="border:3px solid #1976d2; border-radius:12px; padding:10px; min-height:420px;">
    <h3 style="margin:0 0 6px;">Ranking · SCORE</h3>
    <div id="{radar_id}" style="width:100%; height:420px; border:1px solid #ccc;"></div>
    <div style="margin-top:10px;">
      <p style="font-size:12px;">
        Barra horizontal = <strong>SCORE</strong> de recomendación ·
        Color = región geográfica (igual que en el mapa)
      </p>
    </div>
  </div>

  <!-- Selection -->
  <div style="border:3px solid #7b1fa2; border-radius:12px; padding:10px; min-height:420px;">
    <h3 style="margin:0 0 6px;">Selection</h3>
    <div id="{info_id}" style="min-height:420px; background:#f8f9fa; padding:10px; overflow:auto;">
      <em>Haz click en el Graph, en las barras de SCORE o usa el brush en el mapa…</em>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script src="https://cdn.jsdelivr.net/npm/topojson-client@3"></script>

<script>
(function() {{
  const data = {data_json};
  const filteredLinks = {json.dumps(filtered_links, default=str)};

  // =================== JS → Python bridge ====================
  function _sendToPython(payload) {{
    try {{
      const inColab = !!(window.google && google.colab && google.colab.kernel && google.colab.kernel.invokeFunction);
      if (inColab) {{
        google.colab.kernel.invokeFunction('ourlib.update_node', [payload], {{}})
          .catch(err => console.warn('Colab bridge error:', err));
      }} else {{
        const body = JSON.stringify({{ node: payload }});
        fetch('http://127.0.0.1:5000/update_node', {{
          method: 'POST',
          headers: {{ 'Content-Type': 'application/json' }},
          body
        }}).catch(() => {{
          fetch('/proxy/5000/update_node', {{
            method: 'POST',
            headers: {{ 'Content-Type': 'application/json' }},
            body
          }}).catch(err => console.warn('Fetch bridge failed:', err));
        }});
      }}
    }} catch(e) {{
      console.warn('sendToPython failed:', e);
    }}
  }}
  const sendToPython = _sendToPython;
  window.sendToPython = _sendToPython;

  // =================== Estado compartido =====================
  const bus   = new EventTarget();
  const state = {{ selected: [] }};  // array para preservar orden
  const byId  = new Map((data.nodes || []).map(d => [String(d.id), d]));

  // Región → Costa/Sierra/Selva
  const zoneMap = {{
    // Costa
    "LIMA":       {{ zone: "Costa",  scale: d3.scaleSequential(d3.interpolateRgb("#fff9c4", "#fbc02d")).domain([0,1]) }},
    "ICA":        {{ zone: "Costa",  scale: d3.scaleSequential(d3.interpolateRgb("#fff9c4", "#fbc02d")).domain([0,1]) }},
    "LALIBERTAD": {{ zone: "Costa",  scale: d3.scaleSequential(d3.interpolateRgb("#fff9c4", "#fbc02d")).domain([0,1]) }},
    "LAMBAYEQUE": {{ zone: "Costa",  scale: d3.scaleSequential(d3.interpolateRgb("#fff9c4", "#fbc02d")).domain([0,1]) }},
    "PIURA":      {{ zone: "Costa",  scale: d3.scaleSequential(d3.interpolateRgb("#fff9c4", "#fbc02d")).domain([0,1]) }},
    // Sierra
    "ANCASH":     {{ zone: "Sierra", scale: d3.scaleSequential(d3.interpolateRgb("#d7ccc8", "#8D6E63")).domain([0,1]) }},
    "AREQUIPA":   {{ zone: "Sierra", scale: d3.scaleSequential(d3.interpolateRgb("#d7ccc8", "#8D6E63")).domain([0,1]) }},
    "PUNO":       {{ zone: "Sierra", scale: d3.scaleSequential(d3.interpolateRgb("#d7ccc8", "#8D6E63")).domain([0,1]) }},
    "CUSCO":      {{ zone: "Sierra", scale: d3.scaleSequential(d3.interpolateRgb("#d7ccc8", "#8D6E63")).domain([0,1]) }},
    // Selva
    "LORETO":       {{ zone: "Selva", scale: d3.scaleSequential(d3.interpolateRgb("#c8e6c9", "#4CAF50")).domain([0,1]) }},
    "AMAZONAS":     {{ zone: "Selva", scale: d3.scaleSequential(d3.interpolateRgb("#c8e6c9", "#4CAF50")).domain([0,1]) }},
    "MADREDEDIOS":  {{ zone: "Selva", scale: d3.scaleSequential(d3.interpolateRgb("#c8e6c9", "#4CAF50")).domain([0,1]) }},
    // Fallback
    "DEFAULT":    {{ zone: "Other", scale: d3.scaleSequential(d3.interpolateGreys).domain([0,1]) }}
  }};

  function getNodeColor(d) {{
    const mapping = zoneMap[d.region] || zoneMap["DEFAULT"];
    const val = (+d.want_to_go - 4) / 5;  // normaliza (4–9) a (0–1)
    return mapping.scale(isFinite(val) ? val : 0.5);
  }}

  const radarColors = d3.scaleOrdinal(d3.schemeCategory10);

  function setSelection(ids, src) {{
    const unique = [];
    const seen = new Set();
    ids.map(String).forEach(id => {{
      if (!seen.has(id)) {{
        seen.add(id);
        unique.push(id);
      }}
    }});
    state.selected = unique;
    bus.dispatchEvent(new CustomEvent("selection", {{ detail: {{ ids: state.selected, src }} }}));
  }}

  function toggleOne(id, src) {{
    const sid = String(id);
    const current = state.selected.slice();
    const idx = current.indexOf(sid);
    if (idx > -1) {{
      current.splice(idx, 1);
    }} else {{
      current.push(sid);
    }}
    setSelection(current, src);
  }}

  // =================== Panel Selection =======================
  function renderInfo(ids) {{
    const box = document.getElementById("{info_id}");
    if (!ids.length) {{
      box.innerHTML = "<em>Sin selección</em>";
      return;
    }}
    const items = ids.map(id => byId.get(String(id))).filter(Boolean);
    const lis = items.map(n => {{
      const nm = n.name || n.id;
      const reg = n.region || "";
      const color = radarColors(n.id);
      const swatch = `<span style="color:${{color}}; font-size:1.2em; -webkit-text-stroke: 1px #ccc;">●</span> `;
      const link = n.url
        ? `<a href="${{n.url}}" target="_blank" rel="noopener noreferrer">${{nm}}</a>`
        : nm;
      return `<li>${{swatch}}<strong>${{link}}</strong>${{reg ? " · " + reg : ""}}</li>`;
    }}).join("");
    box.innerHTML = `<p><strong>${{ids.length}}</strong> seleccionado(s):</p><ul>${{lis}}</ul>`;
  }}

  bus.addEventListener("selection", e => {{
    renderInfo(e.detail.ids);
  }});

  // =================== FORCE graph ===========================
  (function initForce() {{
    const host = document.getElementById("{force_id}");
    const W = host.clientWidth;
    const H = 450;
    const svg = d3.select(host).append("svg").attr("width", W).attr("height", H);
    const g   = svg.append("g");

    const simExtent = d3.extent(filteredLinks, d => +d.similarity || 0);
    const linkWidth = d3.scaleLinear().domain(simExtent).range([1, 4]);
    const linkColor = d3.scaleSequential(d3.interpolateBlues).domain(simExtent);

    const simNodes = data.nodes.map(d => Object.assign({{}}, d));
    const sim = d3.forceSimulation(simNodes)
      .force("link", d3.forceLink(filteredLinks).id(d => String(d.id)).distance(70))
      .force("charge", d3.forceManyBody().strength(-200))
      .force("center", d3.forceCenter(W / 2, H / 2));

    const link = g.append("g")
      .attr("stroke-opacity", 0.4)
      .selectAll("line")
      .data(filteredLinks)
      .join("line")
      .attr("stroke-width", d => linkWidth(+d.similarity || 0))
      .attr("stroke", d => linkColor(+d.similarity || 0));

    link.append("title").text(d => `Similaridad: ${{(+d.similarity || 0).toFixed(2)}}`);

    const nodeG = g.append("g")
      .selectAll("g")
      .data(sim.nodes())
      .join("g")
      .style("cursor", "pointer");

    nodeG.append("circle")
      .attr("r", 8)
      .attr("fill", d => getNodeColor(d))
      .attr("stroke", "#fff")
      .attr("stroke-width", 2)
      .call(
        d3.drag()
          .on("start", (event, d) => {{
            if (!event.active) sim.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
          }})
          .on("drag", (event, d) => {{
            d.fx = event.x;
            d.fy = event.y;
          }})
          .on("end", (event, d) => {{
            if (!event.active) sim.alphaTarget(0);
            d.fx = null;
            d.fy = null;
          }})
      )
      .on("click", (event, d) => {{
        if (event.metaKey || event.ctrlKey) {{
          toggleOne(d.id, "force");
        }} else {{
          setSelection([d.id], "force");
        }}
        sendToPython(Object.assign({{}}, d, {{ __ts: new Date().toISOString(), __src: "force" }}));
        event.stopPropagation();
      }});

    nodeG.append("text")
      .attr("x", 12)
      .attr("y", 4)
      .attr("font-size", "11px")
      .attr("fill", "#222")
      .style("paint-order", "stroke")
      .style("stroke", "white")
      .style("stroke-width", "3px")
      .text(d => d.name || d.id);

    sim.on("tick", () => {{
      link
        .attr("x1", d => d.source.x)
        .attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x)
        .attr("y2", d => d.target.y);

      nodeG.attr("transform", d => `translate(${{d.x}},${{d.y}})`);
    }});

    bus.addEventListener("selection", e => {{
      const sel = new Set(e.detail.ids);
      const has = sel.size > 0;

      nodeG.select("circle")
        .attr("opacity", d => !has || sel.has(String(d.id)) ? 1.0 : 0.25)
        .attr("stroke",  d => sel.has(String(d.id)) ? "#d32f2f" : "#fff")
        .attr("stroke-width", d => sel.has(String(d.id)) ? 3 : 2);

      link
        .attr("stroke-opacity", d => {{
          if (!has) return 0.25;
          const s = String(d.source.id || d.source);
          const t = String(d.target.id || d.target);
          return sel.has(s) || sel.has(t) ? 0.6 : 0.08;
        }})
        .attr("stroke-width", d => {{
          const base = linkWidth(+d.similarity || 0);
          if (!has) return base;
          const s = String(d.source.id || d.source);
          const t = String(d.target.id || d.target);
          return sel.has(s) || sel.has(t) ? base * 1.5 : base;
        }});
    }});
  }})();

  // =================== Mapa de Perú ==========================
  (function initMap() {{
    const host = document.getElementById("{map_id}");
    const W = host.clientWidth;
    const H = 450;
    const svg = d3.select(host).append("svg").attr("width", W).attr("height", H);
    const gMap = svg.append("g");

    d3.json("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json").then(world => {{
      const countries = topojson.feature(world, world.objects.countries);
      const peru =
        countries.features.find(f => f.id === "604") ||
        countries.features.find(f => (f.properties && f.properties.name === "Peru"));

      const proj = d3.geoMercator().fitExtent([[20, 20], [W - 20, H - 20]], peru);
      const path = d3.geoPath(proj);

      const lineGen = d3.line()
        .x(d => proj([+d.lon, +d.lat])[0])
        .y(d => proj([+d.lon, +d.lat])[1]);

      // Fondo
      gMap.append("path")
        .datum(peru)
        .attr("d", path)
        .attr("fill", "#f3f6ff")
        .attr("stroke", "#9db2ff")
        .attr("stroke-width", 1.0);

      // Ruta
      const routePath = gMap.append("path")
        .attr("fill", "none")
        .attr("stroke", "#d32f2f")
        .attr("stroke-width", 2.5)
        .attr("stroke-dasharray", "5 5")
        .style("pointer-events", "none");

      const pts = data.nodes.filter(
        d => Number.isFinite(+d.lat) && Number.isFinite(+d.lon)
      );

      const nodeG = gMap.append("g")
        .selectAll("g")
        .data(pts, d => d.id)
        .join("g")
        .attr("transform", d => `translate(${{proj([+d.lon, +d.lat])[0]}},${{proj([+d.lon, +d.lat])[1]}})`)
        .style("cursor", "pointer")
        .on("click", (event, d) => {{
          if (event.metaKey || event.ctrlKey) {{
            toggleOne(d.id, "map-click");
          }} else {{
            setSelection([d.id], "map-click");
          }}
          sendToPython(Object.assign({{}}, d, {{ __ts: new Date().toISOString(), __src: "map" }}));
          event.stopPropagation();
        }});

      nodeG.append("circle")
        .attr("r", 6)
        .attr("fill", d => getNodeColor(d))
        .attr("stroke", "#fff")
        .attr("stroke-width", 1.5);

      nodeG.append("text")
        .attr("x", 9)
        .attr("y", 4)
        .attr("font-size", "10px")
        .attr("fill", "#222")
        .style("paint-order", "stroke")
        .style("stroke", "white")
        .style("stroke-width", "3px")
        .style("display", "none")
        .text(d => d.name || d.id);

      nodeG.append("title").text(d => d.name || d.id);

      const brush = d3.brush()
        .extent([[0, 0], [W, H]])
        .on("brush end", event => {{
          const sel = event.selection;
          if (!sel) {{
            setSelection([], "map-brush");
            return;
          }}
          const [[x0, y0], [x1, y1]] = sel;
          const ids = pts
            .filter(d => {{
              const p = proj([+d.lon, +d.lat]);
              return x0 <= p[0] && p[0] <= x1 && y0 <= p[1] && p[1] <= y1;
            }})
            .map(d => String(d.id));
          setSelection(ids, "map-brush");
        }});

      gMap.append("g").attr("class", "brush").call(brush);

      bus.addEventListener("selection", e => {{
        const ids = e.detail.ids;
        const sel = new Set(ids);
        const has = sel.size > 0;

        nodeG.attr("opacity", d => (!has || sel.has(String(d.id)) ? 1.0 : 0.25));

        nodeG.select("circle")
          .attr("stroke", d => (sel.has(String(d.id)) ? "#d32f2f" : "#fff"))
          .attr("stroke-width", d => (sel.has(String(d.id)) ? 3 : 1.5));

        nodeG.select("text")
          .style("display", d => (sel.has(String(d.id)) ? "inline" : "none"));

        const routePoints = ids
          .map(id => byId.get(String(id)))
          .filter(d => d && Number.isFinite(+d.lat) && Number.isFinite(+d.lon));

        if (routePoints.length < 2) {{
          routePath.attr("d", null);
        }} else {{
          routePath.datum(routePoints).attr("d", lineGen);
        }}
      }});
    }});
  }})();

  // =================== SCORE bars ============================
  (function initScoreBars() {{
    const host = document.getElementById("{radar_id}");
    const W = host.clientWidth;
    const H = 420;
    const margin = {{ top: 20, right: 20, bottom: 30, left: 160 }};
    const width  = W - margin.left - margin.right;
    const height = H - margin.top - margin.bottom;

    const svg = d3.select(host)
      .append("svg")
      .attr("width", W)
      .attr("height", H);

    const g = svg.append("g")
      .attr("transform", `translate(${{margin.left}},${{margin.top}})`);

    const items = data.nodes.filter(
      d => typeof d.SCORE === "number" && !isNaN(d.SCORE)
    );

    if (!items.length) {{
      g.append("text")
        .attr("x", 0)
        .attr("y", 20)
        .attr("fill", "#666")
        .text("No SCORE data available.");
      return;
    }}

    items.sort((a, b) => d3.descending(a.SCORE, b.SCORE));

    const x = d3.scaleLinear()
      .domain([0, d3.max(items, d => d.SCORE)])
      .nice()
      .range([0, width]);

    const y = d3.scaleBand()
      .domain(items.map(d => String(d.id)))
      .range([0, height])
      .padding(0.2);

    const bars = g.selectAll("rect.bar")
      .data(items)
      .enter()
      .append("rect")
      .attr("class", "bar")
      .attr("x", 0)
      .attr("y", d => y(String(d.id)))
      .attr("height", y.bandwidth())
      .attr("width", d => x(d.SCORE))
      .attr("fill", d => getNodeColor(d))
      .style("cursor", "pointer")
      .on("click", (event, d) => {{
        if (event.metaKey || event.ctrlKey) {{
          toggleOne(d.id, "score");
        }} else {{
          setSelection([d.id], "score");
        }}
        sendToPython({{
          id: d.id,
          name: d.name,
          SCORE: d.SCORE,
          __ts: new Date().toISOString(),
          __src: "score"
        }});
        event.stopPropagation();
      }});

    g.selectAll("text.label")
      .data(items)
      .enter()
      .append("text")
      .attr("class", "label")
      .attr("x", -6)
      .attr("y", d => y(String(d.id)) + y.bandwidth() / 2)
      .attr("dy", "0.35em")
      .attr("text-anchor", "end")
      .attr("font-size", "10px")
      .text(d => d.name || d.id);

    g.selectAll("text.value")
      .data(items)
      .enter()
      .append("text")
      .attr("class", "value")
      .attr("x", d => x(d.SCORE) + 4)
      .attr("y", d => y(String(d.id)) + y.bandwidth() / 2)
      .attr("dy", "0.35em")
      .attr("font-size", "10px")
      .attr("fill", "#444")
      .text(d => d.SCORE.toFixed(2));

    g.append("g")
      .attr("transform", `translate(0,${{height}})`)
      .call(d3.axisBottom(x).ticks(4));

    g.append("text")
      .attr("x", width / 2)
      .attr("y", height + 26)
      .attr("text-anchor", "middle")
      .attr("font-size", "11px")
      .attr("fill", "#333")
      .text("SCORE de recomendación");

    bus.addEventListener("selection", e => {{
      const sel = new Set(e.detail.ids);
      const has = sel.size > 0;
      bars
        .attr("opacity", d => (!has || sel.has(String(d.id)) ? 1.0 : 0.25))
        .attr("stroke", d => (sel.has(String(d.id)) ? "#7b1fa2" : "none"))
        .attr("stroke-width", d => (sel.has(String(d.id)) ? 2 : 0));
    }});
  }})();
}})();
</script>
"""
    return HTML(html)