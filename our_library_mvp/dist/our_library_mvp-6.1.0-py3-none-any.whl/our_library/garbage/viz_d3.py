# src/our_library/viz_d3.py

import json
import uuid
import pandas as pd
from IPython.display import HTML
from .garbage import turismo_recs  # Importa el motor desde el mismo paquete

def _to_nodes_links_path(df_ranked, catalog, anchor_code=None):
    """
    Convierte el DataFrame de resultados en nodos y rutas para D3.
    'catalog' (df_recs) se usa solo para encontrar el ancla.
    """
    df_temp = df_ranked.copy().reset_index(drop=True)
    nodes, anchor_node = [], None
    
    if anchor_code is not None:
        anchor_code_str = str(anchor_code).split('.')[0].strip()
        try:
            # Busca en el catálogo usando la función interna del motor
            base_idx = turismo_recs._find_base_idx_by_code(catalog, anchor_code_str)
            ar = catalog.loc[base_idx]
            
            anchor_lat = float(ar.get("LATITUD")) if pd.notna(ar.get("LATITUD")) else None
            anchor_lon = float(ar.get("LONGITUD")) if pd.notna(ar.get("LONGITUD")) else None
            
            anchor_node = {
                "id": f"anchor:{anchor_code_str}", "code": anchor_code_str,
                "name": (ar.get("NOMBRE DEL RECURSO") or f"CODE {ar['CODE']}"),
                "region": ar.get("REGION"), "categoria": ar.get("CATEGORIA"),
                "lat": anchor_lat, "lon": anchor_lon,
                "url": ar.get("URL"), "is_anchor": True, "score": 1.0
            }
            if anchor_lat is not None and anchor_lon is not None:
                nodes.append(anchor_node)
        except ValueError:
             print(f"⚠️ Ancla {anchor_code_str} no encontrada en el catálogo.")
            
    for _, r in df_temp.iterrows():
        nid = str(r.get("CODE", r.get("CODIGO", ""))).split('.')[0].strip()
        if not nid: continue
        
        if anchor_node and anchor_node["code"] == nid: continue
        
        node_lat = float(r.get("LATITUD")) if pd.notna(r.get("LATITUD")) else None
        node_lon = float(r.get("LONGITUD")) if pd.notna(r.get("LONGITUD")) else None

        # Solo añadir el nodo si tiene coordenadas geográficas
        if node_lat is not None and node_lon is not None:
            nodes.append({
                "id": nid, "code": nid, "name": r.get("NOMBRE DEL RECURSO", r.get("NOMBRE")),
                "region": r.get("REGION"), "provincia": r.get("PROVINCIA"),
                "distrito": r.get("DISTRITO"), "categoria": r.get("CATEGORIA"),
                "tipo": r.get("TIPO_DE_CATEGORIA"), "subtipo": r.get("SUB_TIPO_CATEGORIA"),
                "url": r.get("URL"),
                "lat": node_lat, "lon": node_lon,
                "score": float(r.get("SCORE", 0.0)),
                "sim_text": float(r.get("SIM_TEXT", 0.0)),
                "dist_km": float(r.get("DIST_KM")) if pd.notna(r.get("DIST_KM")) else None,
                "is_anchor": False
            })
            
    map_path = []
    nodes_with_geo = sorted(
        [n for n in nodes if not n["is_anchor"]],
        key=lambda x: x["score"], reverse=True
    )

    if anchor_node and anchor_node["lat"] is not None and anchor_node["lon"] is not None:
         nodes_with_geo.insert(0, anchor_node)
        
    for i in range(len(nodes_with_geo) - 1):
        s = nodes_with_geo[i]; t = nodes_with_geo[i+1]
        map_path.append({
            "source_id": s["id"], "target_id": t["id"], "score": t["score"],
            "source_geo": [s["lon"], s["lat"]], "target_geo": [t["lon"], t["lat"]]
        })
    return nodes, map_path

def viz_recs_mapa_d3(query, topk=12, model_dir="/content/models",
                      geo_anchor_code=None, geo_km=None, alpha=0.85):
    """
    Genera una visualización D3 aislada que SOLO muestra el mapa de ruta.
    Utiliza el motor 'turismo_recs.py'.
    """
    
    # 1. Cargar modelos (si no están cargados)
    # Esto usa las variables globales dentro de turismo_recs.py
    try:
        tfidf, knn, catalog_df = turismo_recs._load_models(model_dir)
    except FileNotFoundError:
        print(f"❌ Error: No se encontraron los modelos en {model_dir}.")
        print("Asegúrate de haber subido 'tfidf.joblib', 'knn.joblib' y 'recursos.parquet'.")
        return
        
    # 2. Llamar al motor de recomendación
    try:
        raw_results = turismo_recs.recommend(
            model_dir=model_dir,
            modo="texto",
            valor=query,
            topk=max(5*int(topk), 50), # Pedir más para filtrar por geo
            alpha=alpha,
            geo_km=geo_km,
            geo_anchor_code=geo_anchor_code,
            rg_mode="none" # Simplificamos
        )
        print(f"--- DEBUG: Motor OK. {len(raw_results)} resultados 'raw' recibidos.")
    except Exception as e:
        print(f"❌ Error al llamar al motor 'recommend': {e}")
        return

    # 3. Preparar datos para D3
    # Filtramos por nodos que tengan LATITUD/LONGITUD válidas
    df_viz_geo = raw_results[pd.notna(raw_results["LATITUD"]) & pd.notna(raw_results["LONGITUD"])].copy()
    
    if df_viz_geo.empty:
        print(f"--- DEBUG: ¡FALLO! El motor devolvió {len(raw_results)} resultados, pero NINGUNO tiene LAT/LON válidas.")
        return HTML(f"<div style='text-align:center; padding:20px; color:#c0392b;'>No hay resultados con coordenadas geográficas válidas para la consulta: <strong>'{query}'</strong></div>")

    print(f"--- DEBUG: Filtrado Geo OK. {len(df_viz_geo)} resultados con coordenadas.")
    
    df_viz_geo = df_viz_geo.sort_values("SCORE", ascending=False).head(int(topk)).reset_index(drop=True)
    print(f"--- DEBUG: Top-{topk} aplicado. {len(df_viz_geo)} resultados listos para 'to_nodes'.")
    
    nodes, map_path = _to_nodes_links_path(df_viz_geo, catalog_df, anchor_code=geo_anchor_code)
    
    nodes_with_geo_for_json = [n for n in nodes if n.get('lat') is not None and n.get('lon') is not None]
    
    if not nodes_with_geo_for_json:
        print(f"❌ Después de filtrar, no quedan nodos para visualizar para la query: '{query}'")
        return HTML(f"<div style='text-align:center; padding:20px; color:#c0392b;'>No se encontraron puntos para mostrar en el mapa para: <strong>'{query}'</strong></div>")

    print(f"--- DEBUG: Preparación de JSON OK. {len(nodes_with_geo_for_json)} nodos se enviarán a D3.")
    
    data_json = json.dumps({
        "nodes": nodes_with_geo_for_json, 
        "path": map_path
    }, ensure_ascii=False)
    
    # 4. Preparar HTML/JS (simplificado)
    map_id = f"map-{uuid.uuid4().hex[:6]}"
    tooltip_id = f"tooltip-{uuid.uuid4().hex[:6]}"
    
    # --- INICIO DEL BLOQUE HTML (CORREGIDO Y COMPLETO) ---
    html = """
<style>
  #%(map_id)s_container { 
    width:100%%; max-width: 900px; margin:auto; 
    font-family: system-ui, sans-serif;
    border: 1px solid #ccc; border-radius: 8px;
    background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.05);
  }
  #%(map_id)s_container h4 { 
    margin: 0; padding: 12px 16px; border-bottom: 1px solid #eee; 
  }
  #%(map_id)s { height: 600px; position: relative; }
  .map-tooltip { 
    position: absolute; background: rgba(0,0,0,0.75); color: #fff; 
    padding: 6px 10px; border-radius: 4px; font-size: 13px; 
    pointer-events: none; opacity: 0; transition: opacity 0.2s; 
    z-index: 10;
  }
</style>
<div id="%(map_id)s_container">
  <h4>🗺️ Mapa de Ruta para: "%(q)s"</h4>
  <div id="%(map_id)s">
    <div id="%(tooltip_id)s" class="map-tooltip"></div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script src="https://cdn.jsdelivr.net/npm/topojson-client@3"></script>
<script>
(function(){
  const data = %(data)s;
  const nodes = data.nodes || [];
  const mapPath = data.path || [];
  
  if (nodes.length === 0) {
    console.warn("D3.js: No hay nodos con coordenadas para dibujar.");
    return;
  }
  
  const regions = Array.from(new Set(nodes.map(d => d.region || "Sin Región")));
  const colorRegion = d3.scaleOrdinal(d3.schemeTableau10).domain(regions);
  
  const scoreDomain = d3.extent(nodes, d => d.score);
  const colorLine = d3.scaleSequential(d3.interpolateReds).domain(scoreDomain);

  const host = document.getElementById("%(map_id)s");
  const tooltip = d3.select("#%(tooltip_id)s");
  const W = host.clientWidth;
  const H = 600; // Altura fija
  
  if (!W || W <= 0) {
      console.error("D3.js: Error. El contenedor del mapa no tiene ancho (width).");
      return;
  }

  const svg = d3.select(host).append("svg").attr("width", W).attr("height", H);
  const g = svg.append("g");
  
  const zoom = d3.zoom().scaleExtent([1, 15]).on("zoom", (ev) => { g.attr("transform", ev.transform); });
  svg.call(zoom);

  d3.json("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json").then(world=>{
    const countries = topojson.feature(world, world.objects.countries);
    let peru = countries.features.find(f => f.id === "604");
    if (!peru) peru = countries.features.find(f => (f.properties && f.properties.name==="Peru"));
    
    const pts_with_geo = nodes.filter(d => d.lat !== null && d.lon !== null);
    let proj;

    if (peru) {
      proj = d3.geoMercator().fitExtent([[18,18],[W-18,H-18]], peru);
    } else if (pts_with_geo.length > 0) {
        // Fallback: si no hay Perú, ajustar a los puntos disponibles
        const lonMin = d3.min(pts_with_geo, d => d.lon);
        const lonMax = d3.max(pts_with_geo, d => d.lon);
        const latMin = d3.min(pts_with_geo, d => d.lat);
        const latMax = d3.max(pts_with_geo, d => d.lat);
        
        const bounds = {
            type: "Feature",
            geometry: {
                type: "Polygon",
                coordinates: [[
                    [lonMin, latMin], [lonMax, latMin],
                    [lonMax, latMax], [lonMin, latMax],
                    [lonMin, latMin]
                ]]
            }
        };
        proj = d3.geoMercator().fitExtent([[18,18],[W-18,H-18]], bounds);
    } else {
        proj = d3.geoMercator().center([-75, -9]).scale(1500).translate([W / 2, H / 2]);
    }
    
    const path = d3.geoPath(proj);

    if (peru) {
      g.append("path").datum(peru).attr("d", path).attr("fill","#f4f4f4").attr("stroke","#aaa");
    } else {
      g.append("path").datum(countries).attr("d", path).attr("fill","#e0e0e0").attr("stroke","#999");
    }

    const lines = g.append("g").selectAll("line.map-path").data(mapPath).join("line")
      .attr("class", "map-path")
      .attr("x1", d => proj(d.source_geo)[0]).attr("y1", d => proj(d.source_geo)[1])
      .attr("x2", d => proj(d.target_geo)[0]).attr("y2", d => proj(d.target_geo)[1])
      .attr("stroke", d => colorLine(d.score)).attr("stroke-width", 2.5)
      .attr("stroke-opacity", 0.7).style("pointer-events", "none");

    const dots = g.selectAll("g.node").data(pts_with_geo).join("g")
      .attr("class", "node").attr("transform", d => `translate(${proj([+d.lon, +d.lat])})`)
      .style("cursor","pointer")
      .on("mouseover", (ev, d) => { 
         tooltip.style("opacity", 1).html(d.name + "<br/>" + (d.region || "") + "<br/>Score: " + d.score.toFixed(2)); 
      })
      .on("mousemove", (ev) => { 
         const [x, y] = d3.pointer(ev, host);
         tooltip.style("left", (x + 15) + "px").style("top", (y - 20) + "px"); 
      })
      .on("mouseout", () => { 
         tooltip.style("opacity", 0); 
      });

    dots.append("circle").attr("r", d => d.is_anchor ? 8 : 6)
      .attr("fill", d => d.is_anchor ? "#d32f2f" : colorRegion(d.region||"Sin Región"))
      .attr("stroke", d => d.is_anchor ? "#fff" : "#333").attr("stroke-width", 1.5);
  });
})();
</script>
""" % {
        "map_id": map_id,
        "tooltip_id": tooltip_id,
        "q": str(query), 
        "data": data_json
    }
    # --- FIN DEL BLOQUE HTML ---
    
    return HTML(html)