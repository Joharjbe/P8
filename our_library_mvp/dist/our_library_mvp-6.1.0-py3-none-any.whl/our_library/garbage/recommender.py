# src/our_library/recommender.py

import os, joblib, pandas as pd, numpy as np
import json, uuid, math
from math import radians, sin, cos, asin, sqrt
from IPython.display import HTML, display

# --- ============================================= ---
# --- PARTE 1: LÓGICA DEL MOTOR (recs.py)           ---
# --- ============================================= ---

# Variables globales para los modelos cargados
tfidf = None
knn = None
df_recs = None # DataFrame global para el motor
MODEL_DIR_CACHE = None

def _find_col(df, options):
    """Encuentra la primera columna que exista en el df, ignorando mayúsculas/minúsculas."""
    df_cols_lower = {c.lower(): c for c in df.columns}
    for opt in options:
        if opt.lower() in df_cols_lower:
            return df_cols_lower[opt.lower()]
    return None

def haversine_km(lat1, lon1, lat2, lon2):
    vals = [lat1, lon1, lat2, lon2]
    if any(pd.isna(v) for v in vals): return np.nan
    R = 6371.0
    dlat, dlon = radians(lat2-lat1), radians(lon2-lon1)
    a = sin(dlat/2)**2 + cos(radians(lat1))*cos(radians(lat2))*sin(dlon/2)**2
    return 2 * R * asin(np.sqrt(a))

def load_recs(model_dir):
    """
    Carga los modelos y datos en las variables globales.
    """
    global tfidf, knn, df_recs, MODEL_DIR_CACHE
    if MODEL_DIR_CACHE == model_dir and tfidf is not None:
        print("Modelos ya cargados.")
        return

    print(f"Cargando modelos desde {model_dir}...")
    MODEL_DIR_CACHE = model_dir
    
    tfidf_path = os.path.join(model_dir, "tfidf.joblib")
    knn_path = os.path.join(model_dir, "knn.joblib")
    
    assert os.path.exists(tfidf_path), f"No se encontró {tfidf_path}"
    assert os.path.exists(knn_path), f"No se encontró {knn_path}"

    tfidf = joblib.load(tfidf_path)
    knn = joblib.load(knn_path)

    # 1. Cargar Parquet
    df_recs_path = os.path.join(model_dir, "recursos.parquet")
    assert os.path.exists(df_recs_path), f"No se encontró {df_recs_path}"
    df_recs = pd.read_parquet(df_recs_path)

    # 2. Validar y renombrar columnas (basado en tu .info())
    #    (Usamos los nombres exactos que me mostraste)
    assert "LATITUD" in df_recs.columns, "Falta la columna 'LATITUD' en recursos.parquet"
    assert "LONGITUD" in df_recs.columns, "Falta la columna 'LONGITUD' en recursos.parquet"
    assert "CODE" in df_recs.columns, "Falta la columna 'CODE' en recursos.parquet"
    assert "TEXT" in df_recs.columns, "Falta la columna 'TEXT' en recursos.parquet"
    assert "NOMBRE DEL RECURSO" in df_recs.columns, "Falta la columna 'NOMBRE DEL RECURSO' en recursos.parquet"

    df_recs["LATITUD"] = pd.to_numeric(df_recs["LATITUD"], errors="coerce")
    df_recs["LONGITUD"] = pd.to_numeric(df_recs["LONGITUD"], errors="coerce")
            
    # 3. Resetear índice para que .iloc funcione
    df_recs = df_recs.reset_index(drop=True)
    
    # 4. Crear la clave de MERGE (para el ancla)
    df_recs["CODIGO_CAT_KEY"] = df_recs["CODE"].astype(str).str.split('.').str[0].str.strip()

    print(f"Registros: {len(df_recs):,}")

def recs_ready():
    """Comprueba si los modelos están listos."""
    return tfidf is not None and knn is not None and df_recs is not None

def _check_ready():
    if not recs_ready():
        raise RuntimeError("Modelos no cargados. Llama a 'load_recs(MODEL_DIR)' primero.")

def _neighbors_by_vector(q_vec, n):
    _check_ready()
    n = min(n, len(df_recs))
    distances, indices = knn.kneighbors(q_vec, n_neighbors=n)
    return indices[0].tolist(), distances[0].tolist()

def _rankear(base_idx, idxs, dists, alpha=1.0, geo_km=None, rg_mode=None, rg_weight=0.05, **kwargs):
    _check_ready()
    sim = pd.Series(1.0 - np.array(dists), index=idxs)
    
    cand = df_recs.iloc[idxs].copy() 
    
    if base_idx is not None and base_idx in cand.index:
        cand = cand.drop(index=base_idx)
    cand["SIM_TEXT"] = cand.index.map(sim).astype(float)

    if "REGION_GEOGRAFICA" in df_recs.columns and base_idx is not None:
        base_rg = df_recs.loc[base_idx, "REGION_GEOGRAFICA"]
        if rg_mode == "filter":
            cand = cand[cand["REGION_GEOGRAFICA"] == base_rg].copy()
            cand["RG_BONUS"] = 0.0
        elif rg_mode == "bonus":
            cand["RG_BONUS"] = (cand["REGION_GEOGRAFICA"] == base_rg).astype(float)
        else: cand["RG_BONUS"] = 0.0
    else: cand["RG_BONUS"] = 0.0

    if geo_km is not None and base_idx is not None:
        # base_idx es un índice de df_recs, que ya tiene LATITUD/LONGITUD
        lat0, lon0 = df_recs.loc[base_idx, "LATITUD"], df_recs.loc[base_idx, "LONGITUD"]
        if pd.notna(lat0) and pd.notna(lon0):
            # 'cand' también tiene LATITUD/LONGITUD
            cand["DIST_KM"] = cand.apply(lambda r: haversine_km(lat0, lon0, r["LATITUD"], r["LONGITUD"]), axis=1)
            cand["GEO_BONUS"] = (1.0 - cand["DIST_KM"]/float(geo_km)).clip(lower=0, upper=1)
        else: cand["DIST_KM"] = np.nan; cand["GEO_BONUS"] = 0.0
    else: cand["DIST_KM"] = np.nan; cand["GEO_BONUS"] = 0.0

    cand["SCORE"] = alpha*cand["SIM_TEXT"] + (1.0 - alpha)*cand["GEO_BONUS"] + rg_weight*cand["RG_BONUS"]

    return cand.sort_values("SCORE", ascending=False)

def recomendar_por_code(code, topk=10, **kwargs):
    _check_ready()
    m = df_recs.index[df_recs["CODE"].astype(str) == str(code)]
    if len(m)==0: raise ValueError(f"No existe CODE={code}")
    base_idx = int(m[0])
    
    q = tfidf.transform([df_recs.loc[base_idx, "TEXT"]])
    
    idxs, dists = _neighbors_by_vector(q, n=max(topk+1, 200))
    recs = _rankear(base_idx, idxs, dists, **kwargs)
    
    if kwargs.get("filter_cat"):  recs = recs[recs["CATEGORIA"].astype(str).str.contains(kwargs["filter_cat"],  case=False, na=False)]
    
    base = df_recs.loc[base_idx, ["CODE","NOMBRE DEL RECURSO","REGION"]].to_dict()
    return base, recs.head(topk).reset_index(drop=True)

def recomendar_por_nombre(fragmento, topk=10, **kwargs):
    _check_ready()
    hits = df_recs[df_recs["NOMBRE DEL RECURSO"].astype(str).str.contains(str(fragmento), case=False, na=False)]
    if hits.empty: raise ValueError(f"No hallé nombres que contengan: {fragmento}")
    base_idx = int(hits.index[0])
    return recomendar_por_code(df_recs.loc[base_idx, "CODE"], topk, **kwargs)

def recomendar_por_texto_libre(query, topk=10, **kwargs):
    """
    Función principal del motor.
    """
    _check_ready()
    q = tfidf.transform([str(query).lower()])
    idxs, dists = _neighbors_by_vector(q, n=max(topk+1, 200))
    
    base_idx = None
    
    geo_anchor_code = kwargs.pop('geo_anchor_code', None) 
    if geo_anchor_code is not None:
        m = df_recs.index[df_recs["CODE"].astype(str) == str(geo_anchor_code)]
        if len(m) > 0:
            base_idx = int(m[0])
            base = df_recs.loc[base_idx, ["CODE","NOMBRE DEL RECURSO","REGION"]].to_dict()
            print(f"[Ancla] CODE={base.get('CODE')} | {base.get('NOMBRE DEL RECURSO')} | {base.get('REGION','')}")
        else:
            print(f"⚠️ Ancla {geo_anchor_code} no encontrada. Continuando sin ancla.")
            base_idx = None
        
    recs = _rankear(base_idx, idxs, dists, **kwargs) # kwargs ya no contiene geo_anchor_code

    if kwargs.get("filter_cat"):  recs = recs[recs["CATEGORIA"].astype(str).str.contains(kwargs["filter_cat"],  case=False, na=False)]

    return recs.head(topk).reset_index(drop=True)

# --- ALIASES PARA __init__.py ---
recs_recommend_code = recomendar_por_code
recs_recommend_nombre = recomendar_por_nombre
recs_recommend_texto = recomendar_por_texto_libre
recs_recommend = recomendar_por_texto_libre 

# --- ============================================= ---
# --- PARTE 2: LÓGICA DEL VISUALIZADOR (NUEVO)      ---
# --- ============================================= ---

def _format_for_display(df):
    """Prepara el DataFrame para una bonita tabla interactiva en Colab."""
    
    # Seleccionar y renombrar columnas
    cols_to_show = {
        "SCORE": "Score",
        "NOMBRE DEL RECURSO": "Nombre",
        "CATEGORIA": "Categoría",
        "REGION": "Región",
        "DIST_KM": "Dist (km)",
        "URL": "Enlace",
        "CODE": "CODE"
    }
    
    # Asegurarse de que las columnas existan
    cols_present = [c for c in cols_to_show.keys() if c in df.columns]
    df_display = df[cols_present].copy()
    df_display = df_display.rename(columns=cols_to_show)

    # Formatear números
    if "Score" in df_display.columns:
        df_display["Score"] = df_display["Score"].map('{:,.3f}'.format)
    if "Dist (km)" in df_display.columns:
        df_display["Dist (km)"] = df_display["Dist (km)"].map('{:,.1f}'.format)
        
    # Formatear URL como un enlace HTML clicable
    if "Enlace" in df_display.columns:
        df_display["Enlace"] = df_display["Enlace"].apply(
            lambda x: f'<a href="{x}" target="_blank">Ver Ficha</a>' if pd.notna(x) and x.startswith('http') else 'N/A'
        )

    # Convertir a HTML para mostrar los enlaces
    return HTML(df_display.to_html(escape=False, index=False))


def viz_recs_tabla_interactiva(query, topk=15, model_dir="/content/models",
                                geo_anchor_code=None, geo_km=None, alpha=0.85):
    """
    Genera una tabla interactiva (estilo Colab) con los resultados.
    NO usa D3.js.   
    """
    
    # 1. Llamar al motor
    motor_params = {
        "topk": topk, # Pedimos solo el topk que vamos a mostrar
        "alpha": alpha,
        "geo_anchor_code": geo_anchor_code,
        "geo_km": geo_km
    }
    try:
        raw_results = recomendar_por_texto_libre( query=str(query), **motor_params )
        print(f"--- DEBUG: Motor OK. {len(raw_results)} resultados 'raw' recibidos.")
    except Exception as e:
        print(f"❌ Error al llamar al motor 'recomendar_por_texto_libre': {e}")
        return

    if raw_results.empty:
        print(f"❌ No se encontraron resultados para la query: '{query}'")
        return HTML(f"<div style='text-align:center; padding:20px; color:#c0392b;'>No se encontraron recomendaciones para la consulta: <strong>'{query}'</strong></div>")

    # 2. Mostrar la tabla formateada
    # Colab automáticamente hará esta tabla interactiva (ordenable, filtrable)
    print(f"Mostrando Top {len(raw_results)} resultados para: '{query}'")
    
    # Habilitar la visualización interactiva de pandas en Colab
    try:
        from google.colab import data_table
        data_table.enable_dataframe_formatter()
    except ImportError:
        print("INFO: No estamos en Colab, mostrando tabla HTML estándar.")

    # Simplemente devolvemos el DataFrame. Colab/Jupyter se encargan de dibujarlo.
    # Seleccionamos las columnas más importantes para mostrar
    cols_display = [
        "SCORE", "NOMBRE DEL RECURSO", "CATEGORIA", "REGION", "PROVINCIA", 
        "DIST_KM", "SIM_TEXT", "CODE", "URL"
    ]
    cols_final = [c for c in cols_display if c in raw_results.columns]
    
    return raw_results[cols_final]