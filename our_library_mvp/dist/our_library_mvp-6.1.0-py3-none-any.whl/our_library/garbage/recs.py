# src/our_library/recs.py

import os, joblib, pandas as pd, numpy as np
from math import radians, sin, cos, asin, sqrt

# Variables globales para los modelos cargados
tfidf = None
knn = None
df = None
MODEL_DIR_CACHE = None

def haversine_km(lat1, lon1, lat2, lon2):
    vals = [lat1, lon1, lat2, lon2]
    if any(pd.isna(v) for v in vals): return np.nan
    R = 6371.0
    dlat, dlon = radians(lat2-lat1), radians(lon2-lon1)
    a = sin(dlat/2)**2 + cos(radians(lat1))*cos(radians(lat2))*sin(dlon/2)**2
    return 2 * R * asin(np.sqrt(a))

def load_recs(model_dir):
    """
    Carga los modelos y datos en las variables globales.
    """
    global tfidf, knn, df, MODEL_DIR_CACHE
    if MODEL_DIR_CACHE == model_dir and tfidf is not None:
        print("Modelos ya cargados.")
        return

    print(f"Cargando modelos desde {model_dir}...")
    MODEL_DIR_CACHE = model_dir
    
    tfidf_path = os.path.join(model_dir, "tfidf.joblib")
    knn_path = os.path.join(model_dir, "knn.joblib")
    
    assert os.path.exists(tfidf_path), f"No se encontró {tfidf_path}"
    assert os.path.exists(knn_path), f"No se encontró {knn_path}"

    tfidf = joblib.load(tfidf_path)
    knn = joblib.load(knn_path)

    try:
        df_path = os.path.join(model_dir, "recursos.parquet")
        df = pd.read_parquet(df_path)
    except Exception:
        print("No se encontró parquet, intentando con CSV...")
        df_path = os.path.join(model_dir, "recursos.csv")
        assert os.path.exists(df_path), f"No se encontró {df_path}"
        df = pd.read_csv(df_path)

    for c in ["LATITUD","LONGITUD"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
            
    # Asegura que la columna TEXT exista para recomendar_por_code
    if "TEXT" not in df.columns and "NOMBRE DEL RECURSO" in df.columns:
        print("Warning: Columna 'TEXT' no encontrada. Usando 'NOMBRE DEL RECURSO' como fallback.")
        df["TEXT"] = df["NOMBRE DEL RECURSO"].astype(str)
    elif "TEXT" not in df.columns:
        raise ValueError("El archivo 'recursos' debe tener una columna 'TEXT' o 'NOMBRE DEL RECURSO'")

    print(f"Registros: {len(df):,}")

def recs_ready():
    """Comprueba si los modelos están listos."""
    return tfidf is not None and knn is not None and df is not None

def _check_ready():
    if not recs_ready():
        raise RuntimeError("Modelos no cargados. Llama a 'load_recs(MODEL_DIR)' primero.")

def _neighbors_by_vector(q_vec, n):
    _check_ready()
    n = min(n, len(df))
    distances, indices = knn.kneighbors(q_vec, n_neighbors=n)
    return indices[0].tolist(), distances[0].tolist()

def _rankear(base_idx, idxs, dists, alpha=1.0, geo_km=None, rg_mode=None, rg_weight=0.05, **kwargs):
    """
    Función interna de ranking.
    kwargs se usa para ignorar parámetros extra que no usa.
    """
    _check_ready()
    sim = pd.Series(1.0 - np.array(dists), index=idxs)
    cand = df.iloc[idxs].copy()
    if base_idx is not None and base_idx in cand.index:
        cand = cand.drop(index=base_idx)
    cand["SIM_TEXT"] = cand.index.map(sim).astype(float)

    if "REGION_GEOGRAFICA" in df.columns and base_idx is not None:
        base_rg = df.loc[base_idx, "REGION_GEOGRAFICA"]
        if rg_mode == "filter":
            cand = cand[cand["REGION_GEOGRAFICA"] == base_rg].copy()
            cand["RG_BONUS"] = 0.0
        elif rg_mode == "bonus":
            cand["RG_BONUS"] = (cand["REGION_GEOGRAFICA"] == base_rg).astype(float)
        else: cand["RG_BONUS"] = 0.0
    else: cand["RG_BONUS"] = 0.0

    if geo_km is not None and base_idx is not None and "LATITUD" in df.columns and "LONGITUD" in df.columns:
        lat0, lon0 = df.loc[base_idx, "LATITUD"], df.loc[base_idx, "LONGITUD"]
        if pd.notna(lat0) and pd.notna(lon0):
            cand["DIST_KM"] = cand.apply(lambda r: haversine_km(lat0, lon0, r.get("LATITUD", np.nan), r.get("LONGITUD", np.nan)), axis=1)
            cand["GEO_BONUS"] = (1.0 - cand["DIST_KM"]/float(geo_km)).clip(lower=0, upper=1)
        else: cand["DIST_KM"] = np.nan; cand["GEO_BONUS"] = 0.0
    else: cand["DIST_KM"] = np.nan; cand["GEO_BONUS"] = 0.0

    cand["SCORE"] = alpha*cand["SIM_TEXT"] + (1.0 - alpha)*cand["GEO_BONUS"] + rg_weight*cand["RG_BONUS"]

    # --- ¡ESTA ES LA CORRECCIÓN DEL BUG DE DATOS! ---
    # Nos aseguramos de que LATITUD y LONGITUD estén en la salida
    cols = ["CODE","REGION","PROVINCIA","DISTRITO","NOMBRE DEL RECURSO","CATEGORIA",
            "TIPO_DE_CATEGORIA","SUB_TIPO_CATEGORIA","URL",
            "LATITUD", "LONGITUD",  # <-- ESTAS FALTABAN
            "REGION_GEOGRAFICA","SIM_TEXT","GEO_BONUS","RG_BONUS","DIST_KM","SCORE"]
            
    cols = [c for c in cols if c in cand.columns]
    return cand.sort_values("SCORE", ascending=False)[cols]

def recomendar_por_code(code, topk=10, **kwargs):
    _check_ready()
    m = df.index[df["CODE"].astype(str) == str(code)]
    if len(m)==0: raise ValueError(f"No existe CODE={code}")
    base_idx = int(m[0])
    
    assert "TEXT" in df.columns, "La columna 'TEXT' no existe en recursos.parquet/csv"
    q = tfidf.transform([df.loc[base_idx, "TEXT"]])
    
    idxs, dists = _neighbors_by_vector(q, n=max(topk+1, 200))
    recs = _rankear(base_idx, idxs, dists, **kwargs)
    
    if kwargs.get("filter_cat"):  recs = recs[recs["CATEGORIA"].astype(str).str.contains(kwargs["filter_cat"],  case=False, na=False)]
    if kwargs.get("filter_tipo"): recs = recs[recs["TIPO_DE_CATEGORIA"].astype(str).str.contains(kwargs["filter_tipo"], case=False, na=False)]
    if kwargs.get("filter_sub"):  recs = recs[recs["SUB_TIPO_CATEGORIA"].astype(str).str.contains(kwargs["filter_sub"], case=False, na=False)]
    
    base = df.loc[base_idx, ["CODE","NOMBRE DEL RECURSO","REGION"]].to_dict()
    return base, recs.head(topk).reset_index(drop=True)

def recomendar_por_nombre(fragmento, topk=10, **kwargs):
    _check_ready()
    hits = df[df["NOMBRE DEL RECURSO"].astype(str).str.contains(str(fragmento), case=False, na=False)]
    if hits.empty: raise ValueError(f"No hallé nombres que contengan: {fragmento}")
    base_idx = int(hits.index[0])
    return recomendar_por_code(df.loc[base_idx, "CODE"], topk, **kwargs)

def recomendar_por_texto_libre(query, topk=10, **kwargs):
    _check_ready()
    q = tfidf.transform([str(query).lower()])
    idxs, dists = _neighbors_by_vector(q, n=max(topk+1, 200))
    
    base_idx = None
    
    # Corregimos el bug de 'geo_anchor_code'
    geo_anchor_code = kwargs.pop('geo_anchor_code', None) 
    if geo_anchor_code is not None:
        m = df.index[df["CODE"].astype(str) == str(geo_anchor_code)]
        base_idx = int(m[0]) if len(m) else None
        
    recs = _rankear(base_idx, idxs, dists, **kwargs)

    if kwargs.get("filter_cat"):  recs = recs[recs["CATEGORIA"].astype(str).str.contains(kwargs["filter_cat"],  case=False, na=False)]
    if kwargs.get("filter_tipo"): recs = recs[recs["TIPO_DE_CATEGORIA"].astype(str).str.contains(kwargs["filter_tipo"], case=False, na=False)]
    if kwargs.get("filter_sub"):  recs = recs[recs["SUB_TIPO_CATEGORIA"].astype(str).str.contains(kwargs["filter_sub"], case=False, na=False)]

    return recs.head(topk).reset_index(drop=True)

# --- ALIASES PARA COMPATIBILIDAD ---
recs_recommend_code = recomendar_por_code
recs_recommend_nombre = recomendar_por_nombre
recs_recommend_texto = recomendar_por_texto_libre
recs_recommend = recomendar_por_texto_libre 
recs_to_nodes_links = None